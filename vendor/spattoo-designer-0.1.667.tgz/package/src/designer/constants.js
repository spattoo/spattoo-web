// ── Cake geometry constants ───────────────────────────────────────────────────
// Radii for each tier slot (index 0 = bottom tier, ascending toward top).
/* The designer's own ground — the clear colour behind the cake while editing.
 *
 * Exported because the reel panel offers it back as the "Studio" swatch, and the reel's whole promise
 * is that what you see is what records. When these two were separate literals they disagreed
 * (#f4f4f5 here, #E8EDE9 there), so merely OPENING the reel panel changed the ground the baker had
 * not asked to change — a silent edit in the one feature that must not have any. */
/* ⚠️ THE FLOOR: A LIGHT WARM GREY, NOT NEAR-WHITE (was #f4f4f5 until 2026-09-14). The floor is what a cake
 * is seen against — the camera looks down, so it fills most of the frame. A white cake renders its top at
 * about 242 under this scene's light; on the old near-white ground it was DARKER than the page and read as
 * a grey smudge. Chosen by eye from #dcd9d4 / #e1ded9 / #e5e2de in the real designer with production
 * lighting: on #e5e2de a white Vertical Piping top sits ~15 lighter than the floor, the wall (DESIGNER_WALL)
 * ~18 lighter again at a crisp horizon, and chocolate and the gold board separate easily. The floor is
 * unlit (see studioFloorMaterial), so this is exactly the colour on screen. Nothing is calibrated against it:
 * three.js has no bounce light, so the ground does not light the cake. */
export const DESIGNER_GROUND = '#e5e2de';

/* The WALL behind the floor — lighter than the floor, so the scene reads as a floor meeting a wall
 * rather than one flat colour the cake floats in (trial, 2026-09-14). The cake sits mostly against the
 * FLOOR (the camera looks down), so white-cake contrast is still decided by DESIGNER_GROUND; the wall
 * only has to be distinctly lighter than it. Also the colour of the page strip above the canvas, which
 * joins the top of the frame. */
export const DESIGNER_WALL = '#f6f4f1';

/* Where the floor stops and the wall starts: a STRAIGHT, CRISP line this many world units behind the
 * cake's centre, always square-on to the camera — so it reads as a floor meeting a wall however the cake
 * is turned or zoomed. Not a radial blend: that drew a curved rug-shaped edge round the cake, and a soft
 * one read as blur. */
export const DESIGNER_HORIZON = 7.5;

/* ── The grounds a take can be shot against ──────────────────────────────────────────────────────
 * A CURATED LIST, not a colour picker — the same call the storefront themes made for exactly this
 * problem (templates.js `grounds`). A free picker means somebody records a cake on neon pink at the
 * moment they are trying to post something, and the bakers who would use the freedom well would not
 * need it.
 *
 * ⚠️ HERE, not in the reel panel, because the PHOTO panel offers the same five. Two copies of a
 * swatch list is two places for "Slate" to become two different greys — and both panels promise that
 * what is on screen is what is exported, which stops being true the moment a preview reads one
 * literal and a take reads the other. That exact bug has already been paid for once on this list:
 * see DESIGNER_GROUND above.
 */
export const TAKE_GROUNDS = [
  // Literally the designer's own ground: picking Studio — or opening a panel, which selects it —
  // must leave the scene exactly as the baker had it.
  { key: 'studio', label: 'Studio', value: DESIGNER_GROUND },
  { key: 'cream',  label: 'Cream',  value: '#FBF3E7' },
  { key: 'blush',  label: 'Blush',  value: '#FBEFEF' },
  { key: 'slate',  label: 'Slate',  value: '#2E3A36' },
  { key: 'ink',    label: 'Ink',    value: '#14181A' },
];

export const TIER_RADII = [1.2, 0.9, 0.65, 0.45];

// Y-coordinate of the cake board surface and the default tier height.
export const BOTTOM_BASE = 0.1;
export const BOTTOM_H    = 1.45;

// Default vertical anchor for a bend (festoon) swag, as a FRACTION of the tier wall height —
// where the festoon's high ends sit; the belly drapes below by the (scaled) bend depth. Using
// a fraction instead of the absolute bottom_y_offset makes the swag land proportionally on any
// tier size (no hard-coded height). The Height control nudges from here.
export const BEND_ANCHOR_FRAC = 0.55;


/* ── How big a world unit is, and why this is an ASSUMPTION rather than a lookup ──────────────────
 *
 * "The thinnest acrylic must clear what the cutter holds" needs a real millimetre, and the designer
 * has no true scale to give one. The only inches-to-units constant in the codebase is
 * SHEET_INCH_TO_WORLD (0.12), and it does not mean what it looks like: at that rate one unit is
 * ~212mm, which makes the default bottom tier — diameter 2.4 — a TWENTY INCH cake. Its own comment
 * says why: it was chosen so a half sheet reads beside a round tier, not as a conversion.
 *
 * So this is declared, not derived: the default bottom tier is taken to be an 8-inch cake, which
 * puts a unit at 8 x 25.4 / 2.4 mm. Stated in one place with the arithmetic shown, so the day an
 * order pins a REAL size the caller passes it and this stops being used — the same bargain
 * rainbow.js makes with its own optional `mmPerUnit`.
 */
export const NOMINAL_MM_PER_UNIT = (8 * 25.4) / 2.4;   // ≈ 84.7

/* ── How much of the surface a typed message fills when nobody has sized it ───────────────────────
 *
 * PER MATERIAL, because a message in the two materials is not the same object. Piped cream is
 * WRITING — it spans the cake top the way a greeting is written across it. Acrylic is a cut PIECE
 * that stands on the cake, and a piece spanning 80% of the top is not a topper, it is a fence: the
 * one in the report was as wide as the tier it stood on.
 *
 * ⚠️ HERE rather than in acrylicConfig.js, for the same reason NOMINAL_MM_PER_UNIT is here — that
 * file imports the cream fonts, so anything that only wants to know how big a message starts would
 * have to pull a font table in with it, and `surface.js` (imported by cakeShapes and every canvas)
 * is exactly such a caller. ACRYLIC_DEFAULTS reads its number from here, so an admin still overlays
 * it in the one place acrylic numbers are overlaid.
 */
export const WRITING_FIT = Object.freeze({ cream: 0.8, acrylic: 0.4 });

/* The colour a fondant message starts at — plain white paste, before any gel is kneaded through it,
 * which is what a baker reaches for and the one shade that reads as fondant rather than as a choice
 * somebody already made for them. A seed, not a rule: it is the ColorWheel's starting position and
 * the renderer's fallback, so the two cannot disagree about an untouched message. */
export const FONDANT_WRITING_COLOR = '#F4EFE6';

// The starting size for a message of this material — the cream one for a message that does not say,
// because an absent `style` has always meant cream (see DEFAULT_WRITING).
export const writingFit = (style) => WRITING_FIT[style] ?? WRITING_FIT.cream;

// ── Sheet (rectangular) cakes ─────────────────────────────────────────────────
// Standard US bakery sheet/square sizes, full width × depth in inches, scaled to
// world units so a half sheet's long side (~2.16) reads at roughly the round bottom
// tier's footprint (diameter 2.4). `w` is the long side (world X), `d` the short (Z).
export const SHEET_INCH_TO_WORLD = 0.12;
const inToW = (n) => +(n * SHEET_INCH_TO_WORLD).toFixed(3);
export const SHEET_SIZES = {
  quarter:  { label: 'Quarter sheet', inches: '9×13',  w: inToW(13), d: inToW(9)  },
  half:     { label: 'Half sheet',    inches: '13×18', w: inToW(18), d: inToW(13) },
  full:     { label: 'Full sheet',    inches: '18×26', w: inToW(26), d: inToW(18) },
  square_s: { label: 'Square (8")',   inches: '8×8',   w: inToW(8),  d: inToW(8)  },
  square_l: { label: 'Square (12")',  inches: '12×12', w: inToW(12), d: inToW(12) },
};
export const SHEET_DEFAULT_KEY   = 'half';
export const SHEET_CORNER_RADIUS = 0;      // 0 = sharp vertical corners on the cake body
// Corner radius the piping uses. 0 → each side runs full length and the two rows meet at the
// sharp corner (no diagonal bridging shell). >0 → rows inset and a corner shell bridges them.
export const SHEET_PIPING_CORNER_RADIUS = 0;

// ── Sticker ───────────────────────────────────────────────────────────────────
export const STICKER_SIZE = 0.28;       // world-space side length of the hit plane

// Default placement scale (`placement_config.r`) for an UPLOADED decoration that carries none of its
// own. Without it a promoted/placed 2D image falls to the bare `1` scale in addSticker and lands as a
// tiny sticker. The promote studio lets the baker tune this per decoration with a live cake preview;
// this is the starting value there AND the default for a customer's direct-placed upload (which never
// sees the studio). Tuned to read as a topper on the cake, not a postage stamp.
export const DEFAULT_DECOR_R = 3.5;

// ── Piping style picker layout ────────────────────────────────────────────────
export const PICKER_ORIGIN_X = -0.5;
export const PICKER_STEP_X   = -0.62;
export const PICKER_ORIGIN_Z =  2.0;
export const PICKER_STEP_Z   =  0.52;

// ── Tier height ───────────────────────────────────────────────────────────────
export const TIER_HEIGHT_STEP = 0.08;   // each upper tier is this shorter than the one below

// ── Visual constants ──────────────────────────────────────────────────────────
export const SELECTION_COLOR  = '#6c47ff';   // emissive highlight on selected elements

// ── Piping ────────────────────────────────────────────────────────────────────
// Cake front faces the camera (+Z). In the ring math pos=[cos·r, y, sin·r] that's
// angle π/2, so single piping pieces seed here to land dead-center front.
export const PIPING_FRONT_ANGLE = Math.PI / 2;

// ── Camera ────────────────────────────────────────────────────────────────────
export const CAMERA_POSITION        = [0, 4.85, 6.95];
// Pulled in ~15% from [0,7,10.8] so the cake is larger and reaches under the right-side popup
// (the see-through overlay needs cake behind it to read), while still leaving clear headroom above
// for tall toppers. Tune by eye; if a multi-tier cake clips at the top, switch to height-adaptive.
//
// 2026-08-19: a further ~12% in, from [0,5.5,7.9] — a single short tier still read as small on a
// desktop viewport, which is most of the headroom the note above was protecting. That headroom is
// now largely spent, so this is close to the ceiling for a FIXED camera: the next complaint about
// framing should be answered with a height-adaptive distance rather than another number here.
// Derive it from the cake's own height so a short tier fills the frame and a tall one still fits —
// a fixed camera cannot do both, which is why it has now been tuned twice.
//
// MOBILE. Same DIRECTION as the desktop camera (both ≈34° above the horizon) — the two differ only
// in how far back they stand, which is the one thing a narrow viewport actually changes.
//
// 2026-08-20: in 15%, from [0, 6.3, 9.3]. Measured rather than guessed, because a phone frame is
// bound by its WIDTH, not its height: at 9.3 a one-tier cake's board already spanned 70% of the
// frame's width while filling only 18% of its height. That is where "the cake looks like it is
// floating on a phone" comes from — but it is NOT a distance problem, and the room to fix it by
// moving the camera is small. The board touches the side edges at 30% closer; 15% keeps a margin.
//
// The rest of that vertical emptiness cannot be closed by any camera. A phone stage is ~1.7x taller
// than wide and a one-tier cake with its board is ~2.3x wider than tall: a wide flat object cannot
// fill a tall frame without being cropped. What is left is where the emptiness SITS (framing.js) and
// how firmly the cake reads as standing on the floor — contact shadow and ground contrast — not how
// far away the camera is. Do not answer the next report of this with another number here.
export const CAMERA_POSITION_MOBILE = [0, 5.36, 7.91];
export const CAMERA_FOV             = 42;

/* ── Which way the thumbnail camera looks ────────────────────────────────────────────────────────
 *
 * ⚠️ THE THUMBNAIL IS NOT A PICTURE OF THE STUDIO. It is drawn on its own off-screen canvas with no
 * floor and no backdrop, and framed by `FitCakeCamera`, which fits the DISTANCE to the cake's
 * bounding sphere every frame. Only the DIRECTION was fixed — one hardcoded vector, dead front and
 * low — so every template in the catalogue was photographed from the same place.
 *
 * Sandeep: "some times cake's interesting decorations are on the top (hugging) or a message written
 * on the top. that needs to be highlighted. not from the front which capturrs size. some cakes need
 * to be covered both top and side, so a slightly tilted angle works here."
 *
 * ⚠️ `front` IS EXACTLY WHAT SHIPPED — az 0°, el 22.3° is the old `(0, CAMERA_POSITION[1] - 2,
 * CAMERA_POSITION[2])` normalised, so a template saved without touching the control is framed
 * byte-identically to one saved last week. A new default would have re-shot the whole catalogue the
 * next time anybody re-saved.
 *
 * ⚠️ AND `top` IS NOT 90°. Straight down, a round cake is a disc: the side it was decorated on is
 * gone, and the silhouette goes square, which the 3:2 thumbnail crop then letterboxes. 72° keeps a
 * sliver of wall under the top — enough to read as a cake rather than a circle — which is also what
 * makes the crop behave. Measured, not guessed: see the table in the Save as Template panel's note. */
export const THUMB_VIEWS = {
  front:    { label: 'Front',        az: 0,  el: 22.3 },
  tilt:     { label: 'Tilted',       az: 22, el: 45   },
  top:      { label: 'Top',          az: 0,  el: 72   },
};
export const THUMB_VIEW_DEFAULT = { az: 0, el: 22.3 };
/* Elevation is clamped rather than wrapped: past vertical the cake turns upside down, and below the
   board you photograph its underside. Azimuth is free — a cake goes all the way round. */
export const THUMB_EL_MIN = -5;
export const THUMB_EL_MAX = 85;
/* {az, el} in DEGREES → a unit direction FROM the cake TOWARD the camera. Degrees because they are
   stored on a template and read by a person; the renderer is the only thing that wants radians. */
export const thumbViewDir = (view) => {
  const az = ((view?.az ?? THUMB_VIEW_DEFAULT.az) * Math.PI) / 180;
  const el = ((view?.el ?? THUMB_VIEW_DEFAULT.el) * Math.PI) / 180;
  const c = Math.cos(el);
  return [Math.sin(az) * c, Math.sin(el), Math.cos(az) * c];
};

// ── Top cap ───────────────────────────────────────────────────────────────────
// CakeTier renders a thin cap disc (height 0.02) on top of each tier so the
// top face has a slightly smoother sheen. Balls placed on the top surface must
// sit above this cap to avoid geometric clipping.
export const CAKE_TOP_CAP_H = 0.02;

// ── Sticker surface offsets ───────────────────────────────────────────────────
// How far a side decal's base sheet sits off the wall, as a DIMENSIONLESS FRACTION of the live
// tier radius — never an absolute world length (INVARIANTS.md #8). Apply via `sideSeatOffset()`.
//
// Derived, not invented: the Relief Sticker Studio seats its decal at `TIER_R + 0.004` on its
// own 1.2-radius tier. Re-expressing that absolute value as a fraction of THAT tool's radius is
// exactly what #8 prescribes, so the designer can multiply by ITS OWN live radius. Written as the
// original quotient so the provenance survives — do not "simplify" it to a bare number.
//
// (Lesson: this was `0.025` world. On the 1.2 tier that's 2.1% of the radius — 6.25x the studio's
// 0.33% — so every side decal floated a visible slot off the wall, and you saw the board through
// the gap at the silhouette tangent. On a 0.45 tier the same constant is 5.6%: worse the smaller
// the cake, which is the signature of a hardcoded world length.)
export const SIDE_STICKER_SEAT_FRAC = 0.004 / 1.2;
export const FLAT_STICKER_Y_OFFSET  = 0.025;  // lift above cake top surface — TODO: same #8 smell, still absolute

// ── Domain enums ──────────────────────────────────────────────────────────────
// Single source of truth for the string identifiers used across the designer and
// admin. The VALUES are persisted (DB / saved designs), so they must never change
// — but referencing them by name means a slug rename never needs a code change.

// Cake surfaces an element can be placed on.
export const ZONES = Object.freeze({
  TOP_SURFACE: 'top_surface',
  SIDE:        'side',
  MIDDLE_TIER: 'middle_tier',
  BOARD:       'board',
  RIM:         'rim',
  TOP:         'top',
});

// How a placed element orients on its surface.
export const PLACEMENT_MODES = Object.freeze({
  STAND:            'stand',
  HUG:              'hug',
  PERCH:            'perch',   // figure seated on the rim/top edge — straddles the edge, legs over
  VERGE:            'verge',   // rests its base on the rim lip and reclines radially OUTWARD, the rest
                              //   cantilevered over the edge into the air (butterflies, flowers)
  INSERT:           'insert',  // LEGACY position string only. Insert is now a MODIFIER (a per-zone
                              //   `insert:{…}` key riding the zone object like `seat`) that composes
                              //   with an upright base pose — NOT a position. zoneCfg promotes the old
                              //   `mode:"insert"` form to `{mode:<stand|hug>, insert:{…}}`; kept here
                              //   so that back-compat promotion has the string to match on.
});

// Internal element kinds the designer branches on (NOT the admin element-type slug).
export const ELEMENT_KINDS = Object.freeze({
  TIER:    'tier',
  TOPPER:  'topper',
  STICKER: 'sticker',
  TEXT:    'text',
  IMAGE:   'image',
});

// Element-type SLUGS that have bespoke placement logic. Anything special-cased in
// code must be referenced from here, never as a bare string literal.
export const ELEMENT_SLUGS = Object.freeze({
  SCATTERED_DECOR: 'scattered_decor',
  PICKS:           'picks',
  IMAGE_TOPPER:    'image_topper',
});

// Human names for the cake surfaces. Shared: the element popup labels a zone with these, and so does
// the upload studio's zone picker — one vocabulary, so a baker who reads "Side" in one place reads
// "Side" in the other.
export const ZONE_LABELS = Object.freeze({
  top_edge:     'Top',
  bottom_board: 'Base',
  top_surface:  'Top surface',
  side:         'Side',
  side_edge:    'Side edge',
  middle_tier:  'Middle tier',
  board:        'Board',
});
