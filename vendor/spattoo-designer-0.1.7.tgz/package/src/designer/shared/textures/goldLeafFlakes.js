import { makeGoldLeafMaps } from './goldLeafTexture.js';
import { gray } from './finishCanvas.js';

// ── Gold leaf FLAKES — hand-applied edible gold-leaf shards (the "food foil" finish) ──
//
// Bakers tear a sheet of edible leaf into small irregular shards and press them flat onto the cake,
// each piece a different torn shape, scattered or swept in a diagonal. Unlike luster dust (a fine
// metallic SPRAY of round specks) this is a SCATTER of larger torn shards that lie flat and SHINE.
// Same compositing model as dust: each shard is stamped into the tier-wall material maps so it reads
// as real gold METAL over the matte cake (metalness/roughness baked ABSOLUTE so dust + foil can share
// one material). A shard's interior crinkle reuses the approved gold-foil texture (makeGoldLeafMaps),
// not a re-derived one. Developed in the admin Gold Leaf Studio. Ships in two finishes — gold/silver.

export const GOLD_LEAF_DEFAULTS = {
  metalness: 0.6,         // metallic SHEEN, but low enough that the gold albedo still reads bright
  roughness: 0.16,        // low → glossy shine (sells "foil", not matte paint)
  env: 4.5,               // envMapIntensity — high so it reflects the (dim apartment) scene env
  crinkle: 0.7,           // reserved for a future bound crinkle normal (M4)
  sizeScale: 1.0,         // global flake-size multiplier
  raggedness: 0.55,       // 0 = round blob, 1 = very torn/spiky shard
  glow: 0.35,             // emissive glow on the shards (gold, gated to flakes) → luminous foil
};
export const GOLD_LEAF_COLORS = { gold: '#e6be4a', silver: '#cdd2d8' };
export const GOLD_LEAF_NEW_FLAKE = { rot: 0, size: 1, seed: 1 };   // a fresh shard from a tap

function mulberry(seed) { let s = seed >>> 0; return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; }

// One torn shard outline around (cx,cy): an n-gon with random per-vertex radius (inward notches → torn
// edge) and angular jitter (→ angular shard, not a circle).
function tornPts(cx, cy, radPx, rot, rng, raggedness) {
  const n = 8 + Math.floor(rng() * 7);              // 8..14 vertices
  const pts = [];
  for (let i = 0; i < n; i++) {
    const a = rot + (i / n) * Math.PI * 2 + (rng() - 0.5) * 0.5;
    const rr = radPx * (1 - raggedness * rng());
    pts.push([cx + Math.cos(a) * rr, cy + Math.sin(a) * rr]);
  }
  return pts;
}

function trace(ctx, pts) {
  ctx.beginPath();
  pts.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
  ctx.closePath();
}

// Cache the foil crinkle source canvas by seed — the fbm noise is deterministic per seed, so building
// it once and reusing it keeps dragging (which rebuilds the wall maps each frame) smooth.
let _foilTile = null;
function foilCrinkleTile(seed) {
  if (_foilTile && _foilTile.seed === seed) return _foilTile.canvas;
  const t = makeGoldLeafMaps({ w: 256, h: 256, seed });
  _foilTile = { seed, canvas: t.map.image };
  return _foilTile.canvas;
}

// The side-wall (cylinder unwrap) coordinate mapper: u = angle/2π across the width, v = height
// fraction (inverted so a flake lands under the tap), and a flake near a seam stamps a wrapped copy
// one circumference over. This is the DEFAULT `project` — `makeParticleFinishMaps` passes a polar
// one for the flat top. A `project` is { pxPerWorld, place(f, radPx) -> [[cx,cy], …] } so the torn-
// shard stamping below is identical on every surface; only the (u,v)→pixel map changes.
export function sideWallProject(Wc, Hc, height) {
  return {
    pxPerWorld: Hc / height,
    place(f, radPx) {
      const cx0 = (f.u ?? 0.5) * Wc;
      const cy = (1 - (f.v ?? 0.5)) * Hc;
      const xs = cx0 < radPx * 2 ? [cx0, cx0 + Wc]
               : cx0 > Wc - radPx * 2 ? [cx0, cx0 - Wc] : [cx0];
      return xs.map(cx => [cx, cy]);
    },
  };
}

// Stamp every flake (each {u, v, rot, size, seed}) onto the supplied canvas 2D contexts. Albedo = bright
// gold/silver with a gentle foil crinkle (soft fold shadows + bright sparkle); metalness/roughness =
// ABSOLUTE greys on the shard so it goes metal over the matte base. `project` maps (u,v)→pixels for the
// surface (side wall by default; a polar disk map for the flat top) — the shard art is surface-agnostic.
export function stampFoilFlakes({
  alb, met, rou, emi, Wc, Hc, height = 2.2, leafColor = GOLD_LEAF_COLORS.gold,
  metalness = GOLD_LEAF_DEFAULTS.metalness, roughness = GOLD_LEAF_DEFAULTS.roughness,
  sizeScale = 1, raggedness = GOLD_LEAF_DEFAULTS.raggedness, flakes = [], seed = 99, project = null,
}) {
  const proj = project ?? sideWallProject(Wc, Hc, height);
  const pxPerWorld = proj.pxPerWorld;
  // Shared foil crinkle tile — reuse the approved gold-leaf texture as each shard's interior. Cached by
  // seed at module scope: the crinkle is identical every rebuild, so we must NOT re-run the fbm noise on
  // every drag frame (that made dragging lag). Only the cheap per-flake stamping repeats.
  const foilMap = foilCrinkleTile(seed);
  const metFill = gray(metalness), rouFill = gray(roughness);

  flakes.forEach((f, fi) => {
    const worldRad = 0.4 * (f.size ?? 1) * sizeScale;   // size→world unit; size comes from config r (default scale)
    const radPx = Math.max(3, worldRad * pxPerWorld);
    const rot = (f.rot ?? 0) * Math.PI / 180;
    const fseed = ((f.seed ?? 1) * 2654435761 + fi * 40503) >>> 0;
    // (u,v)→pixel centre(s) for this surface (side wall wraps the seam; top is a single polar point).
    const centers = proj.place(f, radPx);

    for (const [cx, cy] of centers) {
      const rng = mulberry((fseed + Math.round(cx)) >>> 0);
      const pts = tornPts(cx, cy, radPx, rot, rng, raggedness);
      const box = [cx - radPx * 1.3, cy - radPx * 1.3, radPx * 2.6, radPx * 2.6];
      const k = (radPx * 3.4) / 256;             // foil tile drawn large enough to cover the shard

      // ALBEDO: bright gold fill + crinkle from a REPEATING foil pattern at a FIXED density, so the
      // sparkle/shine stays consistent at any shard size (a single stretched tile read flat when large).
      const pat = alb.createPattern(foilMap, 'repeat');
      if (pat?.setTransform) {
        try { pat.setTransform(new DOMMatrix().translate(cx, cy).rotate((rot * 1.7 + fi) * 57.29578).scale(0.42)); } catch { /* older browsers: untransformed tile */ }
      }
      alb.save(); trace(alb, pts); alb.clip();
      alb.fillStyle = leafColor; alb.fillRect(...box);
      if (pat) {
        alb.globalCompositeOperation = 'multiply'; alb.globalAlpha = 0.42; alb.fillStyle = pat; alb.fillRect(...box);
        alb.globalCompositeOperation = 'screen';   alb.globalAlpha = 0.42; alb.fillStyle = pat; alb.fillRect(...box);
      } else {
        alb.translate(cx, cy); alb.rotate(rot * 1.7 + fi);
        alb.globalCompositeOperation = 'multiply'; alb.globalAlpha = 0.40;
        alb.drawImage(foilMap, -128 * k, -128 * k, 256 * k, 256 * k);
      }
      alb.restore();

      // METALNESS + ROUGHNESS: absolute greys inside the shard → it goes metal & glossy.
      met.save(); trace(met, pts); met.clip(); met.fillStyle = metFill; met.fillRect(...box); met.restore();
      rou.save(); trace(rou, pts); rou.clip(); rou.fillStyle = rouFill; rou.fillRect(...box); rou.restore();
      // EMISSIVE MASK: the shard glows (material.emissive tints it gold) → luminous foil.
      if (emi) { emi.save(); trace(emi, pts); emi.clip(); emi.fillStyle = '#ffffff'; emi.fillRect(...box); emi.restore(); }
    }
  });
}
