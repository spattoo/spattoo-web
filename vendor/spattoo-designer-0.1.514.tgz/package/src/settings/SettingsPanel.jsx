import { useState, useEffect, useRef } from 'react';
import { useIsMobile, Toggle, Section, Field } from './controls.jsx';
import ThemePreview from '../storefront/ThemePreview.jsx';
// SEC-CORE-4 — same pure helper the storefront renders through, so the input and
// the sink can never disagree about what a valid handle is.
import { normalizeIgHandle } from '../storefront/storefrontKit.js';
import { useTrimmedLogo } from '../shared/useTrimmedLogo.js';
import { PrivacyDataSection } from './PrivacyDataPanel.jsx';
import { dockedLeft } from '../shared/rail.js';

// ── Color conversion utils ─────────────────────────────────────────────────────

function hexToRgb(hex) {
  const h = (hex || '').replace('#', '');
  if (h.length !== 6) return [0, 0, 0];
  return [parseInt(h.slice(0,2),16), parseInt(h.slice(2,4),16), parseInt(h.slice(4,6),16)];
}

function rgbToHex(r, g, b) {
  return '#' + [r, g, b].map(x => Math.round(Math.max(0, Math.min(255, x))).toString(16).padStart(2,'0')).join('');
}

function rgbToHsv(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min;
  let h = 0;
  if (d !== 0) {
    switch (max) {
      case r: h = ((g - b) / d + (g < b ? 6 : 0)) / 6; break;
      case g: h = ((b - r) / d + 2) / 6; break;
      case b: h = ((r - g) / d + 4) / 6; break;
    }
  }
  return [h * 360, max === 0 ? 0 : d / max, max];
}

function hsvToRgb(h, s, v) {
  const f = n => {
    const k = (n + h / 60) % 6;
    return v - v * s * Math.max(0, Math.min(k, 4 - k, 1));
  };
  return [f(5) * 255, f(3) * 255, f(1) * 255];
}

function isValidHex(hex) {
  return /^#[0-9a-fA-F]{6}$/.test(hex);
}

// ── Color wheel picker ─────────────────────────────────────────────────────────

// ── ColorField ─────────────────────────────────────────────────────────────────

function ColorField({ label, hint, value, onChange }) {
  const safe = isValidHex(value) ? value : '#000000';

  return (
    <Field label={label} hint={hint}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 6 }}>
        {/* Swatch — native color picker overlaid invisibly on top */}
        <label style={{ position: 'relative', flexShrink: 0, cursor: 'pointer' }}>
          <div style={{
            width: 44, height: 44, borderRadius: 10, background: safe,
            border: '2.5px solid #C5D4C8',
            boxShadow: '0 2px 6px rgba(0,0,0,0.14)',
          }} />
          <input
            type="color"
            value={safe}
            onChange={e => onChange(e.target.value)}
            style={{
              position: 'absolute', inset: 0, opacity: 0,
              width: '100%', height: '100%', cursor: 'pointer',
            }}
          />
        </label>

        {/* Hex input */}
        <input
          type="text"
          value={value ?? ''}
          onChange={e => onChange(e.target.value)}
          placeholder="#000000"
          style={{
            width: 110, padding: '9px 12px', borderRadius: 10,
            border: '1.5px solid #C5D4C8', fontSize: 13, fontWeight: 700,
            fontFamily: 'monospace', color: '#2C4433', outline: 'none', background: '#fff',
          }}
        />
      </div>
    </Field>
  );
}

// ── Layout helpers ─────────────────────────────────────────────────────────────

const inp = {
  padding: '9px 12px', borderRadius: 10,
  border: '1.5px solid #C5D4C8', fontSize: 13,
  fontFamily: 'inherit', color: '#2C4433', outline: 'none',
  background: '#fff', width: '100%', boxSizing: 'border-box',
};

const DAYS = [
  { key: 'mon', label: 'Mon' },
  { key: 'tue', label: 'Tue' },
  { key: 'wed', label: 'Wed' },
  { key: 'thu', label: 'Thu' },
  { key: 'fri', label: 'Fri' },
  { key: 'sat', label: 'Sat' },
  { key: 'sun', label: 'Sun' },
];

const DEFAULT_DAY_HOURS = { open: '09:00', close: '23:30' };

const HOUR_SLOTS = Array.from({ length: 36 }, (_, i) => {
  const totalMins = 360 + i * 30;
  const h = Math.floor(totalMins / 60);
  const m = totalMins % 60;
  const value = `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`;
  const ampm = h < 12 ? 'AM' : 'PM';
  const h12  = h % 12 || 12;
  return { value, label: `${h12}:${String(m).padStart(2,'0')} ${ampm}` };
});

// ── Main panel ─────────────────────────────────────────────────────────────────

export default function SettingsPanel({ open, onClose, apiClient, primaryColor = '#1a1a1a', accentColor = '#333333', onBrandingUpdate, onSettingsSaved, onReviewFlavours, onUpgrade, onShareStore }) {
  const isMobile = useIsMobile();
  const [settings, setSettings]     = useState(null);
  const [profile,  setProfile]      = useState(null);
  const [logoFile,    setLogoFile]   = useState(null);
  const [logoPreview, setLogoPreview] = useState(null);
  // Preview the logo the way every surface actually renders it — trimmed of its transparent
  // margin. Must stay above the `if (!open) return null` below, or the hook order changes.
  const logoSrc = useTrimmedLogo(logoPreview ?? profile?.logo_url);
  const [loading,  setLoading]  = useState(false);
  const [saving,   setSaving]   = useState(false);
  const [error,    setError]    = useState(null);
  const [saved,    setSaved]    = useState(false);
  const [urlError, setUrlError] = useState(null);
  const [themes,   setThemes]   = useState([]);
  const [previewOpen, setPreviewOpen] = useState(false);

  useEffect(() => {
    if (!open) return;
    setLoading(true); setError(null); setUrlError(null); setLogoFile(null); setLogoPreview(null);
    Promise.all([
      apiClient.fetchBakerSettings(),
      apiClient.fetchBakerProfile(),
      apiClient.fetchStorefrontThemes?.().catch(() => ({ themes: [] })) ?? Promise.resolve({ themes: [] }),
    ])
      .then(([s, { baker }, themesRes]) => {
        const loaded = s ?? {};
        if (!loaded.store_hours) {
          loaded.store_hours = Object.fromEntries(DAYS.map(d => [d.key, { ...DEFAULT_DAY_HOURS }]));
        }
        setSettings(loaded);
        setProfile(baker ?? {});
        setThemes(themesRes?.themes ?? []);
      })
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  }, [open]);

  function setSetting(path, value) {
    setSettings(prev => {
      const next = { ...prev };
      const parts = path.split('.');
      let cur = next;
      for (let i = 0; i < parts.length - 1; i++) {
        cur[parts[i]] = { ...(cur[parts[i]] ?? {}) };
        cur = cur[parts[i]];
      }
      cur[parts[parts.length - 1]] = value;
      return next;
    });
  }

  function setProfileField(key, value) {
    setProfile(p => ({ ...p, [key]: value }));
  }

  function handleLogoChange(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setLogoFile(file);
    const reader = new FileReader();
    reader.onload = ev => setLogoPreview(ev.target.result);
    reader.readAsDataURL(file);
  }

  function isValidWebsite(url) {
    if (!url) return true;
    try {
      const u = new URL(url);
      return u.protocol === 'http:' || u.protocol === 'https:';
    } catch {
      return false;
    }
  }

  // Publish from the theme preview/customiser — persists theme + brand colours immediately.
  // rights_attested comes from the publish confirmation in ThemePreview — the baker's affirmation
  // that they may publish this content (content_attestations). Passed straight through: the API
  // refuses to take a storefront live without it, and it must never be defaulted here.
  async function publishStorefront({ storefront_theme_id, primary_color, accent_color, portrait_key, storefront_customizations, rights_attested }) {
    const payload = {
      storefront_theme_id, primary_color, accent_color,
      instagram_handle: profile.instagram_handle, website_url: profile.website_url, tagline: profile.tagline,
    };
    if (portrait_key !== undefined) payload.portrait_url = portrait_key;  // new portrait (R2 key) or null to clear
    if (storefront_customizations) payload.storefront_customizations = storefront_customizations;
    await apiClient.updateBakerProfile(payload);
    if (apiClient.publishStorefront) await apiClient.publishStorefront(rights_attested);   // take it live
    // Pull back the canonical portrait_url (the public URL the server builds from the key) so it
    // shows when the customiser is reopened — the frontend only had the R2 key.
    let fresh = null;
    try { fresh = (await apiClient.fetchBakerProfile())?.baker; } catch { /* keep optimistic */ }
    setProfile(p => ({
      ...p, storefront_theme_id, primary_color, accent_color, storefront_published: true,
      ...(storefront_customizations ? { storefront_customizations } : {}),
      ...(fresh && 'portrait_url' in fresh ? { portrait_url: fresh.portrait_url } : {}),
    }));
    onBrandingUpdate?.({ primary_color, accent_color, logo_url: profile.logo_url });
  }

  async function unpublishStorefront() {
    if (apiClient.unpublishStorefront) await apiClient.unpublishStorefront();
    setProfile(p => ({ ...p, storefront_published: false }));
  }

  async function handleSave() {
    const websiteVal = profile?.website_url ?? '';
    if (!isValidWebsite(websiteVal)) {
      setUrlError('Enter a valid URL starting with https:// or http://');
      return;
    }
    setSaving(true); setError(null); setSaved(false);
    try {
      const profilePayload = {
        primary_color:    profile.primary_color,
        accent_color:     profile.accent_color,
        instagram_handle: profile.instagram_handle,
        website_url:      profile.website_url,
        tagline:          profile.tagline,
      };
      if (profile.storefront_theme_id != null) profilePayload.storefront_theme_id = profile.storefront_theme_id;
      if (logoFile && apiClient.getSignedUploadUrl) {
        const ext = logoFile.name.split('.').pop();
        const filename = `${crypto.randomUUID()}.${ext}`;
        const { url, key } = await apiClient.getSignedUploadUrl('logos', filename, logoFile.type, logoFile.size);
        await fetch(url, { method: 'PUT', headers: { 'Content-Type': logoFile.type }, body: logoFile });
        profilePayload.logo_url = key;
      }
      await Promise.all([
        apiClient.updateBakerSettings(settings),
        apiClient.updateBakerProfile(profilePayload),
      ]);
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
      onSettingsSaved?.();
      onBrandingUpdate?.({
        primary_color: profile.primary_color,
        accent_color:  profile.accent_color,
        logo_url:      logoPreview ?? profile.logo_url,
      });
    } catch (e) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  }

  if (!open) return null;

  const delivery = settings?.delivery ?? {};

  return (
    <>
      <style>{`
        @keyframes slideInRight { from { transform: translateX(100%) } to { transform: translateX(0) } }
        @keyframes spin { to { transform: rotate(360deg) } }
      `}</style>

      <div style={{
        position: 'fixed', top: 0, right: 0, bottom: 0, left: dockedLeft(isMobile),
        zIndex: 300, display: 'flex', flexDirection: 'column',
        fontFamily: "'Quicksand', sans-serif",
        background: '#F4F8F5',
        boxShadow: '-4px 0 40px rgba(0,0,0,0.15)',
        animation: 'slideInRight 0.3s cubic-bezier(0.32,0.72,0,1)',
      }}>

        {/* Header */}
        <div style={{
          padding: isMobile ? '16px 20px' : '20px 28px',
          background: `linear-gradient(135deg, ${primaryColor} 0%, ${accentColor} 100%)`,
          flexShrink: 0, display: 'flex', alignItems: 'center', gap: 14,
        }}>
          <button onClick={onClose} style={{
            display: 'flex', alignItems: 'center', gap: 5, flexShrink: 0,
            background: 'rgba(255,255,255,0.12)', border: '1px solid rgba(255,255,255,0.2)',
            borderRadius: 10, padding: '7px 14px', cursor: 'pointer', fontFamily: 'inherit',
            fontSize: 13, fontWeight: 700, color: 'rgba(255,255,255,0.85)',
          }}>← Back</button>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 18, fontWeight: 800, color: '#fff' }}>Settings</div>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.6)', marginTop: 2 }}>Manage your store preferences</div>
          </div>
        </div>

        {/* Body */}
        <div style={{ flex: 1, overflowY: 'auto', padding: isMobile ? '16px' : '24px', display: 'flex', flexDirection: 'column', gap: 16 }}>

          {loading && (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', paddingTop: 60, color: '#9BB5A2', fontSize: 14 }}>
              <div style={{ width: 20, height: 20, borderRadius: '50%', border: '2.5px solid #C5D4C8', borderTopColor: '#2C4433', animation: 'spin 0.7s linear infinite', marginRight: 10 }} />
              Loading settings…
            </div>
          )}

          {error && (
            <div style={{ padding: '14px 18px', borderRadius: 12, background: '#FEE2E2', color: '#991B1B', fontSize: 13, fontWeight: 600 }}>
              {error}
            </div>
          )}

          {settings && profile && (
            <>
              {/* ── Branding ── */}
              <Section title="Branding">
                {/* Logo — clicking the image opens the file picker */}
                <Field label="Logo" hint="Wide or square both work — this is the size and shape it appears at in your storefront. Click to change.">
                  <label style={{ display: 'block', marginTop: 4, cursor: 'pointer' }}>
                    {/* Was an 80×80 square, which previewed a shape no surface actually uses: a
                        wide wordmark showed at ~12px tall here and told bakers to re-crop a logo
                        that was fine. Sized to the storefront header instead — height 52, width
                        capped at 6× that, the widest real logos run. */}
                    <div style={{
                      width: '100%', maxWidth: 312, height: 52, borderRadius: 12, overflow: 'hidden',
                      border: '2px dashed #C5D4C8', background: '#F4F8F5',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      position: 'relative', transition: 'border-color 0.15s',
                    }}
                      onMouseEnter={e => e.currentTarget.style.borderColor = '#2C4433'}
                      onMouseLeave={e => e.currentTarget.style.borderColor = '#C5D4C8'}
                    >
                      {logoSrc
                        ? <img src={logoSrc} alt="Logo"
                            style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }} />
                        : <span style={{ fontSize: 26 }}>🏪</span>
                      }
                      {/* Hover overlay */}
                      <div style={{
                        position: 'absolute', inset: 0, borderRadius: 14,
                        background: 'rgba(0,0,0,0.35)',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        opacity: 0, transition: 'opacity 0.15s',
                      }}
                        onMouseEnter={e => e.currentTarget.style.opacity = 1}
                        onMouseLeave={e => e.currentTarget.style.opacity = 0}
                      >
                        <span style={{ fontSize: 20 }}>📷</span>
                      </div>
                    </div>
                    <input type="file" accept="image/*" onChange={handleLogoChange} style={{ display: 'none' }} />
                  </label>
                  {logoFile && (
                    <div style={{ fontSize: 11, color: '#9BB5A2', marginTop: 6 }}>{logoFile.name}</div>
                  )}
                </Field>

                <ColorField
                  label="Primary Color"
                  hint="Main brand color — used for buttons and highlights."
                  value={profile.primary_color ?? ''}
                  onChange={v => setProfileField('primary_color', v)}
                />

                <ColorField
                  label="Accent Color"
                  hint="Secondary color — used for gradients."
                  value={profile.accent_color ?? ''}
                  onChange={v => setProfileField('accent_color', v)}
                />
              </Section>

              {/* ── Storefront Theme ── */}
              {themes.length > 0 && (
                <Section title="Storefront Theme">
                  <Field label="Theme" hint="See your storefront in each theme, tweak the colours, then publish.">
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12, marginTop: 6, padding: '12px 14px', borderRadius: 12, border: '1.5px solid #C5D4C8', background: '#fff' }}>
                      <div>
                        <div style={{ fontSize: 14, fontWeight: 800, color: '#2C4433' }}>
                          {themes.find(t => t.id === profile.storefront_theme_id)?.name ?? 'Spotlight'}
                        </div>
                        <div style={{ fontSize: 12, color: '#9BB5A2', marginTop: 2 }}>Current theme</div>
                      </div>
                      <button type="button" onClick={() => setPreviewOpen(true)}
                        style={{ flexShrink: 0, padding: '10px 16px', borderRadius: 10, border: 'none', cursor: 'pointer', fontFamily: 'inherit', fontSize: 13, fontWeight: 800, color: '#fff', background: `linear-gradient(135deg, ${primaryColor}, ${accentColor})` }}>
                        Preview &amp; customise →
                      </button>
                    </div>
                  </Field>
                </Section>
              )}

              {/* ── Store Info ── */}
              <Section title="Store Info">
                <Field label="Instagram">
                  <div style={{ display: 'flex', alignItems: 'center', gap: 0, marginTop: 4 }}>
                    <span style={{
                      padding: '9px 12px', borderRadius: '10px 0 0 10px',
                      border: '1.5px solid #C5D4C8', borderRight: 'none',
                      fontSize: 13, color: '#9BB5A2', background: '#F4F8F5', fontWeight: 700,
                    }}>@</span>
                    <input
                      style={{ ...inp, borderRadius: '0 10px 10px 0' }}
                      placeholder="yourbakery"
                      value={profile.instagram_handle ?? ''}
                      onChange={e => setProfileField('instagram_handle', normalizeIgHandle(e.target.value) ?? '')}
                    />
                  </div>
                </Field>

                <Field label="Website">
                  <input
                    style={{
                      ...inp, marginTop: 4,
                      borderColor: urlError ? '#E53935' : '#C5D4C8',
                    }}
                    type="text"
                    placeholder="https://yourbakery.com"
                    value={profile.website_url ?? ''}
                    onChange={e => {
                      setProfileField('website_url', e.target.value);
                      if (urlError) setUrlError(null);
                    }}
                    onBlur={e => {
                      const val = e.target.value;
                      if (val && !isValidWebsite(val))
                        setUrlError('Enter a valid URL starting with https:// or http://');
                      else
                        setUrlError(null);
                    }}
                  />
                  {urlError && (
                    <span style={{ fontSize: 11, color: '#E53935', fontWeight: 600, marginTop: 4 }}>
                      {urlError}
                    </span>
                  )}
                </Field>
              </Section>

              {/* ── Store Hours ── */}
              <Section title="Store Hours">
                <Field label="Opening hours" hint="Customers will only see delivery time slots within these hours.">
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 6 }}>
                    {DAYS.map(({ key, label }) => {
                      const hours = settings.store_hours?.[key] ?? null;
                      const isOpen = hours !== null;
                      return (
                        <div key={key} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                          <span style={{ fontSize: 13, fontWeight: 700, color: '#444', width: 34, flexShrink: 0 }}>{label}</span>
                          <Toggle
                            checked={isOpen}
                            onChange={v => {
                              const next = { ...(settings.store_hours ?? {}) };
                              next[key] = v ? { ...DEFAULT_DAY_HOURS } : null;
                              setSetting('store_hours', next);
                            }}
                          />
                          {isOpen ? (
                            <>
                              <select
                                value={hours.open}
                                onChange={e => setSetting('store_hours', { ...settings.store_hours, [key]: { ...hours, open: e.target.value } })}
                                style={{ padding: '6px 8px', borderRadius: 8, border: '1.5px solid #C5D4C8', fontSize: 12, fontFamily: 'inherit', color: '#2C4433', outline: 'none', background: '#fff', cursor: 'pointer' }}
                              >
                                {HOUR_SLOTS.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
                              </select>
                              <span style={{ fontSize: 12, color: '#9BB5A2', fontWeight: 700 }}>to</span>
                              <select
                                value={hours.close}
                                onChange={e => setSetting('store_hours', { ...settings.store_hours, [key]: { ...hours, close: e.target.value } })}
                                style={{ padding: '6px 8px', borderRadius: 8, border: '1.5px solid #C5D4C8', fontSize: 12, fontFamily: 'inherit', color: '#2C4433', outline: 'none', background: '#fff', cursor: 'pointer' }}
                              >
                                {HOUR_SLOTS.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
                              </select>
                            </>
                          ) : (
                            <span style={{ fontSize: 12, color: '#9CA3AF', fontWeight: 600 }}>Closed</span>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </Field>
              </Section>

              {/* ── Orders & Delivery ── */}
              {/* One panel, because a baker setting up their shop is answering one question — how
                  orders reach them and how cakes reach the customer. Two headings for four fields
                  read as more configuration than there is. */}
              <Section title="Orders & Delivery">
                {/* The worst outcome in the whole enquiry funnel is a customer picking a date,
                    waiting a day, and being told it was never possible. It undoes every round-trip
                    the storefront saves — and the baker knew the answer before the customer asked.
                    Set here, the storefront's date picker refuses those dates while they are still
                    on the page. Stored as a column, not in the settings blob (migration 042). */}
                {/* Says WHO does WHAT. "Notice you need" is the baker's side of it and left them
                    working out what the number actually controls; this names the customer and the
                    action, which is what the field governs. */}
                <Field label="How many days ahead customers must order"
                       hint="They won't be able to pick a date sooner than this. Set 0 if same-day orders are fine.">
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 4 }}>
                    <input
                      type="number" min={0} max={90} inputMode="numeric"
                      value={settings.lead_time_days ?? 0}
                      onChange={e => {
                        const v = e.target.value;
                        // Clamped here as well as in the API: 042 caps at 90 because a typo'd 300
                        // would make a baker unbookable for most of a year, and nobody would think
                        // to look at this field to find out why.
                        setSetting('lead_time_days', v === '' ? 0 : Math.max(0, Math.min(90, Number(v) || 0)));
                      }}
                      style={{ width: 90, padding: '9px 11px', borderRadius: 9, border: '1px solid #E5E7EB',
                               font: 'inherit', fontSize: 13, fontWeight: 600, color: '#2C4433' }}
                    />
                    <span style={{ fontSize: 13, color: '#6B7280', fontWeight: 600 }}>
                      {Number(settings.lead_time_days ?? 0) === 1 ? 'day' : 'days'}
                    </span>
                  </div>
                  <div style={{ fontSize: 11.5, color: '#9CA3AF', fontWeight: 600, marginTop: 8, lineHeight: 1.5 }}>
                    {Number(settings.lead_time_days ?? 0) === 0
                      ? 'Customers can order for today.'
                      : `The earliest a customer can pick is ${settings.lead_time_days} ${Number(settings.lead_time_days) === 1 ? 'day' : 'days'} from now.`}
                  </div>
                </Field>

                <Field label="Home Delivery" hint="Offer delivery to customers' addresses in addition to pickup.">
                  <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 4 }}>
                    <Toggle
                      checked={!!delivery.home_delivery}
                      onChange={v => setSetting('delivery.home_delivery', v)}
                    />
                    <span style={{ fontSize: 13, color: delivery.home_delivery ? '#2C4433' : '#9CA3AF', fontWeight: 600 }}>
                      {delivery.home_delivery ? 'Enabled' : 'Disabled'}
                    </span>
                  </div>
                </Field>

                {delivery.home_delivery && (
                  <Field label="Delivery Radius" hint="Maximum distance you deliver to, in kilometres.">
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 4 }}>
                      <input
                        type="number" min={1} max={500}
                        value={delivery.radius_km ?? ''}
                        onChange={e => setSetting('delivery.radius_km', e.target.value === '' ? null : Number(e.target.value))}
                        placeholder="e.g. 10"
                        style={{ width: 100, padding: '8px 12px', borderRadius: 10, border: '1.5px solid #C5D4C8', fontSize: 14, fontWeight: 700, fontFamily: 'inherit', color: '#2C4433', outline: 'none', background: '#fff' }}
                      />
                      <span style={{ fontSize: 13, color: '#6B7280', fontWeight: 600 }}>km</span>
                    </div>
                  </Field>
                )}
              </Section>

              {/* Privacy & Data — DPDP rights (consent trail, withdrawal, account deletion).
                  Self-contained: its own fetches + immediate actions, NOT part of Save Settings. */}
              <PrivacyDataSection apiClient={apiClient} />

              {/* Save */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, paddingTop: 4 }}>
                <button
                  onClick={handleSave}
                  disabled={saving}
                  style={{
                    padding: '12px 28px', borderRadius: 12, border: 'none',
                    cursor: saving ? 'not-allowed' : 'pointer',
                    background: saving ? '#C5D4C8' : `linear-gradient(135deg, ${primaryColor}, ${accentColor})`,
                    color: '#fff', fontSize: 14, fontWeight: 800, fontFamily: 'inherit',
                    boxShadow: saving ? 'none' : '0 4px 14px rgba(0,0,0,0.2)',
                    transition: 'all 0.2s', display: 'flex', alignItems: 'center', gap: 8,
                  }}
                >
                  {saving && <div style={{ width: 14, height: 14, borderRadius: '50%', border: '2px solid rgba(255,255,255,0.4)', borderTopColor: '#fff', animation: 'spin 0.7s linear infinite' }} />}
                  {saving ? 'Saving…' : 'Save Settings'}
                </button>
                {saved && <span style={{ fontSize: 13, fontWeight: 700, color: '#2C4433' }}>✓ Saved</span>}
              </div>
            </>
          )}
        </div>
      </div>

      <ThemePreview
        open={previewOpen}
        apiClient={apiClient}
        themes={themes}
        appPrimary={primaryColor}
        appAccent={accentColor}
        value={{
          storefront_theme_id: profile?.storefront_theme_id,
          primary_color: profile?.primary_color,
          accent_color:  profile?.accent_color,
          portrait_url:  profile?.portrait_url,
          storefront_published: profile?.storefront_published,
          storefront_customizations: profile?.storefront_customizations,
        }}
        baker={{ name: profile?.name, slug: profile?.slug, story: profile?.story, instagram_handle: profile?.instagram_handle, website_url: profile?.website_url }}
        logoUrl={profile?.logo_transparent_url || profile?.logo_url || null}
        onPublish={publishStorefront}
        onUnpublish={unpublishStorefront}
        // Straight through to the host, like onReviewFlavours and onUpgrade below: the share card
        // is the host's modal. The customiser decides WHEN to offer it (a Share button while live,
        // and once on a first publish); it does not own the thing that opens.
        onShareStore={onShareStore}
        // Straight through to the host: the publish review's "Review my flavours" has to open a
        // SIBLING settings screen, which neither this panel nor the customiser owns.
        onReviewFlavours={onReviewFlavours}
        // Same reason as above: a premium theme's "Upgrade to publish" opens BILLING, which is a
        // sibling screen this panel does not own.
        onUpgrade={onUpgrade}
        onClose={() => setPreviewOpen(false)}
      />
    </>
  );
}
