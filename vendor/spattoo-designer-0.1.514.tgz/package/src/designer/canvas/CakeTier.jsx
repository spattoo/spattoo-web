import { useMemo, useEffect, useLayoutEffect, useRef } from 'react';
import { albedoForLight } from '../shared/albedoForLight.js';
import * as THREE from 'three';
import { useThree } from '@react-three/fiber';
import { useGLTF } from '@react-three/drei';
import { SafeGlb } from './TextureErrorBoundary.jsx';
import { pointerRay, planeHit, cylinderHitPoint } from '../utils/raycasting.js';
import { applyGradient } from '../shared/color/gradientMaterial.js';
import { shellMatrix } from './shellMatrix.js';
import { applyStripes, areStripesActive, stripeColors } from '../shared/color/stripeMaterial.js';
import { applyGlaze, GLAZE_DEFAULTS } from '../shared/glaze/glazeMaterial.js';
import { buildGlazeDrip } from '../shared/glaze/glazeDrip.js';
import { getCreamGrainNormalMap, getWhippedFoamNormalMap } from '../shared/textures/creamWaveTexture.js';
import { getFondantNormalMap } from '../shared/textures/fondantTexture.js';
import { getRusticNormalMap } from '../shared/textures/rusticTexture.js';
import { getWeaveNormalMap, weaveTiles } from '../shared/textures/weaveStencilTexture.js';
import { makeParticleFinishMaps } from '../shared/textures/particleFinish.js';
import { frostingDef, frostingSupportsGradient, frostingAllowsStyles, DEFAULT_FROSTING, FROSTINGS } from '../frostings.js';
import { styleDef, resolveStyleParams, DEFAULT_STYLE } from '../creamStyles.js';
import { buildStyledWall } from '../geometry/creamWall.js';
import { tierShape, pipingPerimeter, pipingPerimeters, pipingHolePerimeters, rectEdgeRing, perimeter, circlePerimeter, boxHit, isRoundWall } from '../geometry/surface.js';
import { pointInPolygon } from '../geometry/shapes.js';
import { buildFestoons, buildWrapBand } from '../geometry/festoon.js';
import { seatHalfDepth } from '../geometry/seating.js';
import { buildDripGeometry, buildDripWeb, dripRenderParams } from '../geometry/chocolateDrip.js';
import { buildSecondCreamLayer, buildSecondCreamEdgeLine } from '../geometry/secondCreamLayer.js';
import { makeGoldLeafMaps } from '../shared/textures/goldLeafTexture.js';
import { GOLD_LEAF_DEFAULTS, GOLD_LEAF_COLORS } from '../shared/textures/goldLeafFlakes.js';
import { PIPING_FRONT_ANGLE, TIER_RADII, BEND_ANCHOR_FRAC, SELECTION_COLOR } from '../constants.js';
import { SHELL_HEIGHT_FRAC, setShellExtents, setFestoonExtents, setWrapExtents, festoonSig } from './pipingMetrics.js';
import { ringPositions, angleAtPoint } from './ringPositions.js';

// ── Extract the single mesh from a per-style GLB ──────────────────────────────
// ⚠️ EXPORTED because the hand-piping path needs the IDENTICAL preparation, not a similar one.
// StampStroke used to do its own — merge every mesh, centre on X/Z, seat on the raw base — and the
// difference was invisible and fatal: this bakes a +90° X rotation into the geometry before any
// config value is read, so a hand-piped shell was already a quarter turn out before the calibrated
// rotation was applied to it. Three separate attempts to fix that by adjusting the ROTATION failed,
// because the rotation was never the thing that differed. One preparation, one place.
export function extractGeo(scene) {
  let geo = null;
  scene.traverse(obj => {
    if (obj.isMesh && !geo) geo = obj.geometry.clone();
  });
  if (!geo) return null;
  geo.applyMatrix4(new THREE.Matrix4().makeRotationX(Math.PI / 2));
  geo.computeBoundingBox();
  const box = geo.boundingBox;
  const size = new THREE.Vector3(); box.getSize(size);
  const center = new THREE.Vector3(); box.getCenter(center);
  geo.translate(-center.x, -box.min.y, -center.z);
  return { geo, sizeY: size.y };
}

// Bake a shell geometry from a GLB scene: optional flip (180° X + re-anchor to the base)
// and normalise size to ~24% of the tier radius. Returns the geometry plus the scale and
// bounding extents the ring uses for radius/spacing. Shared by version A and the alternate.
function buildShellGeo(scene, flip, radius, sizeFactor, tiltDeg = [0, 0, 0]) {
  const result = extractGeo(scene);
  if (!result) return null;
  const geo = result.geo;
  if (flip) {
    geo.applyMatrix4(new THREE.Matrix4().makeRotationX(Math.PI));
    geo.computeBoundingBox();
    geo.translate(0, -geo.boundingBox.min.y, 0);
  }
  geo.computeBoundingBox();
  const bbSize = new THREE.Vector3(); geo.boundingBox.getSize(bbSize);
  // Height-normalised base scale (upright shell ≈ SHELL_HEIGHT_FRAC of the tier radius
  // tall) × the user's size.
  const sc1 = (radius * SHELL_HEIGHT_FRAC) / result.sizeY;
  const sc  = capShellScale(sc1, sizeFactor, bbSize.z, radius);
  // True rendered vertical reach: transform the shell's bounding box by the same scale and
  // tilt (meshRot X/Z — the renderer's yaw about Y and swag don't change Y extent) the Shell
  // mesh applies, so worldTopY/worldBotY are how far the shell actually reaches above/below
  // its anchor. This is what makes "top edge touches the rim" exact for tilted shells.
  const m = new THREE.Matrix4()
    .makeRotationFromEuler(new THREE.Euler(tiltDeg[0] * DEG, 0, tiltDeg[2] * DEG))
    .multiply(new THREE.Matrix4().makeScale(sc, sc, sc));
  const wbox = geo.boundingBox.clone().applyMatrix4(m);
  // worldTopY/BotY → vertical reach; worldMaxZ/MinZ → radial reach (local z = the radial axis
  // the renderer places along), both AFTER the tilt, so the editor's clamps match the pixels.
  return {
    geometry: geo, shellScale: sc, bbDepth: bbSize.z, bbWidth: bbSize.x,
    worldTopY: wbox.max.y, worldBotY: wbox.min.y,
    worldMaxZ: wbox.max.z, worldMinZ: wbox.min.z,
  };
}

/* ⚠️ HOW MUCH LIGHT A TIER WALL RECEIVES — MEASURED, NOT DERIVED, and it is NOT the garnish's 2.40.
 * The two surfaces sit in one scene but do not receive the same light: a tier is curved, rougher
 * (0.68 against a garnish's 0.52–0.18) and keeps its sheen and clearcoat, where a garnish switches
 * its specular and environment off entirely. A single shared constant would be wrong for whichever
 * surface was not measured last, which is why `albedoForLight` takes the number as a parameter.
 *
 * WITHOUT this correction a tier renders badly over-exposed and the clipping desaturates it:
 * mid-grey #808080 came back 180,173,168 against an asked 128, and a teal #4EC5B0 arrived as pale
 * mint with its chroma more than halved (119 → 56). A baker picked a colour and the cake showed a
 * paler cousin of it.
 *
 * ⚠️ MEASURE, DO NOT COMPUTE. `scripts/measure-tier-colour.mjs` prints the table. One division
 * overshoots — the pipeline is not a pure multiply end to end — so take two points and interpolate;
 * see the recipe in `shared/albedoForLight.js`. Re-measure after any change to the HDRI, the scene
 * intensity, the lamps, or this material's own roughness/sheen/clearcoat.
 *
 * ⚠️ THREE NUMBERS, NOT ONE, BECAUSE THE LIGHT HAS A CAST. Under a single scalar of 2.114 an asked
 * neutral #808080 rendered 133,125,120 — red high, blue low, a spread of 13 that no scalar removes.
 * Lebombo is an outdoor sky and simply is not neutral. Solved per channel from that reading. */
export const TIER_REFERENCE_LIGHT = [2.297, 2.007, 1.839];

/* ⚠️ FADE THE CORRECTION TOWARD WHITE, or the commonest cake in the catalogue goes grey. A tier wall
 * is large and bright, so its pale colours sit where tone mapping rolls off and the light delivered
 * is less than the reference measured at mid-grey. With a flat divide, pure white rendered 215 and
 * the default blush came back 35 points dark. At 2.0 white stays white, blush lands within 15, and
 * mid-grey is still corrected — every colour ends up closer to what was chosen than it is today, and
 * none ends up further away. A garnish needs none of this (see `albedoForLight`).
 *
 * ⚠️ THE RESIDUAL IS ADDITIVE AND CANNOT BE FIXED HERE — do not chase it by re-tuning the numbers
 * above. Saturated GREENS and CYANS keep a red lift after correction (#45d345 renders +59 on red,
 * halved from +98 but not gone). The cause is the surface's own specular and environment reflection:
 * a warm white highlight added ON TOP of the albedo, independent of it. A green's red albedo is tiny,
 * so that additive term dominates the channel — which is why it shows on greens and is invisible on
 * reds. Scaling an albedo cannot remove something that is not multiplied by it. The garnish fix hit
 * this same wall and solved it by switching specular, clearcoat and envMapIntensity to zero; a tier
 * cannot, because a cake is supposed to have sheen. (⚠️ NOT bounce light off the gold board — that
 * was the first guess, and three.js has no global illumination, so a board cannot light anything.) */
export const TIER_ROLLOFF = 2.0;

/* The wall's correction as a function, because a GRADIENT and STRIPES replace the base colour per
 * pixel and must take the same transform the solid colour takes. Without it a gradient or striped
 * tier renders uncorrected right beside a corrected solid one — the same bypass cream's gradient
 * had, found by looking for it rather than by it being reported. */
export const tierAlbedo = (color) =>
  albedoForLight(color, TIER_REFERENCE_LIGHT, { rolloff: TIER_ROLLOFF });

const DEG = Math.PI / 180;

// ── Cream "softness" → material ───────────────────────────────────────────────
// A single 0–1 control for how the piped cream reads: 0 = glossy/wet icing,
// 1 = matte/whipped. The default 0.7 reproduces the original hardcoded look
// EXACTLY (roughness 0.85, sheen 0.4) so elements saved before this control are
// unchanged. Read from placement_config (bottom_softness / top_softness); absent →
// default. The PipingCalibrator keeps an identical copy so its preview matches.
export const PIPING_SOFTNESS_DEFAULT = 0.7;
/* ⚠️ CREAM RECEIVES MORE LIGHT THAN THE WALL — measured, and it is NOT the wall's number. Cream runs
 * at roughness 0.85 with a sheen layer where the wall runs 0.68 with none, and a mid-grey #808080
 * renders 188,183,180 here against the wall's 180,173,168 and an asked 128. A reference light is a
 * property of the SURFACE; reusing the wall's would be a guess wearing a measurement's clothes.
 *
 * ⚠️ THIS IS THE ONE CHOKEPOINT FOR EVERY CREAM SURFACE — piped borders, the second cream band, the
 * calibrator, stamped strokes and cream writing all come through here, so correcting once corrects
 * all of them and none of them can drift apart. `scripts/measure-cream-colour.mjs` prints the table.
 *
 * Re-measure after any change to the HDRI, the scene intensity, the lamps, or this material's own
 * roughness/sheen — see the recipe in `shared/albedoForLight.js`. */
/* ⚠️ INTERPOLATED FROM TWO MEASURED POINTS, NOT DIVIDED ONCE. Solving straight from the uncorrected
 * render gives [2.330, 2.194, 2.114], and that still leaves grey at 141 against an asked 128 — the
 * pipeline is not a pure multiply end to end, because tone mapping compresses differently at the
 * higher albedo a smaller divisor produces. The wall hit the same wall (predicted 1.163, rendered
 * 142). Take a second reading with the first guess in place and interpolate; do not re-derive this
 * by division and assume the arithmetic is the answer. */
export const CREAM_REFERENCE_LIGHT = [3.254, 2.974, 2.679];
export const CREAM_ROLLOFF = 2.0;   // same reason as the wall: pale cream must not go grey

/* The same correction the solid colour gets, exposed so a GRADIENT's stops can take it too — a
 * gradient replaces the base colour per pixel, so uncorrected stops would render a gradient in
 * different colours from the solid it stands in for. */
export const creamAlbedo = (color) =>
  albedoForLight(color, CREAM_REFERENCE_LIGHT, { rolloff: CREAM_ROLLOFF });

export function creamMaterialProps(softness, color) {
  const s = Math.min(1, Math.max(0, softness ?? PIPING_SOFTNESS_DEFAULT));
  const albedo = creamAlbedo(color);
  return {
    color: albedo,
    roughness:      0.5 + 0.5 * s,   // 0.5 wet … 0.85 (default) … 1.0 matte
    sheen:          (0.4 / 0.7) * s, // 0 … 0.4 (default) … ~0.571 velvety
    sheenRoughness: 0.9,
    sheenColor:     albedo,
  };
}

// ── Chocolate "gloss" → material ──────────────────────────────────────────────
// A single 0–1 control for how wet the ganache reads: 0 = matte set chocolate,
// 1 = glossy wet drip (the default). Drives BOTH roughness and a clearcoat layer
// together (the clearcoat is what sells "wet ganache" vs "plastic"). Mirrors the
// cream "softness" idea but for chocolate. The admin drip studio keeps the same map.
export const DRIP_GLOSS_DEFAULT = 0.85;
/* ⚠️ THE GLOSSIEST SURFACE ON THE CAKE, and the most over-exposed: a mid-grey #808080 renders
 * 188,182,178 here against 180 on the tier wall and 156 on grass. The clearcoat is why — a wet
 * ganache carries a coat the wall does not. Measured for THIS material, like every other.
 * `SURFACE=drip node scripts/measure-surface-colour.mjs` prints the table.
 *
 * ⚠️ ONE CHOKEPOINT for every chocolate surface — the rim drip and the glaze tendrils both come
 * through here, so they cannot drift apart. */
export const CHOCOLATE_REFERENCE_LIGHT = [2.352, 2.194, 2.093];
export const CHOCOLATE_ROLLOFF = 2.0;

export function chocolateMaterialProps(gloss, color) {
  const g = Math.min(1, Math.max(0, gloss ?? DRIP_GLOSS_DEFAULT));
  return {
    color: albedoForLight(color, CHOCOLATE_REFERENCE_LIGHT, { rolloff: CHOCOLATE_ROLLOFF }),
    metalness:          0,
    roughness:          0.5 - 0.42 * g,    // 0.5 matte … 0.08 wet
    clearcoat:          0.4 + 0.6 * g,     // 0.4 … 1.0 glassy
    clearcoatRoughness: 0.28 - 0.16 * g,   // 0.28 … 0.12
  };
}

// ── Acrylic gold finish ───────────────────────────────────────────────────────
// A shiny, lacquered gold for writing/toppers — fully metallic with a clearcoat
// layer on top so it reads as a glossy acrylic/resin gold rather than raw metal.
export const GOLD_FINISH_COLOR = '#d4a824';
export function goldMaterialProps(color = GOLD_FINISH_COLOR) {
  return {
    color,
    // Slightly under full-metal so the gold albedo always reads as gold even
    // without a strong environment map (full metalness mirrors the scene and
    // can pick up the cake's pink). A warm emissive base keeps the glow gold.
    metalness:          0.85,
    roughness:          0.25,   // tight, bright highlights
    clearcoat:          1.0,    // the acrylic/lacquer coat
    clearcoatRoughness: 0.06,
    reflectivity:       1.0,
    sheen:              0,
  };
}

// ── Metallic cream finish ─────────────────────────────────────────────────────
// A shiny, pearlescent take on a chosen cream colour — half-metal with a clearcoat
// and a bright sheen so it shimmers like glossy buttercream/lustre dust rather than
// reading as raw metal. Keeps the picked colour as its tint.
export function metallicCreamProps(color) {
  return {
    color,
    metalness:          0.55,
    roughness:          0.18,   // glossy, but softer than the gold/silver metals
    clearcoat:          1.0,
    clearcoatRoughness: 0.08,
    reflectivity:       1.0,
    sheen:              0.6,
    sheenColor:         '#ffffff',
    sheenRoughness:     0.55,
  };
}

// ── Acrylic silver finish ─────────────────────────────────────────────────────
// Same lacquered-metal treatment as gold, in a cool silver. The neutral albedo
// reads as silver even without a strong env map; emissive is handled by the caller.
export const SILVER_FINISH_COLOR = '#cdd2d8';
export function silverMaterialProps(color = SILVER_FINISH_COLOR) {
  return {
    color,
    metalness:          0.9,
    roughness:          0.22,
    clearcoat:          1.0,
    clearcoatRoughness: 0.06,
    reflectivity:       1.0,
    sheen:              0,
  };
}

// Cream piping must hug the cake, not float off it. The shell's radial depth (how far it
// reaches off the wall) is limited dynamically to a fraction of the tier radius — so a
// smaller tier gets a tighter limit. Past the limit, raising the size slider no longer
// enlarges the shell, which is what keeps the cream from leaving the cake.
const PIPING_MAX_DEPTH_FRAC = 0.16;

// How far (as a fraction of the tier radius) the radial control may push the BOARD border
// OUTWARD past its default (inner face on the wall) before it's capped — keeps it attached to
// the cake rather than drifting onto the board. Inward travel is unrestricted.
const PIPING_RADIAL_PLAY = 0.4;

// Default height of a WRAP band (a pre-formed ring wrapped round the wall), as a fraction of
// the tier radius. The band's thickness follows from the ring's own cross-section aspect; the
// size control scales both. Tuned so a size-1 band reads like a proper cream band on the wall.
const PIPING_WRAP_HEIGHT_FRAC = 0.4;

// GLYPH cakes: the ring's radial inset/outset is CLAMPED to this fraction of the glyph STROKE width, so
// an absolute radial offset authored for a round cake (e.g. −0.17) can't push beads past the thin stroke
// and collapse the border to the stroke centreline (which rings the counters). Radius-independent — the
// bound tracks the live stroke width, per INVARIANTS #8.
const GLYPH_PIPE_INSET_FRAC = 0.45;

// Cap the user-scaled shell scale so its rendered radial depth (bbDepthZ × scale) never
// exceeds PIPING_MAX_DEPTH_FRAC of the tier radius. The max() floor keeps a little growth
// headroom even when the size-1.0 shell is already deep, so the slider is never fully dead.
function capShellScale(sc1, sizeFactor, bbDepthZ, radius) {
  const maxSc = Math.max(sc1 * 1.15, (radius * PIPING_MAX_DEPTH_FRAC) / bbDepthZ);
  return Math.min(sc1 * sizeFactor, maxSc);
}

// Measure a DECORATION GLB for the "element" ring finish. Unlike buildShellGeo (which extracts a
// single geometry and recolours it cream), a decoration keeps its FULL scene + real materials, so we
// only MEASURE it — whole-scene bbox, authored upright (no piping X-rotation). Returns the same shape
// buildShellGeo does (shellScale / bbWidth / bbDepth + world extents), so ringPositions and the editor
// clamps treat it identically, plus `scene` / `minY` for the base-seated render. Height-normalised to
// SHELL_HEIGHT_FRAC of the tier radius (× user size), sharing the same depth cap as cream shells.
function buildDecorationShell(scene, radius, sizeFactor) {
  if (!scene) return null;
  const box = new THREE.Box3().setFromObject(scene);
  const size = new THREE.Vector3(); box.getSize(size);
  const sc1 = (radius * SHELL_HEIGHT_FRAC) / (size.y || 1);
  const sc  = capShellScale(sc1, sizeFactor, size.z || 1e-3, radius);
  return {
    scene, minY: box.min.y, isElement: true,
    shellScale: sc, bbWidth: size.x, bbDepth: size.z,
    // Extents relative to the base-seat anchor (base at 0): for the Height/radial clamps + clearance.
    worldTopY: size.y * sc, worldBotY: 0,
    worldMaxZ: box.max.z * sc, worldMinZ: box.min.z * sc,
  };
}

// buildSwagRing / perimeterSinglePos / perimeterRing + the whole ring distribution moved to
// ./ringPositions.js (shared by the cream rings AND the decoration ring; unit-tested there).

// Local-space bbox of a geometry, in the frame the gradient shader reads (the `position`
// attribute). Null when there's no gradient so non-gradient piping skips the work.
function geomBBox(geometry, gradient) {
  if (!gradient || !geometry) return null;
  geometry.computeBoundingBox?.();
  const bb = geometry.boundingBox;
  if (!bb) return null;
  const size = new THREE.Vector3(); bb.getSize(size);
  const center = new THREE.Vector3(); bb.getCenter(center);
  return { min: bb.min.clone(), size, center };
}

// One cream mesh (a shell, festoon, or wrap band). The cream material is config-driven: a single
// solid colour by default, or a multi-colour blend when the ring carries a `gradient` — applied via
// the SHARED gradientMaterial helper (same one stickers use), so there is no piping-specific
// gradient code. Gradient blends per-mesh in the geometry's local frame (each dollop is two-tone,
// like a two-colour piping bag).
function CreamMesh({ geometry, rotation, scale, color, softness, gradient, selected, castShadow = true, userData = null }) {
  const matRef = useRef(null);
  const bbox = useMemo(() => geomBBox(geometry, gradient), [geometry, gradient]);
  useEffect(() => { if (matRef.current) applyGradient(matRef.current, gradient, bbox, creamAlbedo); }, [gradient, bbox]);
  return (
    <mesh geometry={geometry} rotation={rotation} scale={scale} castShadow={castShadow}
      {...(userData ? { userData } : {})}>
      <meshPhysicalMaterial ref={matRef}
        {...creamMaterialProps(softness, color)}
        emissive={selected ? color : '#000000'}
        emissiveIntensity={selected ? 0.15 : 0}
      />
    </mesh>
  );
}

// Marks a shell the pointer can grab. Read in TWO places, which is why it is a module const rather
// than an inline object: r3f sets it as `mesh.userData`, and CakeCanvas' CAPTURE-phase pointerdown
// raycast reads it to suspend OrbitControls before the orbit listener sees the press. Without that
// second read, pressing a piece would rotate the cake and the drag would never start — the same
// mechanism decorations use via `isStickerHitPlane`.
const PIPING_HANDLE_DATA = { isPipingHandle: true };

// Drag has to travel a few pixels before it counts as a drag rather than a click, or selecting a
// piece would nudge it. Matches the decoration draggables' threshold (5px, compared squared).
const DRAG_SLOP_SQ = 25;

// ── Dragging a single-mode piece around its ring ──────────────────────────────
// A single-mode piece is POSITIONED PARAMETRICALLY — `instances[].angle` in, a world position out of
// ringPositions. So a drag cannot write a position: the next rebuild would overwrite it. It has to
// come back as an angle, which is what angleAtPoint() is for (the tested inverse of both single-mode
// branches). That gives the gesture exactly one degree of freedom, which is also the RIGHT constraint
// — a rim piece belongs on the rim, and dragging it inward onto the top surface would bury it.
//
// Returns a factory: `dragHandler(i)` is the pointerdown handler for the i-th piece. Null when the
// ring isn't in single mode or the host wired no move callback, and Shell then attaches no handler
// and no userData at all — a ring/festoon/wrap keeps its current behaviour untouched.
//
// `canMove` gates the WRITE, not the press, deliberately: a pinned piece must still select when you
// tap it. Gating pointerdown instead would make an unmovable piece unselectable, which is the trap
// the decoration gating already had to avoid.
function useSinglePieceDrag({ active, canMove, onMoveInstance, radius, off, baseY, shape, wall = null }) {
  const { camera, gl } = useThree();
  const plane = useMemo(() => new THREE.Plane(new THREE.Vector3(0, 1, 0), -baseY), [baseY]);
  return useMemo(() => {
    if (!active || !onMoveInstance) return null;
    return (index) => (e) => {
      // No stopPropagation: the ring group's onClick is what selects this piping layer, and that
      // must keep working whether the press turns into a drag or stays a tap.
      const canvas = gl.domElement;
      const start = { x: e.clientX, y: e.clientY };
      let dragged = false;
      function onMove(ev) {
        const dx = ev.clientX - start.x, dy = ev.clientY - start.y;
        if (dx * dx + dy * dy > DRAG_SLOP_SQ) dragged = true;
        if (!dragged || !canMove) return;
        const ray = pointerRay(ev, canvas, camera);
        // A WALL-riding ring (board) hits the tier's own surface, which yields the angle AND the
        // height from one raycast — the pointer stays on the cake, so the piece follows it up and
        // round together. A rim ring has no height, so it keeps the flat plane at its own level.
        const w = wall ? wallHit(ray, wall) : null;
        const hit = w ?? planeHit(ray, plane);
        if (!hit) return;   // missed the cake, or ray parallel to the plane — ignore this frame
        onMoveInstance(
          index,
          angleAtPoint({ x: hit.x, z: hit.z, radius, off, shape }),
          // Tier-LOCAL height (the anchor lives in the same frame as the layer's yOffset). Only sent
          // when the pointer actually met the wall; a miss leaves the piece at the height it had.
          w ? w.y - wall.baseY : null,
        );
      }
      function onUp() {
        canvas.removeEventListener('pointermove', onMove);
        canvas.removeEventListener('pointerup', onUp);
      }
      canvas.addEventListener('pointermove', onMove);
      canvas.addEventListener('pointerup', onUp);
    };
  }, [active, canMove, onMoveInstance, radius, off, shape, camera, gl, plane, wall]);
}

// Where a ray meets the tier WALL, in world space. Round tiers are a cylinder; anything with a
// footprint (sheet, heart, number) is approximated by its bounding box, which is what the existing
// side-element hit test does too — close enough for a fingertip, and the angle is re-derived from
// the hit point by angleAtPoint against the true outline anyway.
// Clamped to the tier's own height band so a drag cannot walk a piece off the top or under the board.
function wallHit(ray, { shape, radius, baseY, height }) {
  const p = isRoundWall(shape)
    ? cylinderHitPoint(ray, radius)
    : boxHit(ray, shape.halfW, shape.halfD);
  if (!p) return null;
  return { x: p.x, z: p.z, y: Math.min(Math.max(p.y, baseY), baseY + height) };
}

// One piping shell: position + facing on the ring, with X/Z tilt and Y-yaw offset baked in.

/* ── One draw call for a whole ring ──────────────────────────────────────────────────────────────
 *
 * A ring is one geometry repeated. It used to be drawn as one <Shell> per position — three
 * Object3Ds each, and because CreamMesh declares its material inline, its OWN MeshPhysicalMaterial.
 * A 48-shell ring was 48 meshes, 48 physical materials and 48 draw calls; a three-tier cake with a
 * rim and a board ring on each was around 288 of each, for one shape repeated.
 *
 * An InstancedMesh is one mesh, one material and one draw call per version, whatever the count. The
 * per-shell placement moves into the instance matrix — see shellMatrix.js, which composes the exact
 * hierarchy this replaces and is tested against it element by element.
 *
 * ⚠️ NOT merged geometry. A merge would also be one draw call and would cost N× the vertices in
 * memory, which is the trade GrassPatch's note warns about ("the warning is about the day somebody
 * merges"). Instancing keeps ONE copy of the geometry and repeats it on the GPU.
 *
 * `alt` is a second InstancedMesh rather than a second material on the first: A and B are different
 * GEOMETRIES, and an instanced draw takes one.
 */
function InstancedShells({ geometry, shellScale, placements, color, softness, gradient, selected, dragHandler = null }) {
  const ref = useRef(null);
  const matRef = useRef(null);
  const bbox = useMemo(() => geomBBox(geometry, gradient), [geometry, gradient]);

  useLayoutEffect(() => {
    const im = ref.current;
    if (!im) return;
    const m = new THREE.Matrix4();
    placements.forEach((p, i) => im.setMatrixAt(i, shellMatrix(p, m)));
    im.instanceMatrix.needsUpdate = true;
    // Instanced meshes do not compute this themselves, and without it the ring is frustum-culled
    // against the bounds of a single shell sitting at the origin — so it vanishes the moment the
    // camera looks away from the middle of the cake.
    im.computeBoundingSphere();
  }, [placements, geometry, shellScale]);

  useEffect(() => { if (matRef.current) applyGradient(matRef.current, gradient, bbox, creamAlbedo); }, [gradient, bbox]);

  return (
    <instancedMesh
      ref={ref}
      // `key` on the count: three.js allocates the instance buffer once, at construction, so a ring
      // that grows (a wider cake, a smaller size) has to be remade rather than resized.
      key={placements.length}
      args={[geometry, undefined, placements.length]}
      castShadow
      {...(dragHandler ? { userData: PIPING_HANDLE_DATA, onPointerDown: dragHandler } : {})}
    >
      <meshPhysicalMaterial ref={matRef}
        {...creamMaterialProps(softness, color)}
        emissive={selected ? color : '#000000'}
        emissiveIntensity={selected ? 0.15 : 0}
      />
    </instancedMesh>
  );
}

// Render every position, alternating between version A and the alternate B per `pattern`
// (a repeating cycle like "AB" or "AAB"). B uses its own geometry, rotation, and a radial/
// height shift relative to A. When B is absent / not active, every shell is A (unchanged).
function renderShells({ positions, A, B, baseRotation, altRotation, altActive, pattern, dRadialB, dYB, color, softness, gradient, selected, dragHandler = null }) {
  const ryA = baseRotation[1] * DEG, meshA = [baseRotation[0] * DEG, 0, baseRotation[2] * DEG];
  const ryB = altRotation[1] * DEG,  meshB = [altRotation[0] * DEG, 0, altRotation[2] * DEG];
  const L = pattern.length || 1;

  // Split the ring by version, keeping each shell's ORIGINAL index alongside it. The index is what
  // a drag writes back through (`instances[i].angle`), and an instanced hit reports a position
  // within its own mesh — so without this an A-shell drag would move whichever B-shell shared its
  // instance number.
  const groups = { A: { ver: A, ry: ryA, mesh: meshA, placements: [], indices: [] },
                   B: { ver: B, ry: ryB, mesh: meshB, placements: [], indices: [] } };
  positions.forEach((u, i) => {
    const isB = altActive && B && pattern[i % L] === 'B';
    const g = isB ? groups.B : groups.A;
    let pos = u.pos;
    if (isB && (dRadialB || dYB)) {
      const [px, , pz] = u.pos;
      const len = Math.hypot(px, pz) || 1;
      pos = [px + (px / len) * dRadialB, u.pos[1] + dYB, pz + (pz / len) * dRadialB];
    }
    g.placements.push({ pos, tq: u.tq, rotY: u.rotY, ryGroup: g.ry, meshRot: g.mesh, shellScale: g.ver.shellScale });
    g.indices.push(i);
  });

  return ['A', 'B'].map(k => {
    const g = groups[k];
    if (!g.ver || !g.placements.length) return null;
    return (
      <InstancedShells key={k} geometry={g.ver.geometry} shellScale={g.ver.shellScale}
        placements={g.placements} color={color} softness={softness} gradient={gradient} selected={selected}
        dragHandler={dragHandler
          ? (e) => { const i = g.indices[e.instanceId ?? 0]; if (i != null) dragHandler(i)(e); }
          : null} />
    );
  });
}

// Render the DECORATION ring ("element" finish): the element's FULL GLB with its REAL materials,
// cloned at each ring position, base-seated on the surface and yawed to face outward. The
// material-preserving counterpart to renderShells (which merges the GLB into one cream geometry).
// Clones are memoised so re-renders are cheap and geometry/materials stay shared across instances.
// (Swag `tq` tilt and per-instance selection tint are intentionally omitted — decorations don't
// swag, and INVARIANTS #5a bans material-tint selection; the ring's card carries selection.)
function DecorationShells({ positions, scene, shellScale, minY, baseRotation = [0, 0, 0], dragHandler = null }) {
  const clones = useMemo(() => {
    if (!scene) return [];
    return positions.map(() => { const c = scene.clone(true); c.scale.setScalar(shellScale); return c; });
  }, [positions, scene, shellScale]);
  const ry = (baseRotation?.[1] ?? 0) * DEG;
  // A decoration keeps its own GLB scene, so there is no CreamMesh to hang PIPING_HANDLE_DATA on —
  // tag the clone's meshes directly, so CakeCanvas' capture-phase raycast suspends orbit for these
  // too. Cleared again when the ring stops being draggable (mode change / capability untick).
  const draggable = !!dragHandler;
  useEffect(() => {
    clones.forEach(c => c.traverse(o => { if (o.isMesh) o.userData.isPipingHandle = draggable || undefined; }));
  }, [clones, draggable]);
  return clones.map((obj, i) => {
    const u = positions[i];
    return (
      <group key={u.key ?? i}
        position={[u.pos[0], u.pos[1] - minY * shellScale, u.pos[2]]}
        rotation={[0, (u.rotY ?? 0) + ry, 0]}
        {...(dragHandler ? { onPointerDown: dragHandler(i) } : {})}>
        <primitive object={obj} />
      </group>
    );
  });
}

// Render the bent-strip festoons (U-shaped swags). Each entry is a pre-bent BufferGeometry
// from buildFestoons(); we just paint them in the ring's colour with the same cream material.
function renderFestoons({ festoonGeos, color, softness, gradient, selected }) {
  return festoonGeos.map((g, i) => (
    <CreamMesh key={i} geometry={g} color={color} softness={softness} gradient={gradient} selected={selected} />
  ));
}

// The tier WALL perimeter a wrap band follows: a circle for round, the rounded-rect for sheet.
// `shape` is the tierShape descriptor (null → round). The band hugs this, lifted by yOffset.
function wallPerimeter(shape, radius) {
  return shape?.kind === 'rect' ? perimeter(shape) : circlePerimeter(radius);
}

// The wall a FESTOON drapes along — one perimeter per closed contour, plus how far off it to sit.
//
// Branching on `isRoundWall`, NOT on `kind === 'rect'`. The old festoon guard asked for rect, which
// silently treated a heart or a number cake as round; surface.js warns about that exact slip on the
// definition of this predicate. Every non-round wall now walks its real outline, and
// `pipingPerimeters` hands back one loop per contour so a swag never bridges the gap between two
// digits of a number cake.
//
// The radial nudge lands differently on the two branches, and deliberately: a circle can simply BE
// bigger, so the offset moves the circle itself and the round path stays arithmetically identical
// to what it always was. A shaped outline is fixed, so there the offset rides along its normal.
function festoonWall(shape, radius, radialOffset) {
  if (!shape || isRoundWall(shape)) return { perims: [circlePerimeter(radius + radialOffset)], outset: 0 };
  return { perims: pipingPerimeters(shape), outset: radialOffset };
}

// How far a band's rendered geometry stands PROUD OF THE WALL, as a radius fraction — what the
// side-clearance resolver needs so a decoration on the wall is pushed out past whatever is already
// piped there.
//
// It has to be measured against the wall, not against the cake AXIS. Distance-from-axis is the same
// thing only on a round tier. On a sheet cake `radius` is the bounding half-extent (the LONG side),
// so a swag hanging on a SHORT face already sits nearer the axis than `radius` — while one running
// out to a corner sits far beyond it, and reported a third of a radius of standoff for a rope a
// couple of millimetres thick. Comparing each axis against that axis's own half-extent gives the
// real, small number. Round is unchanged: there both half-extents are the radius.
function proudOfWall(bb, shape, radius) {
  const halfX = shape?.halfW ?? radius, halfZ = shape?.halfD ?? radius;
  return Math.max(0,
    bb.max.x - halfX, -bb.min.x - halfX,
    bb.max.z - halfZ, -bb.min.z - halfZ) / radius;
}

// Render a single pre-formed RING GLB as ONE band wrapping the wall (no repetition).
function renderWrap({ wrapGeo, color, softness, gradient, selected }) {
  return (
    <CreamMesh geometry={wrapGeo} color={color} softness={softness} gradient={gradient} selected={selected} />
  );
}

// ── Top piping ring — GLB shells hugging the top edge ─────────────────────────
// Mirrors BottomPipingRing's placement model so the rim is driven entirely by
// placement_config (top_rotation / top_radial_offset / top_y_offset / top_flip),
// just anchored at the top edge instead of the base.
//
// Thin wrapper that bails out BEFORE any hooks run when there's no GLB to load
// (e.g. the "piping pattern" style carries no image/model URL). useGLTF(null)
// throws deep in the loader, so the guard has to live above the hook-bearing Impl.
export function TopPipingRing(props) {
  // A drip layer is a procedural ganache ring (no GLB) — dispatch to its own branch BEFORE any
  // useGLTF runs. This is a config-driven branch on the ring entry (like festoon/wrap inside the
  // GLB impl), NOT a per-element-type renderer.
  if (props.drip) return (
    <TopDripRing topY={props.topY} radius={props.radius} color={props.color}
      gloss={props.dripGloss} lengthMul={props.dripLength} flood={props.dripFlood} config={props.dripConfig}
      selected={props.selected} onClick={props.onClick} />
  );
  if (!props.glbPath) return null;
  // SafeGlb, for the same reason the stickers have one: a border whose GLB has been deleted from
  // storage used to throw out of the canvas and take the whole screen with it. Now the rim is
  // simply absent and the cake still draws (the failure is reported — see TextureErrorBoundary).
  return <SafeGlb screen="TopPipingRing"><TopPipingRingImpl {...props} /></SafeGlb>;
}

// ── Top chocolate-drip ring — procedural ganache draped over the rim ──────────
// The drip geometry (web arches + runs) is built from the tier's REAL radius+topY so it scales to any
// tier. The rolled rim bead is a torus the consumer adds with the same material (matching the admin
// drip studio). Customer controls: colour, gloss, length (a multiplier on the authored base run).
export function TopDripRing({ topY, radius, color = '#3a2117', gloss = DRIP_GLOSS_DEFAULT,
  lengthMul = 1, flood = false, config = null, selected = false, onClick }) {
  // ONE derivation of the scaled params + startDrop/lip — shared with the relief sampler (chocolateDrip.js).
  const cfgKey = JSON.stringify(config ?? {});
  const { params, startDrop, lipR, s } = useMemo(
    () => dripRenderParams(config, radius, lengthMul), [cfgKey, radius, lengthMul]);
  const dripsGeo = useMemo(() => buildDripGeometry({ R: radius, topY, startDrop, ...params }), [radius, topY, startDrop, params]);
  const webGeo   = useMemo(() => buildDripWeb({ R: radius, topY, ...params }), [radius, topY, params]);
  const mat = chocolateMaterialProps(gloss, color);
  const emissive = selected ? color : '#000000', emissiveIntensity = selected ? 0.15 : 0;
  const floodH = 0.03 * s;
  return (
    <group onClick={onClick}>
      {/* optional top flood — a thin chocolate pool covering the tier top inside the rim */}
      {flood && (
        <mesh position={[0, topY + floodH / 2, 0]} castShadow>
          <cylinderGeometry args={[radius, radius, floodH, 96]} />
          <meshPhysicalMaterial {...mat} emissive={emissive} emissiveIntensity={emissiveIntensity} />
        </mesh>
      )}
      {/* rolled rim bead at the very edge */}
      <mesh position={[0, topY, 0]} rotation={[Math.PI / 2, 0, 0]} castShadow>
        <torusGeometry args={[radius, lipR, 16, 128]} />
        <meshPhysicalMaterial {...mat} emissive={emissive} emissiveIntensity={emissiveIntensity} />
      </mesh>
      <mesh geometry={webGeo} castShadow>
        <meshPhysicalMaterial {...mat} emissive={emissive} emissiveIntensity={emissiveIntensity} />
      </mesh>
      <mesh geometry={dripsGeo} castShadow>
        <meshPhysicalMaterial {...mat} emissive={emissive} emissiveIntensity={emissiveIntensity} />
      </mesh>
    </group>
  );
}
function TopPipingRingImpl({
  topY, radius, glbPath, color = '#ffffff', sizeFactor = 1,
  softness = PIPING_SOFTNESS_DEFAULT, gradient = null,
  topRotation       = [0, 0, 0],
  extraRadialOffset = 0,
  yOffset           = 0,
  flipTop = false,
  finish = 'cream',
  spacing = 1,
  swagCount = 0, swagDepth = 0, swagTilt = 0.5,
  arrangement = 'ring', instances = null,
  altEnabled = false, altGlbUrl = null, altFlip = false, altRotation = [0, 0, 0],
  altRadialOffset = 0, altYOffset = 0, pattern = 'AB',
  shape = null,
  bend = false, bendRing = false, festoons = 6, bendDepth = 0.4, bendTilt = 0,
  wrap = false, wrapTilt = 0, wrapSize = 1,
  selected = false, onClick,
  canMove = true, onMoveInstance = null,
}) {
  const { scene }          = useGLTF(glbPath);
  const { scene: sceneAlt } = useGLTF(altGlbUrl || glbPath);

  const tr0 = topRotation?.[0] ?? 0, tr2 = topRotation?.[2] ?? 0;
  const A = useMemo(() => finish === 'element'
    ? buildDecorationShell(scene, radius, sizeFactor)
    : buildShellGeo(scene, flipTop, radius, sizeFactor, [tr0, 0, tr2]),
    [finish, scene, flipTop, radius, sizeFactor, tr0, tr2]);
  const B = useMemo(() => (altEnabled ? buildShellGeo(sceneAlt, altFlip, radius, sizeFactor) : null),
    [altEnabled, sceneAlt, altFlip, radius, sizeFactor]);

  // Publish this rim shell's exact post-tilt radial reach (relative to the rim edge, as radius
  // fractions) so the editor's radial control stops the ring precisely when its outer/inner edge
  // touches a neighbouring ring or the rim — matching the rendered pixels, not the raw bbox.
  useEffect(() => {
    if (A && glbPath && radius) {
      const halfRaw = (A.bbDepth * A.shellScale) / 2;   // the render's positioning `half`
      // `outerFrac` = how far the shell's OUTER face stands proud of the wall (radius fraction),
      // INCLUDING its radial positioning — the reach a side decoration must clear. A rim shell is
      // pulled inward (outer face ≤ edge) so this is ~0; a side/board shell projects out by ~its
      // full depth. (radialOutFrac is reach-beyond-centre, for ring de-overlap — a different frame.)
      const off = Math.min(-seatHalfDepth(A.bbDepth * A.shellScale) + extraRadialOffset, -seatHalfDepth(A.bbDepth * A.shellScale));
      setShellExtents(glbPath, flipTop, sizeFactor, {
        topFrac: A.worldTopY / radius, botFrac: A.worldBotY / radius,
        radialOutFrac: (A.worldMaxZ - halfRaw) / radius,
        radialInFrac:  (A.worldMinZ - halfRaw) / radius,
        outerFrac: Math.max(0, (off + A.worldMaxZ) / radius),
      });
    }
  }, [A, glbPath, flipTop, sizeFactor, radius, extraRadialOffset]);

  const altActive = altEnabled && arrangement !== 'single';

  // Rim sits ON the top surface: pull shells inward so their outer face is flush with the edge.
  // extraRadialOffset (incl. the user's radial control) may pull the cream inward, but never push it
  // past the edge — clamp the outer face to the rim.
  // Hoisted out of `positions` because the DRAG needs it too: angleAtPoint has to offset the sampled
  // outline by exactly the same amount the forward pass did, or a dragged piece on a shaped tier
  // lands on the angle of a slightly different outline than the one it is drawn on.
  const off = useMemo(() => {
    if (!A) return 0;
    const half = seatHalfDepth(A.bbDepth * A.shellScale);   // half the shell's measured depth (shared seat rule)
    let   o    = Math.min(-half + extraRadialOffset, -half);   // outer face ≤ cake edge
    // Glyph: never inset deeper than a fraction of the stroke, or the border collapses to the centreline.
    if (shape?.strokeW) o = Math.max(o, -GLYPH_PIPE_INSET_FRAC * shape.strokeW);
    return o;
  }, [A, extraRadialOffset, shape]);

  const positions = useMemo(() => {
    if (!A) return [];
    return ringPositions({
      A, radius, off, baseY: topY + yOffset,
      spacing, swagCount, swagDepth, swagTilt, arrangement, instances, altActive, pattern, shape,
    });
  }, [A, radius, topY, yOffset, off, spacing, swagCount, swagDepth, swagTilt, arrangement, instances, altActive, pattern, shape]);

  // Only single mode is draggable: a ring/swag/festoon/wrap has no per-piece angle to write to.
  const dragHandler = useSinglePieceDrag({
    active: arrangement === 'single' && !wrap && !bend,
    canMove, onMoveInstance, radius, off, baseY: topY + yOffset, shape,
  });

  // U-shaped (bend) elements: bend the whole strip into festoons draped from the rim edge,
  // instead of repeating a discrete shell. ANY shape — the swag follows the wall's perimeter, and
  // a circle is just the perimeter a round cake happens to have.
  const festoonGeos = useMemo(() => {
    if (!bend || !scene) return null;
    // flip:false to match the calibrator's bend preview, which always bends the un-flipped
    // strip (the flip toggle/bottom_flip applies to discrete shells, not festoons).
    // The cross-section scales with radius via the calibrated span; scale the absolute drop
    // (bendDepth, tuned at the standard tier radius) by the same ratio so the whole swag
    // shrinks to fit a smaller tier instead of dropping a fixed amount.
    const { perims, outset } = festoonWall(shape, radius, extraRadialOffset);
    return buildFestoons(scene, {
      flip: false, festoons, depth: bendDepth * (radius / TIER_RADII[0]), tilt: bendTilt * DEG,
      attachY: topY + yOffset, perims, outset, radius: radius + extraRadialOffset,
      spread: bendRing ? 1.0 : 0.96, sizeFactor,
    });
  }, [bend, scene, shape, festoons, bendDepth, bendTilt, topY, yOffset, radius, extraRadialOffset, bendRing, sizeFactor]);

  // Wrap elements: a pre-formed ring re-routed onto the tier wall as ONE band (round or rect).
  const wrapGeo = useMemo(() => {
    if (!wrap || !scene) return null;
    return buildWrapBand(scene, {
      perim: wallPerimeter(shape, radius), anchorY: topY + yOffset,
      heightFrac: PIPING_WRAP_HEIGHT_FRAC, sizeFactor: sizeFactor * wrapSize, radius,
      outset: 0.01 + extraRadialOffset, tilt: wrapTilt * DEG,
    });
  }, [wrap, scene, shape, radius, topY, yOffset, sizeFactor, wrapSize, extraRadialOffset, wrapTilt]);

  if (!A && !festoonGeos && !wrapGeo) return null;

  return (
    <group onClick={onClick}>
      {finish === 'element'
        ? <DecorationShells positions={positions} scene={scene} shellScale={A.shellScale} minY={A.minY} baseRotation={topRotation} dragHandler={dragHandler} />
        : wrapGeo
        ? renderWrap({ wrapGeo, color, softness, gradient, selected })
        : festoonGeos
        ? renderFestoons({ festoonGeos, color, softness, gradient, selected })
        : renderShells({
            positions, A, B, baseRotation: topRotation, altRotation, altActive, pattern,
            dRadialB: altRadialOffset - extraRadialOffset, dYB: altYOffset - yOffset,
            color, softness, gradient, selected, dragHandler,
          })}
    </group>
  );
}

// ── Bottom piping ring — GLB shells hugging the cake base ─────────────────────
// Thin wrapper that bails out BEFORE any hooks run when there's no GLB to load
// (e.g. the "piping pattern" style carries no image/model URL). useGLTF(null)
// throws deep in the loader, so the guard has to live above the hook-bearing Impl.
export function BottomPipingRing(props) {
  if (!props.glbPath) return null;
  return <SafeGlb screen="BottomPipingRing"><BottomPipingRingImpl {...props} /></SafeGlb>;
}
function BottomPipingRingImpl({
  yBase, radius, glbPath, color = '#f5e6c8', sizeFactor = 1, tierHeight = 0,
  softness = PIPING_SOFTNESS_DEFAULT, gradient = null,
  bottomRotation    = [0, 0, 0],
  extraRadialOffset = 0,
  yOffset           = 0,
  flipBottom = true,
  finish = 'cream',
  spacing = 1,
  swagCount = 0, swagDepth = 0, swagTilt = 0.5,
  arrangement = 'ring', instances = null,
  altEnabled = false, altGlbUrl = null, altFlip = false, altRotation = [0, 0, 0],
  altRadialOffset = 0, altYOffset = 0, pattern = 'AB',
  shape = null,
  bend = false, bendRing = false, festoons = 6, bendDepth = 0.4, bendTilt = 0,
  wrap = false, wrapTilt = 0, wrapSize = 1,
  selected = false, onClick,
  canMove = true, onMoveInstance = null,
}) {
  const { scene }          = useGLTF(glbPath);
  const { scene: sceneAlt } = useGLTF(altGlbUrl || glbPath);

  const br0 = bottomRotation?.[0] ?? 0, br2 = bottomRotation?.[2] ?? 0;
  const A = useMemo(() => finish === 'element'
    ? buildDecorationShell(scene, radius, sizeFactor)
    : buildShellGeo(scene, flipBottom, radius, sizeFactor, [br0, 0, br2]),
    [finish, scene, flipBottom, radius, sizeFactor, br0, br2]);
  const B = useMemo(() => (altEnabled ? buildShellGeo(sceneAlt, altFlip, radius, sizeFactor) : null),
    [altEnabled, sceneAlt, altFlip, radius, sizeFactor]);

  // Publish this shell's exact rendered extents (as radius fractions) for the editor's clamps:
  // vertical reach for the Height clamp, post-tilt radial reach for the radial clamp — so the
  // contact tests are precise instead of guessed.
  useEffect(() => {
    if (A && glbPath && radius) {
      const halfRaw = (A.bbDepth * A.shellScale) / 2;
      // Outer-face reach INCLUDING positioning (see the top-ring note). A side/board shell's inner
      // face sits on the wall (off = half + radial nudge), so it projects out by ~its full depth.
      const off = halfRaw + Math.min(extraRadialOffset, radius * PIPING_RADIAL_PLAY);
      setShellExtents(glbPath, flipBottom, sizeFactor, {
        topFrac: A.worldTopY / radius, botFrac: A.worldBotY / radius,
        radialOutFrac: (A.worldMaxZ - halfRaw) / radius,
        radialInFrac:  (A.worldMinZ - halfRaw) / radius,
        outerFrac: Math.max(0, (off + A.worldMaxZ) / radius),
      });
    }
  }, [A, glbPath, flipBottom, sizeFactor, radius, extraRadialOffset]);

  const altActive = altEnabled && arrangement !== 'single';

  // Board: inner face sits on the wall by default, so growing the size pushes the cream OUTWARD (and
  // up), never into the cake. The radial control (extraRadialOffset) shifts it in/out; outward travel
  // is capped at PIPING_RADIAL_PLAY of the radius so the border stays attached rather than drifting
  // onto the board. Inward travel is unrestricted.
  // Hoisted for the drag — see the matching note on the top ring.
  const off = useMemo(() => {
    if (!A) return 0;
    const half = (A.bbDepth / 2) * A.shellScale;
    let   o    = half + Math.min(extraRadialOffset, radius * PIPING_RADIAL_PLAY);
    // Glyph: keep the outset within the stroke so the base border hugs the edge (see top ring).
    if (shape?.strokeW) o = Math.min(o, GLYPH_PIPE_INSET_FRAC * shape.strokeW);
    return o;
  }, [A, extraRadialOffset, radius, shape]);

  const positions = useMemo(() => {
    if (!A) return [];
    return ringPositions({
      A, radius, off, baseY: yBase + yOffset,
      spacing, swagCount, swagDepth, swagTilt, arrangement, instances, altActive, pattern, shape,
    });
  }, [A, radius, yBase, yOffset, off, spacing, swagCount, swagDepth, swagTilt, arrangement, instances, altActive, pattern, shape]);

  // A board piece rides the WALL, so its drag gets the tier surface to hit — that is what carries
  // the height as well as the angle. Memoised because the hook keys its handler on it.
  const wall = useMemo(
    () => (tierHeight > 0 ? { shape, radius, baseY: yBase, height: tierHeight } : null),
    [shape, radius, yBase, tierHeight],
  );

  // Only single mode is draggable — see the top ring.
  const dragHandler = useSinglePieceDrag({
    active: arrangement === 'single' && !wrap && !bend,
    canMove, onMoveInstance, radius, off, baseY: yBase + yOffset, shape, wall,
  });

  // U-shaped (bend) elements: bend the whole strip into festoons draped on the wall from the
  // base, instead of repeating a discrete shell. Any shape — see the rim ring's twin above.
  const festoonGeos = useMemo(() => {
    if (!bend || !scene) return null;
    // flip:false to match the calibrator's bend preview, which always bends the un-flipped
    // strip (the flip toggle/bottom_flip applies to discrete shells, not festoons).
    // The cross-section scales with radius via the calibrated span; scale the absolute drop
    // (bendDepth, tuned at the standard tier radius) by the same ratio so the whole swag
    // shrinks to fit a smaller tier instead of dropping a fixed amount.
    const { perims, outset } = festoonWall(shape, radius, extraRadialOffset);
    return buildFestoons(scene, {
      flip: false, festoons, depth: bendDepth * (radius / TIER_RADII[0]), tilt: bendTilt * DEG,
      attachY: yBase + yOffset, perims, outset, radius: radius + extraRadialOffset,
      spread: bendRing ? 1.0 : 0.96, sizeFactor,
    });
  }, [bend, scene, shape, festoons, bendDepth, bendTilt, yBase, yOffset, radius, extraRadialOffset, bendRing, sizeFactor]);

  // Publish the swag's TRUE vertical reach (its bent bounding box, as radius fractions) so the
  // editor can lift it to rest its actual cream — not the centreline — on the border below it.
  // attachY is baked into the geometry, so reaches are measured relative to it.
  useEffect(() => {
    if (!festoonGeos?.length || !radius) return;
    const anchorY = yBase + yOffset;
    let minY = Infinity, maxY = -Infinity, proud = 0;
    festoonGeos.forEach(g => {
      g.computeBoundingBox?.();
      if (g.boundingBox) {
        const bb = g.boundingBox;
        minY = Math.min(minY, bb.min.y); maxY = Math.max(maxY, bb.max.y);
        proud = Math.max(proud, proudOfWall(bb, shape, radius));
      }
    });
    if (minY < maxY) setFestoonExtents(glbPath, festoonSig({ size: sizeFactor, bendDepth, festoons, bendRing, bendTilt }), {
      bellyFrac: (anchorY - minY) / radius, topFrac: (maxY - anchorY) / radius,
      outerFrac: proud,
    });
  }, [festoonGeos, yBase, yOffset, radius, shape, glbPath, sizeFactor, bendDepth, festoons, bendRing, bendTilt]);

  // Wrap elements: a pre-formed ring re-routed onto the tier wall as ONE band (round or rect),
  // riding up the wall by yOffset. Hugs the wall whatever the cake size or shape.
  const wrapGeo = useMemo(() => {
    if (!wrap || !scene) return null;
    return buildWrapBand(scene, {
      perim: wallPerimeter(shape, radius), anchorY: yBase + yOffset,
      heightFrac: PIPING_WRAP_HEIGHT_FRAC, sizeFactor: sizeFactor * wrapSize, radius,
      outset: 0.01 + extraRadialOffset, tilt: wrapTilt * DEG,
    });
  }, [wrap, scene, shape, radius, yBase, yOffset, sizeFactor, wrapSize, extraRadialOffset, wrapTilt]);

  // Publish the wrap band's rendered extents (vertical reach relative to its anchor + outward reach),
  // as radius fractions, so the side-clearance resolver treats it like any other band.
  useEffect(() => {
    if (!wrapGeo || !radius) return;   // buildWrapBand returns the BufferGeometry directly
    wrapGeo.computeBoundingBox?.();
    const bb = wrapGeo.boundingBox;
    if (!bb) return;
    const anchorY = yBase + yOffset;
    setWrapExtents(glbPath, sizeFactor, {
      topFrac: (bb.max.y - anchorY) / radius, botFrac: (bb.min.y - anchorY) / radius,
      // Same wall-relative measure as the festoon above. A wrap band already followed the
      // rounded-rect on a sheet cake, so it was already over-reporting its standoff there.
      outerFrac: proudOfWall(bb, shape, radius),
    });
  }, [wrapGeo, radius, shape, yBase, yOffset, glbPath, sizeFactor]);

  if (!A && !festoonGeos && !wrapGeo) return null;

  return (
    <group onClick={onClick}>
      {finish === 'element'
        ? <DecorationShells positions={positions} scene={scene} shellScale={A.shellScale} minY={A.minY} baseRotation={bottomRotation} dragHandler={dragHandler} />
        : wrapGeo
        ? renderWrap({ wrapGeo, color, softness, gradient, selected })
        : festoonGeos
        ? renderFestoons({ festoonGeos, color, softness, gradient, selected })
        : renderShells({
            positions, A, B, baseRotation: bottomRotation, altRotation, altActive, pattern,
            dRadialB: altRadialOffset - extraRadialOffset, dYB: altYOffset - yOffset,
            color, softness, gradient, selected, dragHandler,
          })}
    </group>
  );
}

// ── Piped rosette — spiral TubeGeometry ──────────────────────────────────────
function PipedRosette({ position, color, scale = 1 }) {
  const geometry = useMemo(() => {
    const points = [];
    const loops = 2.6;
    const steps = 72;
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      const angle = t * loops * Math.PI * 2;
      const r = (1 - t * 0.68) * 0.13 * scale;
      const y = t * 0.10 * scale;
      points.push(new THREE.Vector3(Math.cos(angle) * r, y, Math.sin(angle) * r));
    }
    return new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points), 72, 0.022 * scale, 7, false);
  }, [scale]);

  return (
    <mesh geometry={geometry} position={position} castShadow>
      <meshStandardMaterial color={color} roughness={0.62} />
    </mesh>
  );
}

function PipedTop({ topY, radius, color }) {
  const spots = useMemo(() => {
    const ringR = radius * 0.6;
    const count = Math.max(5, Math.round(radius * 5.5));
    const result = [{ x: 0, z: 0, scale: 1.0 }];
    for (let i = 0; i < count; i++) {
      const angle = (i / count) * Math.PI * 2;
      result.push({ x: Math.cos(angle) * ringR, z: Math.sin(angle) * ringR, scale: 0.76 });
    }
    return result;
  }, [radius]);

  return (
    <group>
      {spots.map((s, i) => (
        <PipedRosette key={i} position={[s.x, topY + 0.01, s.z]} color={color} scale={s.scale} />
      ))}
    </group>
  );
}

const SPONGE_COLORS = {
  vanilla:      '#f0d98a',
  chocolate:    '#4a2210',
  redvelvet:    '#8b1a1a',
  butterscotch: '#c8860a',
};

function NakedLayers({ shp, yBase, height, flavour }) {
  const spongeColor = SPONGE_COLORS[flavour] || '#f0d98a';
  const layers  = 3;
  const spongeH = (height * 0.62) / layers;
  const creamH  = (height * 0.38) / (layers - 1);

  const stack = [];
  let y = yBase;
  for (let i = 0; i < layers; i++) {
    stack.push({ y, h: spongeH, color: spongeColor, rough: 0.88 });
    y += spongeH;
    if (i < layers - 1) {
      stack.push({ y, h: creamH, color: '#fffdf5', rough: 0.50 });
      y += creamH;
    }
  }

  // An outline tier's sponge is the OUTLINE extruded, one prism per layer — a bounding box would poke
  // out through a heart's cleft and its lobes. Built once per (shape, layer heights) and disposed with
  // them: these are real GPU buffers, not JSX.
  const outlineGeos = useMemo(
    () => (shp.kind === 'outline' ? stack.map(l => buildOutlinePrism(shp.outline, l.h)) : null),
    [shp, spongeH, creamH],   // eslint-disable-line react-hooks/exhaustive-deps -- `stack` is derived from these
  );
  useEffect(() => () => outlineGeos?.forEach(g => g.dispose()), [outlineGeos]);

  return (
    <group>
      {stack.map((layer, i) => (
        <mesh key={i} castShadow receiveShadow
          position={[0, outlineGeos ? layer.y : layer.y + layer.h / 2, 0]}>
          {outlineGeos
            ? <primitive key={outlineGeos[i].uuid} object={outlineGeos[i]} attach="geometry" />
            : shp.kind === 'rect'
              ? <boxGeometry args={[shp.halfW * 2, layer.h, shp.halfD * 2]} />
              : <cylinderGeometry args={[shp.radius, shp.radius, layer.h, 64]} />}
          <meshStandardMaterial color={layer.color} roughness={layer.rough} />
        </mesh>
      ))}
    </group>
  );
}

// Per frosting TYPE (material) — distinct, realistic physical-material descriptors. The three
// Frosting material descriptors, edge profiles and capabilities are DATA in the frostings registry.
// Here we resolve only the part that must be code: the `grain` KEY → a normal-map generator.
const GRAIN_GENERATORS = {
  cream:   getCreamGrainNormalMap,
  foam:    getWhippedFoamNormalMap,
  fondant: getFondantNormalMap,
};

// Tiling micro-grain normal map for the wall, cloned per (grain, repeat) so each material owns its
// own wrap/repeat without mutating the shared cached texture. `aroundLen`/`upLen` are the wall's
// world extents so the grain cell stays a constant physical size across tier sizes.
const GRAIN_TILES_PER_UNIT = 16;
const _grainCache = new Map();
function grainNormalMap(grain, aroundLen, upLen, density = 1) {
  const rx = Math.max(4, Math.round(aroundLen * GRAIN_TILES_PER_UNIT * density));
  const ry = Math.max(3, Math.round(upLen   * GRAIN_TILES_PER_UNIT * density));
  const key = `${grain}:${rx}:${ry}`;
  if (_grainCache.has(key)) return _grainCache.get(key);
  const base = (GRAIN_GENERATORS[grain] ?? getCreamGrainNormalMap)();
  const tex = base.clone();
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(rx, ry);
  tex.needsUpdate = true;
  _grainCache.set(key, tex);
  return tex;
}

// Style surface normal maps (the data↔code seam for normal-map finishes like rustic). Cloned + tiled
// per (key, repeat) so each tier owns its wrap/repeat. `density` (from the style's scale param) tiles
// the stroke pattern more/less finely; tiles scale with the wall extent for a constant physical size.
// Each finish: how to TILE its normal map across the wall, a SIG of the params that change the bake
// (so the cache rebuilds only when needed), and the BUILD. Registry-driven — a new normal-map finish
// is one entry, no render-path branching. Weave tiles by `weaveTiles` (the SAME count its real-relief
// displacement uses) so the baked lines land exactly on the displaced grooves instead of ghosting.
const SURFACE_MAP_GENERATORS = {
  rustic: {
    tiles: ({ aroundLen, upLen, density }) =>
      [Math.max(1, Math.round(aroundLen * 0.9 * density)), Math.max(1, Math.round(upLen * 1.3 * density))],
    sig: () => 'rustic',
    build: () => getRusticNormalMap(),
  },
  weave: {
    tiles: ({ radius, height, params }) => { const { around, up } = weaveTiles(radius, height, params.tile ?? 0.8); return [around, up]; },
    sig: ({ params }) => `weave:${params.grooves ?? 5}:${params.width ?? 0.5}:${params.border ?? 0}:${params.grain ?? 0.12}`,
    build: ({ params }) => getWeaveNormalMap({ grooves: params.grooves ?? 5, width: params.width ?? 0.5, border: params.border ?? 0, grain: params.grain ?? 0.12 }),
  },
};
function surfaceNormalMap(key, ctx) {
  const def = SURFACE_MAP_GENERATORS[key];
  if (!def) return null;
  const [rx, ry] = def.tiles(ctx);
  const cacheKey = `surf:${def.sig(ctx)}:${rx}:${ry}`;
  if (_grainCache.has(cacheKey)) return _grainCache.get(cacheKey);
  const tex = def.build(ctx).clone();
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(rx, ry);
  tex.needsUpdate = true;
  _grainCache.set(cacheKey, tex);
  return tex;
}

// Cake body for a sheet cake: a rounded-RECTANGLE cross-section extruded straight up.
// Only the 4 vertical corners are rounded (radius r); the top and bottom stay flat and the
// footprint keeps its full width×depth — unlike drei RoundedBox, which rounds every edge
// (pillowing the top and shrinking the faces). Spans y ∈ [0, height]. cr=0 → sharp box.
export function buildRoundedPrism(halfW, halfD, height, r) {
  const cr = Math.max(0, Math.min(r, halfW, halfD));
  const s = new THREE.Shape();
  s.moveTo(-halfW + cr, -halfD);
  s.lineTo(halfW - cr, -halfD);
  s.quadraticCurveTo(halfW, -halfD, halfW, -halfD + cr);
  s.lineTo(halfW, halfD - cr);
  s.quadraticCurveTo(halfW, halfD, halfW - cr, halfD);
  s.lineTo(-halfW + cr, halfD);
  s.quadraticCurveTo(-halfW, halfD, -halfW, halfD - cr);
  s.lineTo(-halfW, -halfD + cr);
  s.quadraticCurveTo(-halfW, -halfD, -halfW + cr, -halfD);
  const geo = new THREE.ExtrudeGeometry(s, { depth: height, bevelEnabled: false, curveSegments: 8 });
  geo.rotateX(-Math.PI / 2);   // extrusion axis (Z) → world Y (up)
  return geo;
}

// Cake body for a GLYPH cake (number OR letter): the glyph(s) — THREE.Shape[] with their counters
// attached — extruded straight up, exactly like the sheet's rounded rect. ExtrudeGeometry honours each
// shape's `.holes`, so the counter in 0/4/6/8/9 and A/B/D/O/P/Q/R comes through, and it merges a
// multi-glyph array ("21", "MOM") into one body. Charset-agnostic — one builder for both families.
export function buildGlyphPrism(shapes, height) {
  const geo = new THREE.ExtrudeGeometry(shapes, { depth: height, bevelEnabled: false, curveSegments: 8 });
  geo.rotateX(-Math.PI / 2);   // extrusion axis (Z) → world Y (up)
  return geo;
}

// Cake body for ANY authored footprint (heart, butterfly, hexagon…): the shape's own outline swept up,
// with the top edge rolled over by `fillet` — the same rounded rim the round path gets from the
// frosting's `edge: {kind:'round'}` (that is where the fillet comes from; it is not a per-shape knob).
//
// Built by hand rather than with THREE.ExtrudeGeometry, for two reasons that both showed up on a cake:
//   • UVs. ExtrudeGeometry derives side-wall UVs from WORLD coordinates, not an unwrap, so the
//     buttercream grain landed in overlapping patches — one of which read as a shiny rectangular strip
//     down the wall. Here `u` is ARC LENGTH around the outline and `v` is height: the honest unwrap, and
//     the same coordinate side-decor placement uses.
//   • Normals. Each wall segment is its own quad with its own outward normal, so a hexagon keeps crisp
//     corners while a 160-segment heart still reads smooth. Averaging normals around the ring (what
//     computeVertexNormals would do) would round a hexagon's corners off.
export function buildOutlinePrism(outline, height, fillet = 0) {
  const n = outline.length;
  const f = Math.max(0, Math.min(fillet, height * 0.45));
  const STEPS = f > 1e-4 ? 6 : 0;               // quarter-arc segments in the rolled rim

  // Each ring is the outline inset by `inset`, sitting at `y`, with its wall normal tilted by `slope`
  // (0 = vertical wall, π/2 = facing straight up at the top of the roll).
  const rings = [{ inset: 0, y: 0, slope: 0 }, { inset: 0, y: height - f, slope: 0 }];
  for (let i = 1; i <= STEPS; i++) {
    const a = (i / STEPS) * (Math.PI / 2);
    rings.push({ inset: f * (1 - Math.cos(a)), y: height - f + f * Math.sin(a), slope: a });
  }
  const ringPts = rings.map(r => (r.inset > 1e-6 ? insetPolygon(outline, r.inset) : outline));

  // Arc length around the base outline → the wall's u.
  const uAt = [0];
  for (let i = 0; i < n; i++) {
    const a = outline[i], b = outline[(i + 1) % n];
    uAt.push(uAt[i] + Math.hypot(b.x - a.x, b.z - a.z));
  }
  const perim = uAt[n] || 1;

  const pos = [], nor = [], uv = [];
  const push = (p, y, nx, ny, nz, u, v) => {
    pos.push(p.x, y, p.z); nor.push(nx, ny, nz); uv.push(u, v);
  };

  // ── Wall + rolled rim: one quad per (segment × ring gap) ─────────────────────
  for (let i = 0; i < n; i++) {
    const j = (i + 1) % n;
    const a = outline[i], b = outline[j];
    const dx = b.x - a.x, dz = b.z - a.z;
    const len = Math.hypot(dx, dz) || 1;
    const nx = dz / len, nz = -dx / len;                 // outward normal of THIS segment (CCW winding)
    const u0 = uAt[i] / perim, u1 = uAt[i + 1] / perim;

    for (let r = 0; r < rings.length - 1; r++) {
      const lo = rings[r], hi = rings[r + 1];
      const lp = ringPts[r], hp = ringPts[r + 1];
      const cl = Math.cos(lo.slope), sl = Math.sin(lo.slope);
      const ch = Math.cos(hi.slope), sh = Math.sin(hi.slope);
      const vl = lo.y / height, vh = hi.y / height;

      // Two triangles: (lo_i, hi_j, lo_j) and (lo_i, hi_i, hi_j).
      //
      // The vertex ORDER is what the GPU culls on — the `normal` attribute above only lights the face,
      // it cannot make a back-facing triangle visible. The outline is wound CCW in the (x, z) plane, and
      // sweeping that order upward produces triangles whose winding normal points INWARD: the body was
      // built inside-out, so FrontSide culling removed every near face and you saw through the cake to
      // the inner surface of the far wall. Walking the quad the other way round puts the winding where
      // the normals always claimed it was.
      push(lp[i], lo.y, nx * cl, sl, nz * cl, u0, vl);
      push(hp[j], hi.y, nx * ch, sh, nz * ch, u1, vh);
      push(lp[j], lo.y, nx * cl, sl, nz * cl, u1, vl);

      push(lp[i], lo.y, nx * cl, sl, nz * cl, u0, vl);
      push(hp[i], hi.y, nx * ch, sh, nz * ch, u0, vh);
      push(hp[j], hi.y, nx * ch, sh, nz * ch, u1, vh);
    }
  }

  // ── Caps ─────────────────────────────────────────────────────────────────────
  // Own vertices, own flat normals — sharing them with the wall would average the two and bevel the
  // silhouette. The top cap is the innermost ring (the rim has already rolled inward by `f`).
  const cap = (pts, y, up) => {
    const contour = pts.map(p => new THREE.Vector2(p.x, p.z));
    const faces = THREE.ShapeUtils.triangulateShape(contour, []);
    const ny = up ? 1 : -1;
    for (const t of faces) {
      // triangulateShape winds CCW in the flat (x, z) contour it was handed; laid back into a y-up world
      // that faces DOWN, so it is the TOP cap that needs reversing and the base that takes it as-is. The
      // reverse of this was the same inside-out error the wall had: the lid faced into the cake.
      const tri = up ? [t[0], t[2], t[1]] : t;
      for (const k of tri) {
        const p = pts[k];
        push(p, y, 0, ny, 0, 0.5 + p.x * 0.5, 0.5 + p.z * 0.5);
      }
    }
  };
  cap(ringPts[ringPts.length - 1], height, true);
  cap(outline, 0, false);

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  geo.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  geo.computeBoundingSphere();
  return geo;
}

// The outline pulled INWARD by `d`, each vertex moving along the bisector of its two edge normals. Used
// for the rolled rim. A true polygon offset would also dissolve edges that collapse — but `d` here is a
// rim fillet (a few percent of the cake), so a bisector step is exact enough and cannot self-intersect
// at that scale.
function insetPolygon(pts, d) {
  const n = pts.length;
  const seg = [];
  for (let i = 0; i < n; i++) {
    const a = pts[i], b = pts[(i + 1) % n];
    const dx = b.x - a.x, dz = b.z - a.z;
    const len = Math.hypot(dx, dz) || 1;
    seg.push({ nx: dz / len, nz: -dx / len });           // outward
  }
  return pts.map((p, i) => {
    const prev = seg[(i - 1 + n) % n], next = seg[i];
    const sx = prev.nx + next.nx, sz = prev.nz + next.nz;
    const len = Math.hypot(sx, sz);
    // A near-cusp: the two edge normals oppose, so there IS no inward direction. Leave the vertex where
    // it is rather than sending it somewhere arbitrary — an arbitrary answer is what crossed the rim
    // over itself and left an X on the cake. (Outlines round their own cusps; this is the backstop.)
    if (len < 0.2) return { ...p };
    const nx = sx / len, nz = sz / len;
    // Step along the bisector far enough that both EDGES move in by d (1/cos of the half-angle), capped
    // so a sharp corner can't shoot the vertex across the shape.
    const cos = Math.max(0.5, nx * next.nx + nz * next.nz);
    return { x: p.x - nx * (d / cos), z: p.z - nz * (d / cos) };
  });
}

// Fondant-draped ROUND tier: a solid of revolution whose top edge is a rounded fillet (the fondant
// sheet folds over the rim instead of a sharp 90° tin edge). Profile is revolved around Y, spanning
// y ∈ [0, height]: flat bottom disk → straight wall → quarter-arc top edge → flat top disk. `fillet`
// is the edge radius in world units. Replaces the cylinder+lid for round fondant tiers; the single
// mesh means the vertical gradient and grain flow over the rounded edge with no separate cap.
function buildRoundedTopCylinder(radius, height, fillet, radial = 64) {
  const r = Math.max(0, Math.min(fillet, radius * 0.9, height * 0.5));
  const pts = [
    new THREE.Vector2(0, 0),               // bottom centre (closes the base)
    new THREE.Vector2(radius, 0),          // bottom outer edge
    new THREE.Vector2(radius, height - r), // up the wall to where the fillet starts
  ];
  const ARC = 10;
  for (let i = 1; i <= ARC; i++) {         // quarter-arc rim, centre (radius−r, height−r)
    const a = (i / ARC) * (Math.PI / 2);
    pts.push(new THREE.Vector2((radius - r) + r * Math.cos(a), (height - r) + r * Math.sin(a)));
  }
  pts.push(new THREE.Vector2(0, height));  // top centre (closes the top)
  return new THREE.LatheGeometry(pts, radial);
}

// ── Selection outline ─────────────────────────────────────────────────────────
function SelectionOutline({ shp, yBase, height }) {
  const geometry = useMemo(() => {
    // Round → a cylinder cage; every other footprint → its bounding box. The cue traces the tier's
    // EXTENT, not its silhouette (same rule as the decoration SelectionBox), so an outline shape needs
    // no case of its own — but it must not fall into the round branch, where `radius` is undefined.
    const base = shp.kind === 'round'
      ? new THREE.CylinderGeometry(shp.radius + 0.05, shp.radius + 0.05, height + 0.05, 20)
      : new THREE.BoxGeometry(shp.halfW * 2 + 0.05, height + 0.05, shp.halfD * 2 + 0.05);
    return new THREE.EdgesGeometry(base);
  }, [shp, height]);

  return (
    <lineSegments position={[0, yBase + height / 2, 0]} geometry={geometry}>
      <lineBasicMaterial color={SELECTION_COLOR} linewidth={2} />
    </lineSegments>
  );
}

// Cake-body mesh whose material carries the optional tier gradient. Mirrors CreamMesh: a ref'd
// MeshStandardMaterial driven through the ONE shared `applyGradient` helper off the geometry's
// LOCAL bounding box, so the ombre blends in the body's own frame (bottom→top for vertical) and
// there is no tier-specific shader. `gradient` null ⇒ plain solid colour, exactly as before.
// `geoSig` changes whenever the geometry's size changes (tier resize) so the bbox is recomputed.
// `surf` = a frosting material descriptor (roughness/sheen/clearcoat/grain…). `grainExtent` = [aroundLen,
// upLen] world extents of the wall so the micro-grain tiles at a constant physical size. The material
// is MeshPhysical so sheen + clearcoat read; applyGradient is documented to leave those untouched.
// `overrideNormalMap` (with `overrideNormalScale`) lets a normal-map STYLE (rustic) replace the type's
// cream grain on this tier — the surface texture then comes from the style, not the type's material.
function TierBody({ position, color, surf, grainExtent, overrideNormalMap = null, overrideNormalScale = 1,
                    gradient, stripes = null, glaze = null, geoSig, dusting = null, foil = null, finishMaps = null, children, castShadow = true, receiveShadow = false }) {
  const meshRef = useRef();
  const matRef  = useRef();
  const finishOnRef = useRef(false);
  const grainMap = useMemo(
    () => (surf?.grain && grainExtent ? grainNormalMap(surf.grain, grainExtent[0], grainExtent[1], surf.grainDensity) : null),
    [surf?.grain, grainExtent?.[0], grainExtent?.[1], surf?.grainDensity],
  );
  const normalMap = overrideNormalMap ?? grainMap;
  const normalScale = overrideNormalMap ? overrideNormalScale : (surf?.grainStrength ?? 0.5);
  useEffect(() => {
    if (!matRef.current) return;
    let bb = null;
    const geo = meshRef.current?.geometry;
    if ((gradient || stripes || glaze) && geo) {
      if (!geo.boundingBox) geo.computeBoundingBox();
      const size = new THREE.Vector3();   geo.boundingBox.getSize(size);
      const center = new THREE.Vector3(); geo.boundingBox.getCenter(center);
      bb = { min: geo.boundingBox.min.clone(), size, center };
    }
    applyGradient(matRef.current, gradient, bb, tierAlbedo);
    /* Stripes ride the SAME bbox and the same seam as the gradient — see shared/color/stripeMaterial.js.
     *
     * ⚠️ Order matters, and it is the reason these are not merged yet: both patch `onBeforeCompile` and
     * both write `diffuseColor.rgb`, so whichever runs LAST wins the pixel. Stripes go second, so a
     * tier carrying both renders as stripes. The UI does not let a baker set both — the mode picker is
     * one choice — but a design saved by an older client can, and silently picking one beats a wall
     * that flickers between them depending on which effect re-ran. */
    applyStripes(matRef.current, stripes, bb, tierAlbedo);
    applyGlaze(matRef.current, glaze, bb);   // object-space marble (glaze finish); null/1-colour → solid
  }, [gradient, stripes, glaze, geoSig]);
  // Adding/removing the dust maps on an EXISTING material needs a shader recompile, else three keeps
  // the old program (compiled without the map defines) and silently ignores emissiveMap/metalnessMap/
  // roughnessMap — the flecks never show and only the flat emissive colour leaks through.
  // Recompile the shader ONLY when finish maps appear/disappear (the map defines change). Doing it on
  // every finishMaps change recompiled the shader each drag frame — that was the drag "glue". Content
  // updates (swapping the canvas texture while dragging) need no recompile, just a texture re-upload.
  useEffect(() => {
    if (!matRef.current) return;
    const on = !!finishMaps;
    if (on !== finishOnRef.current) { matRef.current.needsUpdate = true; finishOnRef.current = on; }
  }, [finishMaps]);
  // Particle finishes (luster dust + gold leaf) bake into ONE wall-map set (`finishMaps`). The albedo
  // MAP carries the base colour + dust flecks + gold shards (so `color` goes white and the map drives
  // it). metalness/roughness are baked ABSOLUTE into the maps, so the material scalars are 1 and each
  // particle keeps its own metalness/roughness (dust ≠ foil) over the untouched matte base (base map =
  // base colour, base metalness = surf.metalness, base roughness = surf.roughness → the wall keeps its
  // frosting look). Gold/dust colour comes from the particle's surface colour, never emission, so it
  // reads on ANY base. `emissive` stays an optional faint dust glow. Gold leaf bumps envMapIntensity so
  // the metal shards reflect the room (the "shine"). The grain/style normal stays. (Map binding requires
  // the needsUpdate recompile above.)
  return (
    <mesh ref={meshRef} position={position} castShadow={castShadow} receiveShadow={receiveShadow}>
      {children}
      <meshPhysicalMaterial ref={matRef} color={finishMaps ? '#ffffff' : tierAlbedo(color)}
        map={finishMaps?.map ?? null}
        roughness={finishMaps ? 1 : (surf?.roughness ?? 0.68)}
        metalness={finishMaps ? 1 : (surf?.metalness ?? 0)}
        metalnessMap={finishMaps?.metalnessMap ?? null}
        roughnessMap={finishMaps?.roughnessMap ?? null}
        emissive={finishMaps ? (foil ? (foil.color ?? '#000000') : (dusting?.dustColor ?? '#000000')) : '#000000'}
        emissiveMap={finishMaps?.emissiveMap ?? null}
        emissiveIntensity={finishMaps ? (foil ? (foil.finish?.glow ?? 0.35) : (dusting?.glow ?? 0)) : 0}
        sheen={surf?.sheen ?? 0} sheenRoughness={surf?.sheenRoughness ?? 0.6} sheenColor={surf?.sheenColor ?? '#ffffff'}
        clearcoat={finishMaps ? 1 : (surf?.clearcoat ?? 0)}
        clearcoatMap={finishMaps?.metalnessMap ?? null}
        clearcoatRoughness={finishMaps ? 0.12 : (surf?.clearcoatRoughness ?? 0.5)}
        envMapIntensity={finishMaps && foil ? (foil.finish?.env ?? 4.5) : (surf?.envMapIntensity ?? 0.5)}
        normalMap={normalMap ?? null}
        normalScale={[normalScale, normalScale]} />
    </mesh>
  );
}

// ── Glaze drip fringe ─────────────────────────────────────────────────────────────
// The pendant drip tendrils hanging off a glaze tier's bottom edge (geometry from glazeDrip.js, riding
// perimeter(shape)). It wears the SAME glaze material as the body and is handed the BODY's bbox, so the
// object-space marble shader continues off the edge and every tendril carries the streak above it. Placed
// at the tier base in the body's LOCAL frame, so its local Y (0 → −depth) lines up beneath the wall.
function GlazeDrip({ geo, surf, glaze, bodyBbox, yBase }) {
  const matRef = useRef();
  useEffect(() => { if (matRef.current) applyGlaze(matRef.current, glaze, bodyBbox); }, [glaze, bodyBbox, geo]);
  return (
    <mesh position={[0, yBase, 0]} geometry={geo} castShadow>
      <meshPhysicalMaterial ref={matRef} color={glaze?.colors?.[0] ?? '#ffffff'} metalness={0}
        roughness={surf?.roughness ?? 0.2} clearcoat={surf?.clearcoat ?? 1} clearcoatRoughness={surf?.clearcoatRoughness ?? 0.2}
        envMapIntensity={surf?.envMapIntensity ?? 1.2} side={THREE.DoubleSide} />
    </mesh>
  );
}

// ── Top-surface foil decal ──────────────────────────────────────────────────────
// Gold leaf on the flat TOP can't bake into the wall unwrap (different surface), so it rides a thin
// transparent disk decal sitting just above the lid. The baked maps carry the shards; the emissive
// mask doubles as the alpha map, so only the shards are opaque (the rest of the disk stays clear and
// the cake top shows through). Same material treatment as the wall foil (lines in TierBody), but
// transparent — it's a decal, not the surface. A PlaneGeometry(2R) laid flat: its default UV matches
// the polar `place()` in topDiskProject, so a flake's drag handle (FinishHandles top branch) lands on
// its shard. Works for cylinder / rounded / styled tiers alike (all share the flat top at topY).
function TopFoilDecal({ maps, radius, y, foilColor = '#e6be4a', glow = 0.35, env = 4.5 }) {
  const matRef = useRef();
  const onRef = useRef(false);
  // Binding the maps onto an existing material needs a one-time shader recompile (same reason as the
  // wall body) — do it only when the maps appear/disappear, not on every drag-frame content swap.
  useEffect(() => {
    if (!matRef.current) return;
    const on = !!maps;
    if (on !== onRef.current) { matRef.current.needsUpdate = true; onRef.current = on; }
  }, [maps]);
  if (!maps) return null;
  return (
    <mesh position={[0, y, 0]} rotation={[-Math.PI / 2, 0, 0]} renderOrder={2}>
      <planeGeometry args={[2 * radius, 2 * radius]} />
      <meshPhysicalMaterial ref={matRef} color="#ffffff" transparent alphaTest={0.35} depthWrite={false}
        map={maps.map} alphaMap={maps.emissiveMap}
        roughness={1} metalness={1} metalnessMap={maps.metalnessMap} roughnessMap={maps.roughnessMap}
        emissive={foilColor} emissiveMap={maps.emissiveMap} emissiveIntensity={glow}
        clearcoat={1} clearcoatMap={maps.metalnessMap} clearcoatRoughness={0.12}
        envMapIntensity={env} />
    </mesh>
  );
}

// ── Second cream layer ────────────────────────────────────────────────────────
// A stack of raised two-tone bands on the tier wall, each with a customer-drawn torn
// edge h(θ) and optional gold-leaf trim. Bands are REAL geometry (offset shell + ledge
// lip) — the raised lip is the whole look. Round tiers only (the geometry is cylindrical).
const SECOND_CREAM_STACK_STEP = 0.04;                       // radial gap per stacked band
const SECOND_CREAM_GRAIN_SCALE = new THREE.Vector2(0.35, 0.35);
const SECOND_CREAM_GOLD_NORMAL_SCALE = new THREE.Vector2(0.7, 0.7);

// One band. `order` pushes it radially proud of lower layers so the lips stack without
// z-fighting; it wears the same cream grain as the wall, plus optional gold-leaf trim.
function SecondCreamBand({ layer, radius, yBase, height, grain }) {
  const order = layer.order ?? 0;
  const baseR = radius + order * SECOND_CREAM_STACK_STEP;
  // NB: `height` (prop) is the WALL height; the band's own thickness is layer.height → bandHeight.
  const { color, edge, lift, fillSide, noise, seed, height: bandHeight } = layer;
  const gold = layer.gold ?? {};

  const bandGeo = useMemo(
    () => buildSecondCreamLayer({ R: baseR, y0: yBase, wallH: height, lift, edge, fillSide, noise, height: bandHeight, seed }),
    [baseR, yBase, height, lift, fillSide, noise, bandHeight, seed, edge],
  );
  const goldGeo = useMemo(
    () => (gold.on ? buildSecondCreamEdgeLine({ R: baseR, y0: yBase, wallH: height, lift, edge, noise, height: bandHeight, fillSide, seed }) : null),
    [gold.on, baseR, yBase, height, lift, noise, bandHeight, fillSide, seed, edge],
  );
  // Brighter floor than the food-foil shards: the edge ribbon uses this map AS its albedo (full-strength
  // multiply), so a low floor browns the creases — lift it so the crinkle reads as gold, not mud.
  const goldMaps = useMemo(() => (gold.on ? makeGoldLeafMaps({ seed, lumFloor: 0.5 }) : null), [gold.on, seed]);

  return (
    <group>
      <mesh geometry={bandGeo} castShadow>
        {/* ⚠️ `layer.softness ?? 0.85` — the fallback is the value this was hardcoded to, so every
            saved band renders exactly as before. It became a parameter so the colour correction could
            be MEASURED across the range a real piping ring uses: rings pass their own softness and
            default to 0.7, while this band was fixed at 0.85, and softness drives sheen — which adds
            light. Swept 0.0 / 0.4 / 0.7 / 0.85 / 1.0, a mid-grey renders 130 / 128 / 125 / 124 / 124
            against an asked 128, so the reference light holds across the whole range. */}
        <meshPhysicalMaterial {...creamMaterialProps(layer.softness ?? 0.85, color)}
          normalMap={grain} normalScale={SECOND_CREAM_GRAIN_SCALE} side={THREE.DoubleSide} />
      </mesh>
      {gold.on && goldMaps && (
        <mesh geometry={goldGeo}>
          {/* Glossy edible leaf — the SAME approved gold look as the food-foil shards (GOLD_LEAF_DEFAULTS):
              metalness low enough that the gold albedo stays bright, high env to catch the dim apartment
              scene, and a gold emissive glow gated by the crinkle map so it reads luminous, not muddy. */}
          <meshStandardMaterial color={gold.color ?? GOLD_LEAF_COLORS.gold}
            map={goldMaps.map} normalMap={goldMaps.normalMap} normalScale={SECOND_CREAM_GOLD_NORMAL_SCALE}
            metalness={GOLD_LEAF_DEFAULTS.metalness} roughness={GOLD_LEAF_DEFAULTS.roughness} envMapIntensity={GOLD_LEAF_DEFAULTS.env}
            emissive={gold.color ?? GOLD_LEAF_COLORS.gold} emissiveMap={goldMaps.map} emissiveIntensity={GOLD_LEAF_DEFAULTS.glow}
            transparent={false} alphaTest={0.45} side={THREE.DoubleSide} />
        </mesh>
      )}
    </group>
  );
}

// All second-cream bands on a (round) tier. The grain matches the wall's (constant
// physical cell size across tier sizes) so the bands read as the SAME buttercream.
function SecondCreamLayers({ layers, radius, yBase, height, grainKey, grainDensity }) {
  const grain = useMemo(
    () => grainNormalMap(grainKey, 2 * Math.PI * radius, height, grainDensity),
    [grainKey, radius, height, grainDensity],
  );
  if (!layers?.length) return null;
  return layers.map((layer, idx) => (
    <SecondCreamBand key={layer.layerId ?? idx} layer={layer} radius={radius} yBase={yBase} height={height} grain={grain} />
  ));
}

export default function CakeTier({
  radius, height, color, yBase,
  gradient = null,
  // Several colours up the wall — shared/color/stripeMaterial.js. Null = the solid colour or gradient.
  stripes = null,
  glaze = null,
  shape = 'round', shapeFamily = null, shapeConfig = null, width, depth, cornerR,
  frostingType = 'buttercream',
  frostingStyle = DEFAULT_STYLE,
  styleParams = null,
  dusting = null,
  foil = null,
  flavour = 'vanilla',
  selected = false,
  // New: arrays of stacked piping layers per zone. Legacy single topPiping/bottomPiping
  // props are still accepted (admin/template tools) and normalised into the arrays below.
  topPipings = null,
  bottomPipings = null,
  topPiping = null,
  bottomPiping = null,
  creamLayers = null,   // raised two-tone bands (second cream layer) — round tiers only

  // Element id of the piping whose card is expanded — every ring of that element is
  // highlighted on the cake. Legacy single-piping callers fall back to the booleans.
  highlightPipingId = null,
  topPipingSelected = false,
  bottomPipingSelected = false,
  onTopPipingClick,
  onBottomPipingClick,
  // Drag a single-mode piece round its ring: (zone, layerId, index, angle) => void. Absent (previews,
  // the thumbnail scene) = no drag wiring at all. `pipingMovable(layer)` is the capability read — the
  // host owns it because only the host has the catalogue; default movable so a preview never invents
  // a restriction (same contract as isStickerMovable).
  onPipingInstanceMove = null,
  pipingMovable = () => true,
  onClick,
}) {
  const topY    = yBase + height;
  const centerY = yBase + height / 2;
  // Finish definition (data) → material descriptor, edge profile, capabilities. naked has no
  // `material` (it renders its own way), so fall back to the default for the unused body material.
  const fdef = frostingDef(frostingType);
  const mat = fdef.material ?? FROSTINGS[DEFAULT_FROSTING].material;
  const roundEdge = fdef.edge?.kind === 'round' ? fdef.edge : null;
  // Gradient is a cream technique only — ignore any (dormant) gradient on a finish that doesn't
  // support it (fondant/naked), so it always renders solid. The data is kept; just not rendered.
  const effGradient = frostingSupportsGradient(frostingType) ? gradient : null;
  /* Stripes ride the SAME declared capability as the gradient — a frosting that cannot hold an ombre
   * cannot hold stripes either (fondant is a rolled sheet, naked has barely any cream). Config-driven
   * off the frostings registry, never a name check (INVARIANTS #1/#6).
   * ⚠️ Worth revisiting: the sunset reference cake reads as fondant, and fondant does not declare
   * gradient support — so that capability may be the wrong gate for stripes specifically. Following
   * the existing one rather than inventing a second is the smaller mistake for now. */
  const effStripes = frostingSupportsGradient(frostingType) ? stripes : null;
  // Chocolate glaze: a render:'glaze' finish paints its body with the object-space marble shader. The
  // palette lives on the instance (tier.glaze); absent → the default solid chocolate. Config-driven off
  // the finish's `render` KEY, never the literal frosting name (INVARIANTS #1/#6). The glaze base colour
  // is glaze.colors[0] (not tier.color, which is for cream finishes), so a solid glaze reads chocolate.
  const effGlaze = fdef.render === 'glaze' ? (glaze ?? GLAZE_DEFAULTS) : null;
  const bodyColor = effGlaze ? (effGlaze.colors?.[0] ?? color) : color;
  // Vertical gradient runs bottom→top, so the top lid takes the last (top-most) stop; solid colour
  // otherwise. Mirrors the shader, which maps gt=1 (the cake top) to the final stop.
  const gradColors = effGradient?.colors?.filter(Boolean) ?? [];
  /* The top lid takes the TOP-MOST colour, whichever effect is painting the wall.
   *
   * This is the "top disc" question the plan left open, and the gradient already answered it: every
   * reference photo ices the top separately in one colour, and the one that reads is the colour the
   * wall arrives at. Stripes reuse the rule rather than inventing a stored choice nobody asked for. */
  const stripeCap   = areStripesActive(effStripes) ? stripeColors(effStripes).slice(-1)[0] : null;
  const capColor    = stripeCap ?? (gradColors.length >= 2 ? gradColors[gradColors.length - 1] : color);
  const shp = useMemo(() => tierShape({ shape, shapeFamily, shapeConfig, width, depth, radius, cornerR }), [shape, shapeFamily, shapeConfig, width, depth, radius, cornerR]);
  // "Not round" — an extruded footprint (the sheet's rounded rect, or any authored outline). Every
  // feature below that was gated on `!isPrism` was really gated on "this is the lathe/cylinder path":
  // the cream wall styles, drip, festoons, luster and foil are all cylinder-unwrap maths. An outline
  // shape belongs on the prism side of that line, so it inherits the gate rather than needing a branch.
  const isPrism = shp.kind !== 'round';
  const prismGeo = useMemo(
    () => {
      if (shp.kind === 'glyph') return buildGlyphPrism(shp.shapes, shp.thickness ?? height);  // number/letter — per-count extrusion depth
      if (shp.kind === 'rect') return buildRoundedPrism(shp.halfW, shp.halfD, height, shp.cornerR);
      if (shp.kind !== 'outline') return null;
      // The rolled top rim comes from the FROSTING's own edge config — the very same `roundEdge` the
      // round tier uses for its fondant drape (frostings.js `edge: {kind:'round', frac}`). So a fondant
      // heart rolls over at the rim and a sharp-edged finish stays sharp, with no per-shape knob and no
      // second opinion about what a cake's edge looks like.
      const f = roundEdge ? roundEdge.frac * Math.min(Math.min(shp.halfW, shp.halfD), height) : 0;
      return buildOutlinePrism(shp.outline, height, f);
    },
    [shp, height, roundEdge?.frac],
  );
  // The wall's grain runs once around the tier, so its U extent is the PERIMETER. (Rect keeps its
  // existing 2·(w+d) approximation so no sheet cake's texture shifts.)
  const prismGrainU = useMemo(
    () => (shp.kind === 'rect' ? 2 * (shp.halfW + shp.halfD)
        :  shp.outline ? perimeter(shp).length   // heart, polygon, glyph (number/letter) — the real contour length
        :  0),
    [shp],
  );
  // Round fondant tiers get a draped, rounded-edge body (config-driven via the finish's
  // `edge: { kind:'round', frac }`). Other round tiers stay a plain cylinder + lid. null ⇒ cylinder.
  const roundedGeo = useMemo(
    () => (!isPrism && roundEdge)
      ? buildRoundedTopCylinder(radius, height, roundEdge.frac * Math.min(radius, height))
      : null,
    [isPrism, roundEdge?.frac, radius, height],
  );
  // Glaze DRIP fringe — the pendant tendrils off the bottom edge, only for a glaze finish. The geometry
  // rides perimeter(shp) so it fits ANY shape; it shares the BODY geometry's bbox so the object-space
  // marble shader continues off the edge and colours each tendril. `drip` is the finish's AUTHORED
  // fraction of tier height (glaze.drip), not a customer knob.
  const glazeBodyGeo = isPrism ? prismGeo : roundedGeo;
  // Drip length is an AUTHORED finish property: use the instance's if present, else the finish default
  // (GLAZE_DEFAULTS.drip, DB-overlaid) — never a customer knob.
  const dripFrac = effGlaze ? (effGlaze.drip ?? GLAZE_DEFAULTS.drip) : 0;
  const glazeDrip = useMemo(
    () => (effGlaze && dripFrac > 0.001 ? buildGlazeDrip(shp, dripFrac, height, 1) : null),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [!!effGlaze, dripFrac, shp, height],
  );
  const glazeBodyBbox = useMemo(() => {
    const g = glazeBodyGeo;
    if (!g) return null;
    if (!g.boundingBox) g.computeBoundingBox();
    const size = new THREE.Vector3();   g.boundingBox.getSize(size);
    const center = new THREE.Vector3(); g.boundingBox.getCenter(center);
    return { min: g.boundingBox.min.clone(), size, center };
  }, [glazeBodyGeo]);
  // Cream STYLE → a displaced wall (wave/swirl/rustic). Only for finishes that texture (cream, not
  // fondant) and round tiers; an unsupported/unknown style falls back to smooth (null → plain wall).
  // Resolved params (schema defaults ← tier overrides) feed the geometry; memo keyed on their values.
  const wallKey = frostingAllowsStyles(frostingType) ? styleDef(frostingStyle).wall : 'smooth';
  const styleVals = resolveStyleParams(frostingStyle, styleParams);
  const styleSig = JSON.stringify(styleVals);
  const styledGeo = useMemo(
    () => (!isPrism && !roundEdge) ? buildStyledWall(wallKey, radius, height, styleVals) : null,
    // styleVals is recreated each render; styleSig captures its values for the memo. eslint-disable-next-line
    [isPrism, roundEdge, wallKey, radius, height, styleSig],
  );
  // Normal-map STYLE (rustic): a surface texture on the plain wall instead of geometry. Built when the
  // style declares a surfaceMap; `depth` → normalScale, `scale` → tiling density.
  const surfaceMapKey = frostingAllowsStyles(frostingType) ? styleDef(frostingStyle).surfaceMap : null;
  const styleNormalMap = useMemo(
    () => (surfaceMapKey && !isPrism)
      ? surfaceNormalMap(surfaceMapKey, {
          aroundLen: 2 * Math.PI * radius, upLen: height, density: (styleVals.scale ?? 9) / 9,
          radius, height, params: styleVals,
        })
      : null,
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [surfaceMapKey, isPrism, radius, height, styleSig],
  );
  const styleNormalScale = styleVals.depth ?? 1;

  // Particle finishes (luster dust + gold leaf) are config-driven by SURFACE: a flake/splash addresses
  // the wall (cylinder unwrap) or the flat top (polar disk), per its `surface`. Each surface bakes its
  // own map set — the wall set (dust + side flakes) binds to the tier body; the top set (top flakes)
  // binds to a thin decal disk above the lid. Round tiers only (the u,v address a round surface).
  const foilFlakes = foil?.flakes ?? [];
  const sideFlakes = foilFlakes.filter(f => (f.surface ?? 'side') !== 'top_surface');
  const topFlakes  = foilFlakes.filter(f => (f.surface ?? 'side') === 'top_surface');
  const sideFoil = foil && sideFlakes.length ? { ...foil, flakes: sideFlakes } : null;
  const topFoil  = foil && topFlakes.length  ? { ...foil, flakes: topFlakes }  : null;

  const sideSig = `${dusting ? JSON.stringify(dusting) : ''}|${sideFoil ? JSON.stringify(sideFoil) : ''}`;
  const finishRef = useRef(null);   // reused canvases/textures across rebuilds (drag/add stay cheap)
  const finishMaps = useMemo(() => {
    if (isPrism || !(dusting?.splashes?.length || sideFoil?.flakes?.length)) { finishRef.current = null; return null; }
    finishRef.current = makeParticleFinishMaps({
      surface: 'side', radius, height, baseColor: color, surfRoughness: mat.roughness ?? 0.68, surfMetalness: mat.metalness ?? 0,
      dusting, foil: sideFoil, reuse: finishRef.current,
    });
    return finishRef.current;
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isPrism, radius, height, color, mat.roughness, mat.metalness, sideSig]);

  const topSig = topFoil ? JSON.stringify(topFoil) : '';
  const topFinishRef = useRef(null);
  const topFinishMaps = useMemo(() => {
    if (isPrism || !topFoil?.flakes?.length) { topFinishRef.current = null; return null; }
    topFinishRef.current = makeParticleFinishMaps({
      surface: 'top_surface', radius, height, baseColor: color, surfRoughness: mat.roughness ?? 0.68, surfMetalness: mat.metalness ?? 0,
      foil: topFoil, reuse: topFinishRef.current,
    });
    return topFinishRef.current;
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isPrism, radius, height, color, mat.roughness, mat.metalness, topSig]);

  const tops    = topPipings    ?? (topPiping    ? [topPiping]    : []);
  const bottoms = bottomPipings ?? (bottomPiping ? [bottomPiping] : []);

  function handleClick(e) {
    e.stopPropagation();
    if (tops.length && e.point.y > topY - height * 0.25) {
      onTopPipingClick?.(e, tops[0].layerId);
    } else if (bottoms.length && e.point.y < yBase + height * 0.25) {
      onBottomPipingClick?.(e, bottoms[0].layerId);
    } else {
      onClick?.(e);
    }
  }

  // One <TopPipingRing>/<BottomPipingRing> per stacked layer. A layer is "selected"
  // by its layerId; legacy single-piping callers fall back to the boolean flags.
  const renderTops = () => tops.map((p, idx) => (
    <TopPipingRing key={p.layerId ?? `t${idx}`} topY={topY} radius={shp.shellRadius ?? radius} glbPath={p.glbUrl} color={p.color}
      gradient={p.gradient ?? null}
      sizeFactor={p.size ?? 1} softness={p.softness ?? PIPING_SOFTNESS_DEFAULT}
      topRotation={p.rotation ?? [0,0,0]}
      extraRadialOffset={(p.extraRadialOffset ?? 0) + (p.userRadialOffset ?? 0)}
      yOffset={(p.yOffset ?? 0) + (p.userYOffset ?? 0)}
      flipTop={p.userFlipTop !== undefined ? p.userFlipTop : (p.flipTop ?? false)}
      spacing={p.spacing ?? 1}
      swagCount={p.swagCount ?? 0} swagDepth={p.swagDepth ?? 0} swagTilt={p.swagTilt ?? 0.5}
      arrangement={p.arrangement ?? 'ring'} instances={p.instances ?? null} finish={p.finish ?? 'cream'}
      altEnabled={p.altEnabled ?? false} altGlbUrl={p.altGlbUrl ?? null}
      altFlip={p.altFlip ?? false} altRotation={p.altRotation ?? [0,0,0]}
      altRadialOffset={p.altRadialOffset ?? 0} altYOffset={(p.altYOffset ?? 0) + (p.userYOffset ?? 0)}
      pattern={p.pattern ?? 'AB'} shape={shp}
      bend={p.bend ?? false} bendRing={p.bendRing ?? false}
      festoons={p.festoons ?? 6} bendDepth={p.bendDepth ?? 0.4} bendTilt={p.bendTilt ?? 0}
      wrap={p.wrap ?? false} wrapTilt={p.wrapTilt ?? 0} wrapSize={p.wrapSize ?? 1}
      drip={p.drip ?? false} dripConfig={p.dripConfig ?? null}
      dripGloss={p.dripGloss ?? DRIP_GLOSS_DEFAULT} dripLength={p.dripLength ?? 1} dripFlood={p.dripFlood ?? false}
      selected={highlightPipingId != null ? p.cardId === highlightPipingId : topPipingSelected}
      canMove={pipingMovable(p)}
      onMoveInstance={onPipingInstanceMove ? (index, angle) => onPipingInstanceMove('rim', p.layerId, index, angle) : null}
      onClick={e => { e.stopPropagation(); onTopPipingClick?.(e, p.layerId); }} />
  ));

  // Festoon anchor = a fraction of the wall + the offset BAKED when the swag was added (which
  // already cleared whatever borders existed then — see nextFestoonYOffset in CakeDesigner). It
  // does NOT react to layers added later, so an existing swag never jumps when something new is
  // placed; instead the new layer stacks around the swag's reported band.
  const renderBottoms = () => bottoms.map((p, idx) => (
    <BottomPipingRing key={p.layerId ?? `b${idx}`} yBase={yBase} radius={shp.shellRadius ?? radius} tierHeight={height} glbPath={p.glbUrl} color={p.color}
      gradient={p.gradient ?? null}
      sizeFactor={p.size ?? 1} softness={p.softness ?? PIPING_SOFTNESS_DEFAULT}
      bottomRotation={p.bottomRotation ?? [0,0,0]}
      extraRadialOffset={(p.extraRadialOffset ?? 0) + (p.userRadialOffset ?? 0)}
      yOffset={p.bend
        ? height * BEND_ANCHOR_FRAC + (p.userYOffset ?? 0)   // festoon: wall anchor + baked/nudged offset
        : (p.yOffset ?? 0) + (p.userYOffset ?? 0)}
      flipBottom={p.userFlipBottom !== undefined ? p.userFlipBottom : (p.flipBottom ?? true)}
      spacing={p.spacing ?? 1}
      swagCount={p.swagCount ?? 0} swagDepth={p.swagDepth ?? 0} swagTilt={p.swagTilt ?? 0.5}
      arrangement={p.arrangement ?? 'ring'} instances={p.instances ?? null} finish={p.finish ?? 'cream'}
      altEnabled={p.altEnabled ?? false} altGlbUrl={p.altGlbUrl ?? null}
      altFlip={p.altFlip ?? false} altRotation={p.altRotation ?? [0,0,0]}
      altRadialOffset={p.altRadialOffset ?? 0} altYOffset={(p.altYOffset ?? 0) + (p.userYOffset ?? 0)}
      pattern={p.pattern ?? 'AB'} shape={shp}
      bend={p.bend ?? false} bendRing={p.bendRing ?? false}
      festoons={p.festoons ?? 6} bendDepth={p.bendDepth ?? 0.4} bendTilt={p.bendTilt ?? 0}
      wrap={p.wrap ?? false} wrapTilt={p.wrapTilt ?? 0} wrapSize={p.wrapSize ?? 1}
      selected={highlightPipingId != null ? p.cardId === highlightPipingId : bottomPipingSelected}
      canMove={pipingMovable(p)}
      onMoveInstance={onPipingInstanceMove ? (index, angle, wallY) => onPipingInstanceMove('board', p.layerId, index, angle, wallY) : null}
      onClick={e => { e.stopPropagation(); onBottomPipingClick?.(e, p.layerId); }} />
  ));

  if (frostingType === 'naked') {
    return (
      <group onClick={handleClick}>
        {selected && <SelectionOutline shp={shp} yBase={yBase} height={height} />}
        <NakedLayers shp={shp} yBase={yBase} height={height} flavour={flavour} />
        {!isPrism && (
          <mesh position={[0, topY + 0.01, 0]}>
            <cylinderGeometry args={[radius - 0.01, radius - 0.01, 0.02, 64]} />
            <meshStandardMaterial color="#fffdf5" roughness={0.5} />
          </mesh>
        )}
        {renderTops()}
        {renderBottoms()}
      </group>
    );
  }

  return (
    <group onClick={handleClick}>
      {selected && <SelectionOutline shp={shp} yBase={yBase} height={height} />}
      {/* Glaze drip tendrils off the bottom edge (glaze finish only) — same wet material as the body,
          sharing its bbox so the object-space marble field flows unbroken off the edge onto each drip. */}
      {glazeDrip && glazeBodyBbox && (
        <GlazeDrip geo={glazeDrip.geo} surf={mat} glaze={effGlaze} bodyBbox={glazeBodyBbox} yBase={yBase} />
      )}
      {isPrism ? (
        // An extruded footprint (sheet rect, or an authored outline): flat top, full footprint, no
        // separate top cap (a cap reads as a stray "board" on a non-round cake).
        <TierBody position={[0, yBase, 0]} color={bodyColor} surf={mat}
          grainExtent={[prismGrainU, height]}
          gradient={effGradient} stripes={effStripes} glaze={effGlaze} geoSig={prismGeo?.uuid} castShadow receiveShadow>
          <primitive object={prismGeo} attach="geometry" />
        </TierBody>
      ) : roundedGeo ? (
        // Fondant-draped round tier: one rounded-edge solid (spans y ∈ [0,height]), positioned at
        // the base. No separate lid — the gradient/grain flow over the rounded rim continuously.
        <TierBody position={[0, yBase, 0]} color={bodyColor} surf={mat}
          grainExtent={[2 * Math.PI * radius, height]} dusting={dusting} foil={foil} finishMaps={finishMaps}
          gradient={effGradient} stripes={effStripes} glaze={effGlaze} geoSig={roundedGeo.uuid} castShadow receiveShadow>
          <primitive object={roundedGeo} attach="geometry" />
        </TierBody>
      ) : styledGeo ? (
        // Cream STYLE wall (wave/swirl/rustic): a displaced cylinder, one centred mesh (caps flat),
        // no separate lid — the texture and gradient flow over the whole wall.
        <TierBody position={[0, centerY, 0]} color={color} surf={mat}
          grainExtent={[2 * Math.PI * radius, height]} dusting={dusting} foil={foil} finishMaps={finishMaps}
          gradient={effGradient} stripes={effStripes} geoSig={styledGeo.uuid} castShadow receiveShadow>
          {/* key on the geometry uuid: <primitive> won't re-attach a swapped `object` without it, so
              changing the STYLE params (Depth/Waviness…) rebuilds styledGeo but the mesh kept the old one. */}
          <primitive key={styledGeo.uuid} object={styledGeo} attach="geometry" />
        </TierBody>
      ) : (
        <>
          <TierBody position={[0, centerY, 0]} color={color} surf={mat}
            grainExtent={[2 * Math.PI * radius, height]} dusting={dusting} foil={foil} finishMaps={finishMaps}
            overrideNormalMap={styleNormalMap} overrideNormalScale={styleNormalScale}
            gradient={effGradient} stripes={effStripes} geoSig={`r${radius}h${height}`} castShadow receiveShadow>
            <cylinderGeometry args={[radius, radius, height, 64]} />
          </TierBody>
          {/* Top lid: a thin disk that reads as the cake's flat top. Under a vertical gradient its
              own 0.02-tall frame can't show the blend, so it takes the top (last) stop's colour. */}
          <mesh position={[0, topY + 0.01, 0]} castShadow>
            <cylinderGeometry args={[radius - 0.01, radius - 0.01, 0.02, 64]} />
            <meshStandardMaterial color={capColor} roughness={mat.roughness - 0.08} />
          </mesh>
        </>
      )}
      {!isPrism && (
        <SecondCreamLayers layers={creamLayers ?? []} radius={radius} yBase={yBase} height={height}
          grainKey={mat.grain} grainDensity={mat.grainDensity} />
      )}
      {!isPrism && topFinishMaps && (
        <TopFoilDecal maps={topFinishMaps} radius={radius - 0.02} y={topY + 0.02}
          foilColor={topFoil?.color} glow={topFoil?.finish?.glow ?? 0.35} env={topFoil?.finish?.env ?? 4.5} />
      )}
      {renderTops()}
      {renderBottoms()}
    </group>
  );
}
