/* ── Deciding what a take should cost, before paying for it ──────────────────────────────────────
 *
 * A reel is rendered at 1080×1920 and captured live. On a current phone that is comfortable. On a
 * four-year-old Android with a loaded cake — a dozen toppers, piping all round — it is not, and the
 * failure is quiet: the recording still succeeds, it just comes out juddering.
 *
 * So the take is measured before it is committed to. A handful of frames are rendered at the size
 * being asked for, and if the device cannot keep up, the take is made cheaper rather than worse.
 *
 * Pure arithmetic, no renderer, no DOM: the rendering half lives in TakeDirector where the camera
 * is, and everything decided from it is here where it can be tested.
 */

/* Ladder, best first. Each rung is a real Instagram-acceptable portrait size.
 *
 * 720×1280 is 44% of the pixels of 1080×1920 — enough of a saving to matter, and still sharp on a
 * phone. There is deliberately no third rung: below this the video stops being worth posting, and a
 * reel nobody posts is not a cheaper success, it is a failure that took longer. */
export const RUNGS = [
  { width: 1080, height: 1920, label: '1080×1920' },
  { width: 720,  height: 1280, label: '720×1280' },
];

/* Above this many milliseconds per frame, the device is not sustaining the shot.
 *
 * 60fps is a 16.7ms budget. 20ms allows a little slack — a stray garbage collection or a topper
 * texture finishing upload should not demote a device that is otherwise fine — while still catching
 * anything genuinely below about 50fps. */
export const SLOW_MS = 20;

/* What to record, given what a probe measured.
 *
 * `msPerFrame` null (no probe ran, or it could not measure) means the top rung. Refusing to guess
 * downward matters: a device that was never measured is not a slow device, and quietly halving
 * everybody's resolution because a probe failed would be the worse bug of the two.
 */
export function planTake(msPerFrame) {
  if (msPerFrame == null || !Number.isFinite(msPerFrame) || msPerFrame <= SLOW_MS) {
    return { ...RUNGS[0], demoted: false };
  }
  return { ...RUNGS[1], demoted: true };
}

/* The median, not the mean.
 *
 * The first frame after a resize includes the reallocation of the drawing buffer, and any frame can
 * absorb a garbage collection. Either one drags a mean far enough to demote a device that is
 * perfectly capable — and the mean is what the first version of this used.
 */
export function medianOf(samples) {
  const xs = samples.filter(Number.isFinite).slice().sort((a, b) => a - b);
  if (!xs.length) return null;
  const mid = xs.length >> 1;
  return xs.length % 2 ? xs[mid] : (xs[mid - 1] + xs[mid]) / 2;
}

/* How far through the shot we are, from the CLOCK rather than from a frame counter.
 *
 * ⚠️ This is the difference between "4.5 seconds" meaning it and meaning it on fast hardware only.
 * The loop used to run a fixed `seconds × 60` iterations, one per animation frame — so a phone
 * managing 30fps took NINE seconds to get through them, and MediaRecorder timestamps in real time,
 * so the reel came out twice as long and half as fast as the baker chose. Nothing reported this;
 * the file was fine, it was just wrong.
 *
 * Driven by elapsed time, a slow device produces FEWER frames over the same duration — which is a
 * choppier reel of the correct length, and the probe above is what stops it being choppy. Duration
 * and motion are what the baker chose; frame count is the machine's business.
 */
export const progressAt = (elapsedMs, seconds) =>
  Math.min(1, Math.max(0, elapsedMs / (seconds * 1000)));

/* ── How high the camera is, partway through ─────────────────────────────────────────────────────
 *
 * three.js measures phi DOWN from +Y: 0 is directly overhead, π/2 is level with the cake.
 *
 * A take used to hold `start.phi` for its whole length — only the azimuth swept and only the radius
 * pushed in. So whatever the baker chose, the camera stayed at that height, and NO reel could ever
 * show the top of a cake. For anything decorated on its lid that is the only side that matters, and
 * it is exactly the cake a still photograph already has an angle for ("From above", phi 26°).
 *
 * `topPhi` null means hold the starting height, which is the previous behaviour to the digit.
 *
 * ⚠️ Clamped off BOTH poles. At phi 0 the camera sits on the very axis it is looking down: the up
 * vector and the view direction become parallel, the view matrix degenerates, and the frame flips or
 * goes blank depending on the driver. photoAngles.anglePosition guards its presets with the same
 * margin — a take easing straight to 0 would walk around that guard rather than inherit it.
 *
 * Riding the SAME eased phase as the arc and the dolly is what makes this loop: on an out-and-back
 * the easing returns to 0, so the camera comes back down to where it started and the seam stays
 * invisible. Giving the lift its own curve would have broken that for no gain.
 */
/* ── Does the camera finish where it started? ────────────────────────────────────────────────────
 *
 * The dolly and the lift ride an out-and-back curve so they come home with the arc and the reel
 * loops with no jump. That used to be keyed on `pingPong`, which was right while a one-way take
 * always ended somewhere new.
 *
 * A FULL TURN breaks that. It is one-way and it still comes home — on ANGLE. Left riding a one-way
 * curve, the dolly ends 22% closer than it started and the lift ends overhead, so the loop pops on
 * distance and height while the angle matches perfectly. Measured on a 6-unit framing: a seam of
 * 1.32 world units level, 4.35 with the rise on.
 *
 * So the question is not "is this a ping-pong" but "does the arc come home", and a full turn is the
 * other way it can. `arcDeg` may be negative — direction is a signed multiplier, not a branch.
 */
export const arcComesHome = (arcDeg, pingPong) =>
  !!pingPong || (Number.isFinite(arcDeg) && arcDeg !== 0 && Math.abs(arcDeg) % 360 === 0);

export const POLE_MARGIN = (6 * Math.PI) / 180;

export function elevationAt(startPhi, eased, topPhi = null) {
  const end = topPhi == null ? startPhi : topPhi;
  const phi = startPhi + (end - startPhi) * eased;
  return Math.min(Math.PI - POLE_MARGIN, Math.max(POLE_MARGIN, phi));
}
