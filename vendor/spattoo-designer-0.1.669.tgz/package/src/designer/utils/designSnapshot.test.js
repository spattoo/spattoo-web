import { describe, it, expect } from 'vitest';
import { buildDesignSnapshot , OPTIONAL_TIER_FIELDS} from './designSnapshot.js';
import { toCanvasConfig, normalizeDesign } from '../hooks/useCakeDesign.js';

// A glaze cake must survive being SAVED (order snapshot / template) and reloaded, and reach the renderer
// config — else a saved glaze design (and its thumbnail) would come back as a plain cake. Pins the
// tier.glaze round-trip through the three seams: snapshot build, load-normalise, and canvas config.
describe('glaze survives the snapshot round-trip and reaches the renderer', () => {
  const glaze = { colors: ['#2a1810', '#8a5a30', '#efd9b8'], flow: 2.6, warp: 1.1, contrast: 3.2, streak: 0.12, drip: 0.18 };
  const design = {
    tiers: [{ shape: 'round', color: '#ffffff', frostingType: 'glaze', glaze, topPipings: [], bottomPipings: [], creamLayers: [] }],
    texts: [], ages: [], stickers: [], writings: [], piping: [],
  };

  it('buildDesignSnapshot preserves tier.glaze', () => {
    expect(buildDesignSnapshot(design).tiers[0].glaze).toEqual(glaze);
  });

  it('normalizeDesign restores tier.glaze on load', () => {
    const loaded = normalizeDesign(buildDesignSnapshot(design));
    expect(loaded.tiers[0].glaze).toEqual(glaze);
    expect(loaded.tiers[0].frostingType).toBe('glaze');
  });

  it('toCanvasConfig forwards glaze to the renderer (CakeTier reads it here)', () => {
    const cfg = toCanvasConfig(design);
    expect(cfg.tiers[0].glaze).toEqual(glaze);
    expect(cfg.tiers[0].frostingType).toBe('glaze');
  });

  it('a design with no glaze keeps glaze absent (no accidental default in the snapshot)', () => {
    const plain = { tiers: [{ shape: 'round', color: '#fff', frostingType: 'buttercream', topPipings: [], bottomPipings: [], creamLayers: [] }], texts: [], ages: [], stickers: [] };
    expect(buildDesignSnapshot(plain).tiers[0].glaze).toBeUndefined();
  });
});

// ── Everything on the cake must survive being saved ─────────────────────────────────────────────
// The pinned test above guards ONE field, glaze, because glaze was once dropped. Grass, letter
// blocks, board grass and second-cream layers were dropped in exactly the same way and for exactly
// the same reason: the round-trip is a hand-maintained list of field names, and four element types
// were added to the cake without being added to it. A saved template then came back as a plain cake,
// and — because the thumbnail is captured from the CANVAS, not from the snapshot — its picture still
// showed the grass. The cake in the picture and the cake you got were different cakes.
//
// So this guards the ROUND-TRIP ITSELF rather than any one field: whatever the renderer reads
// (toCanvasConfig) must be identical after design → snapshot → load. A new element type that is not
// added to OPTIONAL_TIER_FIELDS / buildDesignSnapshot / normalizeDesign fails here, at the moment it
// is added, instead of on a customer's cake.
describe('a saved design comes back as the same cake', () => {
  // Every field the renderer reads, set to something recognisable. layerIds are explicit because
  // loading assigns them to piping that has none, and that is a legitimate difference, not a loss.
  const FULL = {
    tiers: [{
      color: '#f3f0ec', radius: 1.2, height: 1.45,
      shape: 'round', shapeFamily: 'circle', shapeConfig: { r: 1 },
      width: 2.4, depth: 2.4, cornerR: 0.1,
      frostingType: 'buttercream', frostingStyle: 'wave', styleParams: { depth: 0.4 },
      gradient: { stops: [{ color: '#fff', at: 0 }] },
      stripes: { palette: ['#F1EEDC', '#ABD76B'], count: 16, weights: [1, 1], softness: 0.18, wobble: 0.3 },
      topCavity: { on: true, lip: 0.07, seed: 42 },
      topSpiral: { on: true, turns: 5, rise: 0.018, seed: 7 },
      /* ⚠️ THE SEED AND THE ELEMENT ID MATTER AS MUCH AS THE PALETTE. The band is thirty strokes of
         seeded noise re-derived on every render, so losing the seed does not come back a plainer
         cake — it comes back a DIFFERENT one. And `elementId` is what carries the catalogue row into
         a template bundle, which finds its elements by scanning the design for uuids. */
      /* The hand-drawn list, beside the band: two strokes so a list that round-trips its first entry
         and drops the rest cannot look identical to a working one. */
      brushStrokes: [
        { id: 'bs1', at: 0.1, rise: 0.02, climb: 0.42, sweep: 0.01, bow: -0.2,
          width: 0.3, weight: 0.18, seed: 11, color: '#B24A63' },
        { id: 'bs2', at: 0.2, rise: 0.05, climb: 0.3, sweep: -0.01, bow: 0,
          width: 0.26, weight: 0.4, seed: 18, color: '#8EC5E8' },
      ],
      brushBand: { elementId: '0f1e2d3c-4b5a-6978-8796-a5b4c3d2e1f0', seed: 4213,
                   colors: ['#B24A63', '#F6DCE2'], count: 30, overlap: 0.35,
                   weight: 0.18, sweep: 0, climb: 0.42, bow: -0.2 },
      glaze: { colors: ['#2a1810'], flow: 2 },
      dusting: { splashes: [{ u: 0.2, v: 0.4 }], color: '#d4af37' },
      foil: { flakes: [{ u: 0.1, v: 0.3 }], finish: 'gold' },
      grass: { color: '#4caf3d', height: 0.2, overhang: 0.5, patches: [{ u: 0.1, v: 0.5, r: 0.3 }] },
      // Two of them, and deliberately different arrangements: a list that round-trips its first entry
      // and drops the rest looks identical to a working one on any cake with a single rainbow.
      rainbows: [
        { id: 'r1', surface: 'top', footLeft: 'top', footRight: 'board', offsetX: 0.71, scale: 1,
          bands: 6, colors: ['#F6A9C0', '#F9C9A0'] },
        { id: 'r2', surface: 'side', footLeft: 'board', footRight: 'board', theta: -0.09, scale: 0.75 },
      ],
      clouds: [
        { id: 'c1', variant: 'puff', surface: 'board', yaw: 0.8, standoff: 1.3, lobes: 3, rows: 2 },
        { id: 'c2', variant: 'flat', surface: 'side', theta: -0.4, width: 0.55, depth: 0.08 },
      ],
      creamLayers: [{ id: 'c1', color: '#e0479e', from: 0.1, to: 0.6 }],
      topPipings: [{ layerId: 'p1', glbUrl: 'x.glb', color: '#fff' }],
      bottomPipings: [{ layerId: 'p2', glbUrl: 'y.glb', color: '#eee' }],
    }],
    texts:    [{ id: 't1', content: 'HELLO', theta: 0, y: 0.7, fontSize: 0.2, color: '#e0479e' }],
    ages:     [{ id: 'a1', value: '30', size: 0.95, finish: 'gold' }],
    /* ⚠️ A CALENDAR AMONG THEM, for the reason `toppers` below is a real one: an absent key cannot be
       seen to be lost. A calendar's DATE lives on the instance (`calendarValues`) and its recipe on
       `calendar` — neither is derivable from anything else, so if a serialiser ever stops carrying
       them the cake comes back showing a date nobody chose. That failure is silent: the calendar
       still draws, just not the customer's. Both sides pass stickers through wholesale today, which
       is exactly why this has to be pinned now rather than after it breaks. */
    stickers: [{ id: 's1', elementId: 'e1', imageUrl: 'lion.glb', zone: 'top_surface', tierIndex: 0, x: 0, z: 0, scale: 1 },
               { id: 's2', elementId: 'e2', imageUrl: null, zone: 'top_surface', tierIndex: 0, x: 0, z: 0, scale: 1,
                 calendar: { layout: 'round', medium: 'piped', ink: '#1A1A1A', accent: '#D8342B',
                             paper: null, ringStyle: 'heart' },
                 calendarValues: { year: 2026, month: 12, day: 25 } }],
    writings: [{ id: 'w1', text: 'Happy Birthday', font: 'script', surface: 'top', color: '#ffffff' },
               { id: 'w2', text: 'Love, Mum',      font: 'script', surface: 'board', color: '#e0479e' }],
    piping:   [{ id: 'k1', points: [[0, 0], [1, 1]], color: '#fff' }],
    boardGrass: { color: '#3f9c33', height: 0.16, ringWidth: 0.8, patches: [{ u: 0.5, v: 0.9, r: 0.3 }] },
    nameBlocks: { zone: 'board', text: 'CAKE', size: 0.3, blockColor: '#f7f5f2',
                  blocks: [{ char: 'C', u: 0.1, v: 0.9, yaw: 0.6 }] },
    garnishes: [{ id: 'g1', kind: 'piped', theta: 0.4, radius: 0.5, mode: 'stand', zone: 'top',
                  paths: [[[10, 10], [40, 40]]], rings: [], color: '#4A2C1B', rope: 6, plate: 420,
                  parts: [{ color: '#4A2C1B', paths: [[[10, 10], [40, 40]]], rings: [] }] }],
    /* ⚠️ A REAL ONE, because an absent key cannot be seen to be lost. `toppers` was hydrated and
       never saved, and the structural check below — written after `garnishes` to stop exactly that
       — compared an empty array against an empty array and passed. A topper's PAYLOAD is the thing
       that has to survive, not just the row: it is the words, and a template whose topper comes back
       blank is a template with a blank card on it. */
    toppers:  [{ id: 'ct1', name: 'Ten', theta: 0.2, radius: 0.35, yaw: 0, mode: 'stand', scale: 1,
                 tierIndex: 0,
                 payload: { v: 1, stick: { on: true, bury: 0.5 }, objects: [
                   { id: 1, kind: 'text', text: '10', size: 1.2, x: 0, y: 0, face: '__block',
                     colour: '#D94F6E', offset: 0.08, offsetColour: '#FFFFFF' },
                 ] } }],
  };

  const roundTrip = d => normalizeDesign(buildDesignSnapshot(d));

  it('reaches the renderer with every field intact', () => {
    expect(toCanvasConfig(roundTrip(FULL))).toEqual(toCanvasConfig(FULL));
  });

  /* ── The guard that does not depend on remembering ──────────────────────────────────────────
   *
   * ⚠️ EVERY TEST ABOVE CAN ONLY CHECK A FIELD SOMEBODY PUT IN `FULL`, which is the same act of
   * remembering that fails in designSnapshot.js — so the round-trip has now missed the loss it was
   * written to catch, twice in one go: `topCavity` and `topSpiral` reached the renderer, never
   * reached OPTIONAL_TIER_FIELDS, and every test here passed while a saved template came back plain.
   * That is five fields lost the same way (glaze, grass, creamLayers, and these two), each followed
   * by a comment asking the next person to be more careful.
   *
   * So this one DERIVES the answer instead. It hands `toCanvasConfig` a tier that records every key
   * the renderer touches, and asserts the snapshot carries all of them. Add a field to the renderer
   * and forget the list, and this fails naming the key — without anyone having to extend a fixture.
   */
  it('carries every tier field the renderer actually reads', () => {
    /* Written unconditionally by buildDesignSnapshot, so they need no entry on the optional list. */
    const ALWAYS = ['color', 'topPipings', 'bottomPipings'];

    const read = new Set();
    const watch = t => new Proxy(t, {
      get(o, k) { if (typeof k === 'string') read.add(k); return o[k]; },
      has(o, k) { if (typeof k === 'string') read.add(k); return k in o; },
    });
    /* A tier carrying EVERY key the designer can put on one, so a reader that guards with `?.` or
       `in` is still seen to have read it. */
    const everything = { ...FULL.tiers[0] };
    for (const k of OPTIONAL_TIER_FIELDS) if (!(k in everything)) everything[k] = null;
    toCanvasConfig({ ...FULL, tiers: [watch(everything)] });

    const carried = new Set([...OPTIONAL_TIER_FIELDS, ...ALWAYS]);
    const lost = [...read].filter(k => !carried.has(k)).sort();
    expect(lost).toEqual([]);
  });

  // Named individually as well as in the whole-config check above, so a failure says WHICH element
  // type was lost rather than printing two large objects and leaving you to diff them.
  for (const key of ['grass', 'creamLayers', 'dusting', 'foil', 'gradient', 'glaze', 'styleParams', 'rainbows', 'clouds', 'topCavity', 'topSpiral', 'brushBand', 'brushStrokes']) {
    it(`tier.${key} survives`, () => {
      expect(roundTrip(FULL).tiers[0][key]).toEqual(FULL.tiers[0][key]);
    });
  }

  for (const key of ['boardGrass', 'nameBlocks', 'writings', 'texts', 'ages', 'stickers', 'piping', 'garnishes', 'toppers']) {
    it(`design.${key} survives`, () => {
      expect(roundTrip(FULL)[key]).toEqual(FULL[key]);
    });
  }

  /* ⚠️ THE LIST ABOVE IS A LIST SOMEBODY HAS TO REMEMBER TO EXTEND, and twice now nobody did: the
     legacy `writing`, and then `garnishes` — hydrated on the way in, dropped on the way out, so a
     placed chocolate piece vanished when the design was saved and nothing failed loudly. This asks
     the question structurally instead. Whatever `normalizeDesign` decides a design HAS, saving and
     reloading must give back; a new decoration type that never reaches the snapshot fails here on
     the day it is added rather than on the day a baker notices their cake is missing something. */
  it('every field the design carries survives a save, including ones added later', () => {
    const hydrated = normalizeDesign(FULL);
    const saved = roundTrip(FULL);
    const lost = Object.keys(hydrated).filter(k => k !== 'tiers'
      && JSON.stringify(saved[k]) !== JSON.stringify(hydrated[k]));
    expect(lost).toEqual([]);
  });

  // A message became a LIST on 2026-08-22. Every template and order saved before that holds a single
  // nullable `writing` OBJECT, and those are not ours to rewrite — a saved order is a record of what
  // somebody bought. So the promotion is the compatibility guarantee, and it is asserted rather than
  // assumed: drop it and every old cake silently loses its message on load, with nothing to see.
  it('a legacy single `writing` object is promoted to the writings list', () => {
    const legacy = { ...FULL, writing: { text: 'Happy Birthday', font: 'script', surface: 'top', color: '#ffffff' } };
    delete legacy.writings;
    const out = roundTrip(legacy).writings;
    expect(out).toHaveLength(1);
    expect(out[0]).toMatchObject({ text: 'Happy Birthday', surface: 'top', color: '#ffffff' });
    expect(out[0].id).toBeTruthy();          // minted on promotion — the list is addressable by id
  });
});
