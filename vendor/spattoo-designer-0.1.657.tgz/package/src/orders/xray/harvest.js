// Pull the X-Ray-relevant bits out of a saved design snapshot.
import { normalizeHex } from './gelLibrary.js';
import { decorationWhat } from './decorationLabel.js';

// The cake board is a hardcoded render constant, not part of the design — and we
// deliberately exclude it from the cream-colour table.
const BOARD_HEX = normalizeHex('#fce8d5');

// Cream-pen messages, whichever shape the snapshot is in. A message became a LIST on 2026-08-22 (a
// cake can carry "9" on the side and a name on the board); every order placed before that stored a
// single nullable `writing` OBJECT, and a saved order is a record of what was ordered — it is never
// rewritten. So both shapes are read here, forever, rather than the old one being migrated away.
function writingList(design) {
  if (Array.isArray(design?.writings)) return design.writings;
  return design?.writing ? [design.writing] : [];
}

const tierLabel = (i, n) => (n === 1 ? 'Cake' : i === 0 ? 'Base tier' : i === n - 1 ? 'Top tier' : `Tier ${i + 1}`);

// Piping was once stored as singular topPiping/bottomPiping; newer designs use
// the topPipings/bottomPipings arrays. Normalize so X-Ray works on old orders.
const topList = (t) => t?.topPipings ?? (t?.topPiping ? [t.topPiping] : []);
const bottomList = (t) => t?.bottomPipings ?? (t?.bottomPiping ? [t.bottomPiping] : []);

// Friendly mapping for the freehand Cream Pen's internal nozzle keys → real tip.
const FREEHAND_NOZZLE = {
  round:  { shape: 'Round',       tip: 'Round / writing tip (e.g. Wilton 3–5)' },
  bead:   { shape: 'Round bead',  tip: 'Round tip (e.g. Wilton 10–12)' },
  star5:  { shape: 'Open star',   tip: 'Open star (e.g. Wilton 1M / 18)' },
  star6:  { shape: 'Open star',   tip: 'Open star (e.g. Wilton 2D / 32)' },
  drop:   { shape: 'Drop flower', tip: 'Drop flower (e.g. Wilton 2D)' },
  closed: { shape: 'Closed star', tip: 'Closed star (e.g. Wilton 30 / 35)' },
  jumbo:  { shape: 'Jumbo star',  tip: 'Large open star (e.g. Wilton 8B)' },
  french: { shape: 'French star', tip: 'French star (e.g. Ateco 863)' },
  fine:   { shape: 'Fine French', tip: 'Fine French star (e.g. Ateco 861)' },
};

// Deduped cream colours used across the design (board excluded).
// Returns [{ hex, uses: [string] }] in first-seen order.
export function harvestColors(design) {
  const tiers = design?.tiers ?? [];
  const n = tiers.length;
  const map = new Map(); // hex → Set(uses)
  const add = (raw, use) => {
    const hex = normalizeHex(raw);
    if (!hex || hex === BOARD_HEX) return;
    if (!map.has(hex)) map.set(hex, new Set());
    map.get(hex).add(use);
  };

  tiers.forEach((t, i) => {
    add(t?.color, `${tierLabel(i, n)} icing`);
    [...topList(t), ...bottomList(t)].forEach(p => add(p?.color, `Piping (${tierLabel(i, n)})`));
  });
  (design?.piping ?? []).forEach(p => add(p?.color, 'Cream pen'));
  (design?.texts ?? []).forEach(t => add(t?.color, 'Text'));
  writingList(design).forEach(w => add(w?.color, 'Message'));
  // stickers (current) and decorations (legacy) — only when they carry a colour.
  [...(design?.stickers ?? []), ...(design?.decorations ?? [])].forEach(s => { if (s?.color) add(s.color, s?.name || 'Decoration'); });

  return [...map.entries()].map(([hex, uses]) => ({ hex, uses: [...uses] }));
}

// Piping instances that reference a library element (→ craft-guide lookup) plus
// freehand cream-pen strokes (nozzle is in-snapshot already).
// Returns { elements: [...], freehand: [...], elementIds: [unique] }.
export function harvestPiping(design) {
  const tiers = design?.tiers ?? [];
  const n = tiers.length;
  const elements = [];
  const ids = new Set();

  tiers.forEach((t, i) => {
    const zones = [['top', topList(t)], ['bottom', bottomList(t)]];
    zones.forEach(([zone, list]) => {
      (list ?? []).forEach(p => {
        if (!p?.id) return;
        ids.add(p.id);
        elements.push({
          elementId: p.id,
          name: p.name || 'Piping',
          color: normalizeHex(p.color),
          tier: tierLabel(i, n),
          tierIndex: i,
          tierCount: n,
          zone: zone === 'top' ? 'Rim' : 'Base',
          // Photo orders only: where the model saw this border on the reference image. Carried
          // rather than derived, because the leader-line anchor for a photo cannot be computed —
          // there is no camera to project through, only the box the model reported.
          bbox: p.bbox ?? null,
          // Photo orders only: the model's own read of the technique. A FALLBACK for when no
          // curated nozzle exists — never a substitute for one, and rendered so the difference is
          // visible.
          seenTechnique: p.technique ?? null,
        });
      });
    });
  });

  // ── A hand-piped run is the SAME element as its ring ────────────────────────────────────────
  // A stamped stroke carries the element's own id, so it earns the element's own craft guide — the
  // very nozzle a ring of it would use — and a leader line on the diagram beside the rings.
  //
  // Sent down the freehand path instead (which is where it went), it reported a generic cream-pen
  // tip nobody had chosen, and appeared on no diagram at all: `diagram` is built from `elements`,
  // and freehand entries were never in it. That is the "nozzle given, diagram missing" case.
  (design?.piping ?? []).forEach((p, idx) => {
    if (!p?.stampId) return;
    ids.add(p.stampId);
    const ti = typeof p.tierIndex === 'number' ? p.tierIndex : 0;
    // Rim or Base only decides where the leader line points. Read off the surface the stroke was
    // drawn against rather than guessed: work on the cake TOP belongs at the rim line, work down
    // the wall belongs lower. The label the baker reads is `zoneLabel`, which says neither.
    const onTop = Math.abs(p?.normal?.[1] ?? 1) > 0.7;
    elements.push({
      elementId: p.stampId,
      name: p.stampName || 'Piping',
      color: normalizeHex(p.color),
      tier: tierLabel(ti, n),
      tierIndex: ti,
      tierCount: n,
      zone: onTop ? 'Rim' : 'Base',
      // What the SHEET says. "Cake · Rim" would claim a border that is not there — this run is
      // wherever the customer drew it, and calling it a rim ring would send a baker to pipe one.
      zoneLabel: 'Hand-piped',
      bbox: null,
      seenTechnique: null,
    });
  });

  // Cream-pen strokes only — a stamped one is an element, harvested above. Left in here it would be
  // counted twice AND credited with a nozzle nobody picked.
  const freehand = (design?.piping ?? []).filter(p => !p?.stampId).map((p, idx) => {
    const m = FREEHAND_NOZZLE[p?.nozzle] ?? FREEHAND_NOZZLE.round;
    const ti = p?.tierIndex;
    return {
      key: p?.id ?? `fh-${idx}`,
      shape: m.shape,
      tip: m.tip,
      color: normalizeHex(p?.color),
      tier: typeof ti === 'number' ? tierLabel(ti, n) : null,
    };
  });

  return { elements, freehand, elementIds: [...ids] };
}

// ── Everything that has to be PLACED on the cake ──────────────────────────────
// harvestPiping answers "which nozzle for which piping". This answers a different
// question: what does the baker still have to put on, and have they put it all on?
//
// ── WHY THIS EXISTS SEPARATELY ────────────────────────────────────────────────
// Until now the X-Ray sheet was piping-centric. Stickers, toppers, texts and the age
// numbers appeared nowhere on it — a lion topper is the most visible thing on the cake
// and the easiest to forget, and the sheet said nothing about it. harvestColors touches
// stickers, but only to pull a colour out of them.
//
// ── THE COMPLETENESS TRAP ─────────────────────────────────────────────────────
// A checklist makes a claim the rest of the report does not: that this is EVERYTHING.
// If it enumerates six collections and the design grows a seventh, the sheet quietly
// gets shorter, the baker trusts it, and a decoration ships missing. A checklist that
// silently omits is worse than no checklist, because it is believed.
//
// So the source list is written out ONCE, explicitly, right here — every placeable
// collection in DEFAULT_DESIGN (useCakeDesign.js), including the two easiest to miss:
// `writing`, which is a SINGLE OBJECT rather than an array, and `ages`, which is the
// kind of thing added later and forgotten. If you add a placeable collection to the
// design, add it here in the same change.
//
//   tiers[].topPipings / .bottomPipings   piped rim + base borders
//   design.stickers                       decorations, toppers, decals  ← the lion
//   design.decorations                    legacy stickers (pre-migration designs)
//   design.texts                          text on the cake
//   design.ages                           gold 3D balloon numbers
//   design.writings                       cream-pen messages (LIST; older designs: `writing`, one
//                                         nullable object — see writingList)
//   design.piping                         freehand cream-pen strokes
//
// ── ORDER ─────────────────────────────────────────────────────────────────────
// Grouped by tier, BOTTOM UP, because that is the order a cake is assembled in — the
// list should read in the order the hand works, not alphabetically or by type. Items
// that belong to the whole cake rather than one tier (texts, ages, writing, freehand)
// come last, under "Finishing", which is also when they actually go on.
//
// Deduped by (what · where) with a count, reusing the rule report.js already applies to
// piping: six scattered sprinkles of one element are ONE line reading "× 6". Nobody
// ticks the same box six times.
export function harvestPlaceables(design) {
  const tiers = design?.tiers ?? [];
  const n = tiers.length;
  const groups = [];

  const push = (bucket, what, where, key) => {
    const found = bucket.items.find(i => i.key === key);
    if (found) { found.count++; return; }
    bucket.items.push({ key, what, where, count: 1 });
  };

  // Per tier, bottom up.
  tiers.forEach((t, i) => {
    const bucket = { title: tierLabel(i, n), items: [] };

    topList(t).forEach(p => push(bucket, p?.name || 'Piping', 'Rim', `pipe-top-${p?.id ?? p?.name}`));
    bottomList(t).forEach(p => push(bucket, p?.name || 'Piping', 'Base', `pipe-bot-${p?.id ?? p?.name}`));

    // Stickers and legacy decorations carry their own tierIndex, so they are filtered
    // per tier rather than collected globally — the checklist has to say WHICH tier the
    // lion goes on, or it does not save anyone a decision.
    [...(design?.stickers ?? []), ...(design?.decorations ?? [])]
      .filter(s => (s?.tierIndex ?? 0) === i)
      /* ⚠️ WHAT THE MODEL SAW, NOT WHAT IT MATCHED. This read `s.name` — the matched library
         element — and on a photo order that match is a guess scored against a 0.35 floor. A real
         cake's wide fondant hat came through the checklist as "Elephant" while the Decorations
         section of the same sheet called it "flower on the top": two names for one object, three
         lines apart, and the wrong one on the half a baker ticks at the bench. `seen` is written
         beside the match for exactly this; see decorationLabel.js. `name` still wins on a DESIGNED
         order, where the sticker is a library element the customer actually placed. */
      .forEach(s => push(
        bucket,
        decorationWhat(s),
        s?.zone ? String(s.zone).replace(/_/g, ' ') : null,
        `deco-${s?.elementId ?? s?.name}-${s?.zone ?? ''}`,
      ));

    if (bucket.items.length) groups.push(bucket);
  });

  // Whole-cake items. Last, because that is when they go on.
  const finishing = { title: 'Finishing', items: [] };

  (design?.texts ?? []).forEach((t, idx) => push(
    finishing,
    t?.content ? `Text — "${t.content}"` : 'Text',
    null,
    `text-${t?.id ?? idx}`,
  ));

  (design?.ages ?? []).forEach((a, idx) => push(
    finishing,
    `Number "${a?.value ?? ''}"`.replace(' ""', ''),
    a?.finish ? `${a.finish} topper` : 'topper',
    `age-${a?.id ?? idx}`,
  ));

  writingList(design).forEach((w, idx) => {
    if (w?.text) push(finishing, `Message — "${w.text}"`, 'cream pen', `writing-${w.id ?? idx}`);
  });

  // ── One line per JOB, not per stroke ────────────────────────────────────────────────────────
  // The key used to be the stroke's own id, so a border piped as twenty-eight drags became
  // twenty-eight identical checklist items — a sheet nobody can tick and a count ("29 items") that
  // says nothing about how much work there is.
  //
  // A baker fits one nozzle, mixes one colour, and pipes until it is done. That is the unit, so the
  // key is what would make them stop and change something: the tier, the colour, and what is on the
  // nozzle. `push` already merges on the key and keeps a count, so the line comes out with ×28.
  (design?.piping ?? []).forEach((p) => {
    const what = p?.stampId
      ? `${p.stampName || 'Decoration'} — piped by hand`
      : 'Freehand piping';
    push(
      finishing,
      what,
      typeof p?.tierIndex === 'number' ? tierLabel(p.tierIndex, n) : 'cream pen',
      `fh-${p?.stampId ?? p?.nozzle ?? 'round'}-${normalizeHex(p?.color) ?? ''}-${p?.tierIndex ?? 'x'}`,
    );
  });

  // ── Procedural decorations ──────────────────────────────────────────────────────────────────
  // Rainbows, clouds, grass and letter blocks are BUILT rather than placed as a model, so they live
  // in their own per-tier collections instead of design.stickers — and this file enumerated the
  // collections it knew about, so all four were missing from the sheet entirely. A cake whose most
  // visible decoration is a rainbow said nothing about the rainbow.
  //
  // The comment at the top of this function calls that the completeness trap, and it happened
  // anyway. Hence proceduralPlacements() below: ONE list of the collections, so a new procedural
  // decoration is added in a place that is obviously about being complete.
  proceduralPlacements(design, n).forEach(p => push(finishing, p.what, p.where, p.key));

  if (finishing.items.length) groups.push(finishing);

  return groups;
}

// Every BUILT decoration on the cake, per tier. Kept beside the checklist AND the guide harvest so
// the two can never disagree about what is on the cake.
//
// `elementId` is what a craft guide is looked up by. It is null on anything placed before the
// designer started recording it, and that is not fixable after the fact — an order saved then simply
// does not know which rainbow it was. New ones do.
export function proceduralPlacements(design, tierCount) {
  const n = tierCount ?? (design?.tiers?.length ?? 1);
  const out = [];
  const add = (item, label, tierIndex, kind, idx) => {
    if (!item) return;
    out.push({
      what: item.elementName || label,
      where: tierLabel(tierIndex, n),
      key: `${kind}-${item.id ?? idx}`,
      elementId: item.elementId ?? null,
    });
  };
  (design?.tiers ?? []).forEach((t, i) => {
    (t?.rainbows ?? []).forEach((r, k) => add(r, 'Rainbow', i, 'rb', k));
    (t?.clouds ?? []).forEach((c, k) => add(c, 'Cloud', i, 'cl', k));
    if (t?.grass) add(t.grass, 'Piped grass', i, 'grass', 0);
  });
  if (design?.nameBlocks) add(design.nameBlocks, 'Letter blocks', 0, 'blocks', 0);
  /* ⚠️ A GARNISH BELONGS ON THE CHECKLIST — it is a decoration a baker must MAKE, which is the whole
     point of this list — but its `elementId` is deliberately NOT carried. Every id here is used to
     fetch a written craft guide, and a garnish already has a better one derived from its own paths;
     asking for both would print a vague guide beside the true one. The id all garnishes share is the
     palette element ("Chocolate drawing"), so the written guide could not be about this piece
     anyway. */
  (design?.garnishes ?? []).forEach((g, k) => out.push({
    what: g.name || 'Chocolate garnish',
    where: g.zone === 'board' ? 'Board' : tierLabel(n - 1, n),
    key: `garnish-${g.id ?? k}`,
    elementId: null,
  }));
  return out;
}
