import { useEffect, useState } from 'react';
import { ChevronRightIcon } from '../shared/icons.jsx';
import { creditsChanged } from './creditsBus.js';
import { Panel } from '../shared/Panel.jsx';
import { Disclosure } from '../shared/Disclosure.jsx';

// ── Buy credits ──────────────────────────────────────────────────────────────────────
// A screen about ONE thing: how many credits you have and how to get more.
//
// It exists because the top-up shelf used to live inside the Billing panel, and sending a baker
// there to buy credits put them in front of their subscription, their plan, their invoices and a
// change-plan button. Someone who wanted 400 credits was suddenly being asked to think about
// whether to upgrade — a much bigger, much scarier question, and not the one they had.
//
// Billing keeps the READOUT (balance, meter, what each tool costs) because that belongs beside the
// plan it comes with. Buying moved here. One shelf, in one place, so the two cannot drift.
export default function BuyCreditsPanel({ open, onClose, apiClient, primaryColor = '#3D5A44' }) {
  const [data, setData]   = useState(null);
  const [packs, setPacks] = useState([]);
  const [shelf, setShelf] = useState(null);
  const [busyPack, setBusy] = useState(null);
  const [err, setErr]     = useState(null);
  const [tick, setTick]   = useState(0);

  // ── After checkout ───────────────────────────────────────────────────────────────
  // Credits are minted by the payment WEBHOOK, so they do not exist the moment Checkout closes.
  // That gap is the whole design problem here: a baker has just paid, and the one thing they need
  // is to be told it worked.
  //
  // So the panel does NOT close. It becomes the confirmation — three honest states:
  //   'waiting'  paid, credits not here yet
  //   'done'     the balance actually moved, by how much
  //   'slow'     we stopped looking before they arrived
  //
  // It never auto-closes. A panel that vanishes by itself reads as a dismissal, and with unlucky
  // timing it disappears before the confirmation can be read.
  const [phase, setPhase] = useState(null);     // null | 'waiting' | 'done' | 'slow'
  const [gained, setGained] = useState(0);
  const [lastPaymentId, setLastPaymentId] = useState(null);
  const [history, setHistory] = useState(null);   // null = not loaded yet, [] = nothing to show
  const [allHistory, setAllHistory] = useState(false);   // expanded past the first few rows
  const [nextBefore, setNextBefore] = useState(null);    // cursor; null once the server says "that is all"
  const [loadingMore, setLoadingMore] = useState(false);

  useEffect(() => {
    if (!open || !apiClient?.fetchAiCredits) return;
    let alive = true;
    Promise.all([
      apiClient.fetchAiCredits().catch(() => null),
      apiClient.fetchAiCreditPacks ? apiClient.fetchAiCreditPacks().catch(() => null) : Promise.resolve(null),
    ]).then(([bal, pk]) => {
      if (!alive) return;
      setData(bal);
      setPacks(pk?.packs ?? []);
      setShelf(pk ? { canBuy: pk.canBuy, reason: pk.reason, ceiling: pk.ceiling, resetsOn: pk.resetsOn } : null);
    });
    return () => { alive = false; };
  }, [open, apiClient, tick]);

  // The ledger, loaded separately from the balance: it is the slower of the two and the balance is
  // what someone opened this for, so it must not wait behind a list.
  useEffect(() => {
    if (!open || !apiClient?.fetchAiCreditHistory) return;
    let alive = true;
    apiClient.fetchAiCreditHistory()
      .then(r => { if (!alive) return; setHistory(r?.items ?? []); setNextBefore(r?.nextBefore ?? null); })
      .catch(() => { if (alive) setHistory([]); });   // a missing ledger hides the section, never errors
    return () => { alive = false; };
  }, [open, apiClient, tick]);

  if (!open) return null;

  async function buy(packKey) {
    setBusy(packKey); setErr(null);
    try {
      const d = await apiClient.purchaseAiCredits(packKey);
      if (!window.Razorpay) {
        await new Promise((resolve, reject) => {
          const s = document.createElement('script');
          s.src = 'https://checkout.razorpay.com/v1/checkout.js';
          s.onload = resolve; s.onerror = reject;
          document.head.appendChild(s);
        });
      }
      await new Promise(resolve => {
        // A one-time ORDER, not a subscription — order_id + amount, where a plan checkout passes
        // subscription_id. That is why this cannot reuse the plan checkout helper.
        const rzp = new window.Razorpay({
          key: d.key_id, order_id: d.order_id, amount: d.amount, currency: d.currency ?? 'INR',
          name: 'Spattoo',
          // Razorpay's Price Summary shows ONE figure and we cannot add rows to it — the panel is
          // theirs. `description` is the only text we control on that screen, so the split rides
          // there: a baker who reached Checkout expecting ₹149 can see where ₹175.82 came from
          // without going back. `d` carries the breakup from the same server function that computed
          // the charge, so this line cannot disagree with the amount beside it.
          description: gstLine(d, packs.find(p => p.packKey === packKey)?.credits),
          theme: { color: primaryColor },
          handler: (resp) => {
            setLastPaymentId(resp?.razorpay_payment_id ?? null);
            resolve();
            // The balance BEFORE the purchase, captured here rather than read later: waiting until
            // after the first poll would race the webhook and could baseline against the new value.
            settle(data?.spendable ?? 0);
          },
          modal: { ondismiss: resolve },
        });
        rzp.open();
      });
    } catch (e) { setErr(e.message || 'Could not start the payment.'); }
    finally { setBusy(null); }
  }

  // Poll until the balance CHANGES, not merely until we have refetched.
  //
  // Comparing against the pre-purchase balance is what makes "arrived" a fact rather than a guess —
  // the old version re-read five times and assumed, so it could not tell success from silence and
  // showed the same screen for both.
  //
  // Backs off rather than hammering: a webhook is usually a second or two, occasionally much longer
  // when Razorpay retries. ~30s of looking, then say so plainly instead of pretending.
  async function settle(before) {
    setPhase('waiting');
    const waits = [1200, 1500, 2000, 2500, 3000, 4000, 5000, 5000, 5000];
    for (const wait of waits) {
      await new Promise(r => setTimeout(r, wait));
      const fresh = await apiClient.fetchAiCredits().catch(() => null);
      creditsChanged();                    // the header readout is a different component
      if (fresh) setData(fresh);
      const now = fresh?.spendable ?? before;
      if (now > before) {
        setGained(now - before);
        setPhase('done');
        return;
      }
    }
    // Not a failure, and must not be dressed as one — the payment is captured and the credits are
    // coming. But saying NOTHING here is the worst option: an unchanged balance with no explanation
    // is indistinguishable from having been charged for nothing.
    setPhase('slow');
  }

  // Fetch the next page and append. Keyset, so this cannot double-count a row when a credit is
  // spent mid-scroll the way an offset page would.
  async function loadMore() {
    if (loadingMore || !nextBefore) return;
    setLoadingMore(true);
    try {
      const r = await apiClient.fetchAiCreditHistory(nextBefore);
      setHistory(h => [...(h ?? []), ...(r?.items ?? [])]);
      // Trust the server's answer about whether there is more, including when it says no.
      setNextBefore(r?.nextBefore ?? null);
    } catch {
      setNextBefore(null);           // stop offering something that is not working
    } finally { setLoadingMore(false); }
  }

  // Reopening is a fresh visit: the last purchase's confirmation must not be the first thing a
  // baker sees three days later.
  function close() {
    setPhase(null); setGained(0); setLastPaymentId(null);
    setAllHistory(false); setNextBefore(null);   // the ledger collapses again, like every other section
    setTick(t => t + 1);          // so the next open re-reads rather than showing a stale balance
    onClose?.();
  }

  const spendable = data?.unlimited ? null : (data?.spendable ?? 0);
  // `data` is null until the fetch lands, and `?? 0` collapsed that into a real-looking ZERO — so
  // the first thing a baker saw on opening was "0 credits to spend", which is the one number that
  // would make them stop what they were doing. Not-loaded and none-left must never render alike.
  const loading = !data;

  /* ⚠️ "Smart tool credits", not "Credits" — SUBSCRIPTION_TIERS.md: name the JOB, never "AI", and
     never so short it names nothing. The pill's own tooltip has always said "Smart tool credits —
     N left", so the two halves of the same gesture disagreed; that was invisible while the only way
     in was an unlabelled number, and stopped being invisible the moment Settings → Top-ups grew a
     row SAYING "Smart tool credits" that opened a panel headed "Credits". */
  return (
    <Panel onClose={close} title="Smart tool credits" width={420} bodyPadding={18}>
      <style>{PACK_CSS}</style>
      {/* One wrapper because the panel body is the scroller, and the loading state needs a floor:
          without it the panel opens as a small box and grows as the balance arrives, which reads as
          two different windows. Sized to roughly what the loaded panel occupies. */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14, ...(loading ? { minHeight: 260 } : null) }}>

        {/* The number first and large. It is the question that brought them here — which is also
            why a placeholder beats a guess: a wrong balance shown for one second is read, and
            believed, before the right one arrives. */}
        <div style={s.balance}>
          {loading
            ? <div style={s.numSkeleton} aria-hidden="true" />
            : <div style={{ fontSize: 34, fontWeight: 800, color: '#2C4433', fontVariantNumeric: 'tabular-nums' }}>
                {data.unlimited ? 'Unlimited' : spendable}
              </div>}
          {(loading || !data.unlimited) && (
            <div style={{ fontSize: 12, color: loading ? '#C3CBC6' : '#7C8B82', fontWeight: 600 }}>
              credits to spend
            </div>
          )}
        </div>

        {/* ⚠️ WHAT A CREDIT IS FOR, BEFORE ANY NUMBER ABOUT IT. The panel went straight from "800
            credits to spend" to a price list reading "X-Ray — read a cake photo", which assumes the
            reader already knows what a smart tool is and what X-Ray means. A baker who has just
            signed up knows neither, and this is the screen where they are deciding to spend money.
            Sandeep: "for a new user, he wont have any clue what these credits are used for."

            Three examples, not all six — the list below is the full set with its prices, and a lede
            that enumerates everything is a second price list nobody reads. */}
        {!loading && (
          <Disclosure label="How are these credits used?">
            Smart tools do a slow job for you — turning a customer&rsquo;s photo into a cake design,
            writing an enquiry up as an order, or working out how a decoration was made. Each one
            spends a few credits, and what each costs is listed below.
          </Disclosure>
        )}

        {/* ── The two buckets ──────────────────────────────────────────────────────────
            The headline number is a SUM of two things with different rules — one resets on the
            1st, one never expires — and showing only the total means a baker watching it fall
            cannot tell whether they are running out of something that comes back next month or
            something they paid for.
            Shown whenever the account HAS a monthly allowance, not only when they have bought
            credits: "bought 0" is the answer to "what happens when the monthly ones run out". */}
        {!data?.unlimited && data?.allowance > 0 && (
          <div style={s.split}>
            <div style={s.splitRow}>
              <div>
                <div style={s.splitLabel}>Monthly</div>
                <div style={s.splitSub}>
                  of {data.allowance} · resets {formatResetDate(data.resetsOn)}
                </div>
              </div>
              <div style={s.splitNum}>{data.allowanceLeft ?? 0}</div>
            </div>
            <div style={s.splitRow}>
              <div>
                <div style={s.splitLabel}>Bought</div>
                <div style={s.splitSub}>never expire</div>
              </div>
              <div style={s.splitNum}>{data.walletBalance ?? 0}</div>
            </div>
            {/* The spend ORDER, said plainly. It is what makes the two numbers above mean
                something, and it is a promise in the terms (B8.2) rather than an implementation
                detail — so it belongs where the numbers are, not in a help page. */}
            <div style={{ fontSize: 11, color: '#9BB5A2', fontWeight: 600, paddingTop: 2 }}>
              Monthly credits are used first.
            </div>
          </div>
        )}

        {/* WHAT THEY BUY, before what they cost. A pack is meaningless without knowing what a
            credit does, and this is the one screen where someone is deciding to spend money.
            The heading is not decoration: without it the list ran straight on from the balance
            breakdown and read as more numbers about the balance. */}
        {(data?.actions ?? []).length > 0 && (
          <div>
            <h4 style={s.listHead}>What each one costs</h4>
            <div style={s.priceList}>
            {data.actions.map(a => (
              <div key={a.actionKey} style={s.priceRow}>
                <span style={{ color: '#4A5D51', fontWeight: 600 }}>{a.label}</span>
                <span style={{ color: '#7C8B82', fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>
                  {a.credits} credits
                </span>
              </div>
            ))}
            </div>
          </div>
        )}

        {/* Two gates, two different sentences. "Your plan doesn't include this" points at an
            upgrade; "you're already well stocked" points at nothing and must not read as refusal. */}
        {!phase && shelf && !shelf.canBuy && (
          <div style={s.note}>
            <div style={{ fontSize: 12.5, fontWeight: 800, color: '#2C4433' }}>
              Your credits refresh on {formatResetDate(shelf.resetsOn)}
            </div>
            <div style={{ fontSize: 12, color: '#7C8B82', fontWeight: 600, lineHeight: 1.5, marginTop: 4 }}>
              Blaze includes top-ups — add credits whenever you need them, and they never expire.
            </div>
          </div>
        )}

        {!phase && shelf?.canBuy && shelf.reason === 'stocked' && (
          <div style={s.note}>
            <div style={{ fontSize: 12, color: '#7C8B82', fontWeight: 600, lineHeight: 1.5 }}>
              <strong style={{ color: '#2C4433' }}>You’re well stocked.</strong> You can add more
              once your bought balance drops below {shelf.ceiling}.
            </div>
          </div>
        )}

        {/* ── After a payment ─────────────────────────────────────────────────────────
            Everything below stands in for the packs while a purchase is settling or has just
            settled. Buying again is not the next thing anyone wants here, and offering it beside
            an unconfirmed payment invites paying twice. */}
        {phase === 'waiting' && (
          <div style={s.note}>
            <div style={{ fontSize: 13, fontWeight: 800, color: '#2C4433' }}>Payment received</div>
            <div style={{ fontSize: 12, color: '#7C8B82', fontWeight: 600, lineHeight: 1.5, marginTop: 4 }}>
              Adding your credits… this usually takes a few seconds.
            </div>
          </div>
        )}

        {phase === 'done' && (
          <>
            {/* The number they bought, said back to them. The big balance above has already
                changed, but "it is bigger than it was" is not the same as being told it worked. */}
            <div style={{ ...s.note, borderColor: '#CFE3D5', background: '#F4FAF6' }}>
              <div style={{ fontSize: 13, fontWeight: 800, color: '#2C4433' }}>
                ✓ {gained} credits added
              </div>
              <div style={{ fontSize: 12, color: '#7C8B82', fontWeight: 600, lineHeight: 1.5, marginTop: 4 }}>
                They never expire, and they are used only after your monthly credits run out.
              </div>
            </div>
            <button type="button" onClick={close}
              style={{ ...s.pack, justifyContent: 'center', cursor: 'pointer', background: primaryColor,
                       border: 'none', color: '#fff', fontSize: 14, fontWeight: 800 }}>
              Done
            </button>
          </>
        )}

        {/* Not an error, and must not be dressed as one — the payment IS captured. But an
            unchanged balance with no explanation is indistinguishable from having been charged
            for nothing, which is the single worst thing this screen could do. */}
        {phase === 'slow' && (
          <>
            <div style={s.note}>
              <div style={{ fontSize: 13, fontWeight: 800, color: '#2C4433' }}>Payment received</div>
              <div style={{ fontSize: 12, color: '#7C8B82', fontWeight: 600, lineHeight: 1.5, marginTop: 4 }}>
                Your credits are taking longer than usual to arrive. They are on their way — nothing
                is lost, and there is no need to pay again.
              </div>
              {/* The one handle they and we share if this has to be chased. */}
              {lastPaymentId && (
                <div style={{ fontSize: 10.5, color: '#B7C4BB', fontWeight: 600, marginTop: 6, userSelect: 'text' }}>
                  Payment {lastPaymentId}
                </div>
              )}
            </div>
            <button type="button" onClick={() => settle(spendable ?? 0)}
              className="spattoo-pack"
              style={{ ...s.pack, justifyContent: 'center', cursor: 'pointer' }}>
              <span style={{ fontSize: 13, fontWeight: 800, color: '#2C4433' }}>Check again</span>
            </button>
          </>
        )}

        {!phase && shelf?.canBuy && packs.length > 0 && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
            {/* Priced in CREDITS, never in jobs. The endpoint also returns `buys` (what a pack is
                worth in each tool) and it stays unused: "+20 decoration guides" would say the pack
                is FOR that one tool, when it spends anywhere. The price list above carries the same
                information without the false earmarking. */}
            {packs.map(p => (
              <button
                key={p.packKey} type="button" onClick={() => buy(p.packKey)}
                disabled={!!busyPack || p.blocked}
                className={p.blocked ? undefined : 'spattoo-pack'}
                style={{ ...(p.blocked ? s.packOff : s.pack),
                         opacity: busyPack && busyPack !== p.packKey ? 0.5 : 1,
                         cursor: (busyPack || p.blocked) ? 'default' : 'pointer' }}
              >
                <div>
                  <div style={{ fontSize: 15, fontWeight: 800, fontVariantNumeric: 'tabular-nums',
                                color: p.blocked ? '#93A69A' : '#2C4433' }}>
                    +{p.credits} credits
                  </div>
                  <div style={{ fontSize: 11.5, fontWeight: 600, marginTop: 2,
                                color: p.blocked ? '#A8B5AC' : '#7C8B82' }}>
                    {p.label} · never expires
                  </div>
                  {/* WHY it cannot be bought, on the tile itself. This was a `title` tooltip, which
                      does not exist on a phone — so on the device most bakers use, a pack was simply
                      unbuyable with no explanation anywhere. */}
                  {p.blocked && (
                    <div style={{ fontSize: 10.5, color: '#B0906A', fontWeight: 700, marginTop: 5, lineHeight: 1.4 }}>
                      Would take you over {shelf?.ceiling} bought credits — available once your
                      balance drops.
                    </div>
                  )}
                </div>
                {/* OUR PRICE leads; the tax qualifies it.
                    Showing the tax-inclusive total as the headline made ₹175.82 look like what a
                    pack costs, when what we charge for it is ₹149 — the number that should anchor
                    a decision, and the one that compares against a competitor's sticker.
                    The qualifier names the RUPEES, not the rate. "+ 18% GST" is arithmetic
                    homework; "+ ₹26.82 GST" is the answer, and a baker deciding whether to spend
                    can add two numbers they can both see. It also means nothing new appears at
                    Checkout — ₹175.82 there is a sum they have already been shown the parts of. */}
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexShrink: 0 }}>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: 15, fontWeight: 800, fontVariantNumeric: 'tabular-nums',
                                  color: p.blocked ? '#A8B5AC' : primaryColor }}>
                      {busyPack === p.packKey ? 'Opening…' : formatMoney((p.basePaise ?? p.pricePaise) / 100)}
                    </div>
                    {p.gstPaise > 0 && busyPack !== p.packKey && (
                      <div style={{ fontSize: 10, color: p.blocked ? '#C3CBC6' : '#B7C4BB', fontWeight: 600, marginTop: 1 }}>
                        + {formatExact(p.gstPaise)} GST
                      </div>
                    )}
                  </div>
                  {/* The verb the tile was missing. A price alone reads as a fact; a price with
                      somewhere to go reads as an offer — and it is what separates these rows from
                      the X-Ray costs above them, which are priced the same way and are NOT buyable.
                      Absent when blocked: an arrow pointing nowhere is worse than no arrow. */}
                  {!p.blocked && (
                    <span style={{ display: 'flex', color: '#C3D3C8' }}><ChevronRightIcon size={17} /></span>
                  )}
                </div>
              </button>
            ))}
            <span style={{ fontSize: 10.5, color: '#B7C4BB', fontWeight: 600 }}>
              Prices exclude GST. The total with tax is shown at checkout, and a tax invoice is
              emailed to you.
            </span>
          </div>
        )}

        {err && <div style={{ fontSize: 12, fontWeight: 700, color: '#C0392B' }}>{err}</div>}

        {/* ── Where the credits went ────────────────────────────────────────────────────
            A metered resource a baker cannot audit is one they have to trust us about. This is
            the surface where "I had 300 and now I have 240" becomes answerable.
            Below the packs deliberately: someone opens this to see what they have or to buy more
            far more often than to reconcile, so the ledger is available without being in the way.
            Absent entirely when there is nothing to show — an empty "Recent activity" heading is
            a worse answer than no heading. */}
        {history?.length > 0 && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            <div style={{ fontSize: 11, fontWeight: 800, color: '#9BB5A2', letterSpacing: 0.4,
                          textTransform: 'uppercase', marginBottom: 4 }}>
              Recent activity
            </div>
            {(allHistory ? history : history.slice(0, 6)).map(h => (
              <div key={h.id} style={s.ledgerRow}>
                <div style={{ minWidth: 0 }}>
                  <div style={s.ledgerLabel}>{h.label}</div>
                  <div style={s.ledgerSub}>
                    {formatStamp(h.at)}
                    {/* The bucket, per row. A spend that straddled both says so rather than being
                        rounded to whichever was larger — that IS the interesting case, and hiding
                        it would make the "monthly first" rule above unverifiable. */}
                    {h.spent && bucketOf(h) && <> · {bucketOf(h)}</>}
                  </div>
                </div>
                <div style={{ ...s.ledgerAmt, color: h.spent ? '#7C8B82' : '#3D5A44' }}>
                  {h.spent ? '−' : '+'}{h.credits}
                </div>
              </div>
            ))}
            {/* ── Seeing all of it ─────────────────────────────────────────────────────
                Two steps behind one control, because they are the same intent — "show me more"
                — and a baker should not have to learn that the first few rows and the older
                pages are fetched differently.
                  collapsed          → reveal the rest of what is already loaded
                  expanded + cursor  → go and fetch the next page
                  expanded, no cursor→ nothing left; the button is gone rather than dead. */}
            {(!allHistory ? history.length > 6 : !!nextBefore) && (
              <button
                type="button"
                onClick={() => (allHistory ? loadMore() : setAllHistory(true))}
                disabled={loadingMore}
                style={{ background: 'none', border: 'none', padding: '8px 0 0',
                         cursor: loadingMore ? 'default' : 'pointer',
                         fontFamily: 'inherit', fontSize: 11.5, fontWeight: 700,
                         color: loadingMore ? '#B7C4BB' : '#7C8B82', textAlign: 'left' }}>
                {loadingMore ? 'Loading…' : allHistory ? 'Load older' : `Show ${history.length - 6} more`}
              </button>
            )}
            {/* Said once, at the bottom, so someone who scrolled to the end knows they reached it
                rather than wondering whether the list gave up. */}
            {allHistory && !nextBefore && !loadingMore && history.length > 6 && (
              <div style={{ fontSize: 10.5, color: '#C3CBC6', fontWeight: 600, padding: '8px 0 0' }}>
                That's your full history.
              </div>
            )}
          </div>
        )}

        {/* Deliberately at the bottom and understated. Someone here wants credits, not a plan
            conversation — but if the real answer IS a bigger plan, the door should not be hidden. */}
        <div style={{ fontSize: 11.5, color: '#B7C4BB', fontWeight: 600, lineHeight: 1.5 }}>
          Monthly credits come with your plan and reset each month. Credits you buy never expire and
          are only used once the monthly ones are gone.
        </div>
      </div>
    </Panel>
  );
}

// Whole rupees for a price list; paise matter once tax is in the number, because ₹175.82 rounded
// to ₹176 is not what the statement will say.
const formatMoney  = (n) => `₹${Number(n).toLocaleString('en-IN')}`;
const formatExact  = (paise) => `₹${(Number(paise || 0) / 100).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

// What Razorpay shows beneath the merchant name. Degrades to the plain thing if the server ever
// sends no breakup — a missing GST line is a worse screen, a WRONG one is a dispute.
function gstLine(d, credits) {
  const head = credits ? `${credits} credits` : 'Credits';
  if (!d?.gstPaise) return head;
  return `${head} · ${formatExact(d.basePaise)} + ${formatExact(d.gstPaise)} GST (${d.ratePct ?? 18}%)`;
}

// Date AND time, because two X-Rays on one afternoon are indistinguishable by date alone and
// "which of those was the one I cancelled" is exactly the question this list answers.
const formatStamp = (iso) => {
  if (!iso) return '';
  try {
    return new Date(iso).toLocaleString('en-IN', {
      day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit', hour12: true,
    });
  } catch { return ''; }
};

// Which bucket paid. Both non-zero is a STRADDLE — the spend crossed the boundary mid-action —
// and it is spelled out rather than collapsed, because it is the one case where the monthly-first
// rule is visibly doing something.
export function bucketOf(h) {
  if (h.allowance && h.wallet) return `${h.allowance} monthly + ${h.wallet} bought`;
  if (h.wallet)                return 'bought credits';
  if (h.allowance)             return 'monthly credits';
  return null;
}
const formatResetDate = (iso) => {
  if (!iso) return 'the 1st';
  try {
    return new Date(iso).toLocaleDateString('en-IN', { day: 'numeric', month: 'long' });
  } catch { return 'the 1st'; }
};

const s = {
  balance: { display: 'flex', flexDirection: 'column', gap: 2 },
  // Sized to the real number's line box, so nothing shifts when it swaps in.
  numSkeleton: { width: 132, height: 41, borderRadius: 9, background: '#F1F5F2' },
  /* The one paragraph on this screen. Sits under the balance because a returning baker opened the
     panel to see the number, and a new one cannot read the number until they know what it buys. */
  lede:      { fontSize: 12.5, color: '#5A6B60', lineHeight: 1.55, margin: 0, fontWeight: 600 },
  listHead:  { fontSize: 12.5, fontWeight: 800, color: '#2C4433', margin: '0 0 7px' },
  priceList: {
    background: '#F7FAF8', border: '1px solid #E8EFE9', borderRadius: 11, padding: '11px 13px',
    display: 'flex', flexDirection: 'column', gap: 4,
  },
  priceRow: { display: 'flex', justifyContent: 'space-between', gap: 12, fontSize: 12 },
  split: {
    background: '#F7FAF8', border: '1px solid #E8EFE9', borderRadius: 11, padding: '11px 13px',
    display: 'flex', flexDirection: 'column', gap: 9,
  },
  splitRow:   { display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  splitLabel: { fontSize: 12.5, fontWeight: 800, color: '#2C4433' },
  splitSub:   { fontSize: 11, color: '#9BB5A2', fontWeight: 600, marginTop: 1 },
  splitNum:   { fontSize: 17, fontWeight: 800, color: '#2C4433', fontVariantNumeric: 'tabular-nums' },
  ledgerRow: {
    display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12,
    padding: '7px 0', borderBottom: '1px solid #F1F5F2',
  },
  ledgerLabel: { fontSize: 12.5, fontWeight: 700, color: '#4A5D51', overflow: 'hidden',
                 textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
  ledgerSub:   { fontSize: 10.5, color: '#B7C4BB', fontWeight: 600, marginTop: 1 },
  ledgerAmt:   { fontSize: 13, fontWeight: 800, fontVariantNumeric: 'tabular-nums', flexShrink: 0 },
  note: { background: '#F7FAF8', border: '1px solid #E8EFE9', borderRadius: 11, padding: '11px 13px' },
  // ── Buyable, and not ────────────────────────────────────────────────────────────────────────
  // These two must not be a matter of opacity. A pack used to be #fff on a #E8EFE9 border and the
  // read-only X-Ray price list #F7FAF8 on the SAME border — so an offer and a fact were the same
  // object, and the whole shelf read as text running down the page with nothing to press.
  //
  // So the surfaces now mean something: a WHITE, lifted, darker-bordered card is a thing you can
  // buy; the tinted flat card is a thing you can only read. A blocked pack takes the tinted
  // treatment rather than a faded copy of the buyable one, because it is — right now — a fact
  // about your balance and not an offer.
  pack: {
    display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12,
    background: '#fff', border: '1.5px solid #CBDDD1', borderRadius: 12,
    boxShadow: '0 1px 2px rgba(20,24,21,0.05)',
    padding: '13px 15px', fontFamily: 'inherit', textAlign: 'left', width: '100%',
    transition: 'border-color .15s, box-shadow .15s, transform .15s',
  },
  // flex-start, not centre: the reason line makes the left column three lines tall, and a centred
  // price then floats halfway down with nothing to line up against. It belongs beside the pack it
  // is the price of.
  packOff: {
    display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12,
    background: '#F7FAF8', border: '1px solid #EDF2EE', borderRadius: 12,
    padding: '13px 15px', fontFamily: 'inherit', textAlign: 'left', width: '100%',
  },
};

// Hover and press, which inline styles cannot express — and without them a card that IS pressable
// gives no sign of it until you have already clicked. Same approach as the panel shell's own CSS.
const PACK_CSS = `
  .spattoo-pack:hover:not(:disabled) { border-color: #9DBBA8; box-shadow: 0 4px 14px rgba(20,24,21,0.10);
    transform: translateY(-1px); }
  .spattoo-pack:active:not(:disabled) { transform: translateY(0); box-shadow: 0 1px 2px rgba(20,24,21,0.06); }
  .spattoo-pack:focus-visible { outline: 2px solid #7FA98C; outline-offset: 2px; }
`;
