import { INK } from './tokens.js';
// ── Toggleable chip ───────────────────────────────────────────────────────────
// A pill you tap to turn on or off. Extracted the moment it was needed twice — the
// dietary picker on the order form and the flavour declarations in settings — rather
// than pasted a second time. Two copies of a chip is two hover states, two focus rings
// and two mobile hit-targets that quietly drift apart (the de-overlap rule reached four
// copies before anyone unified it; the tax is real).
//
// Colour is a prop, not a branch: callers pass the tone they want (the dietary surfaces
// pass dietTone(kind), settings passes the baker's brand colour). This component knows
// nothing about diets, flavours or brands — it knows pressed and not pressed.

// `tone`   { fg, bg, border } when active — falls back to a neutral ink
// `variant` 'solid' (a normal choice) | 'dashed' (a value inherited from elsewhere that
//           the user may override — dashed reads as provisional without relying on hue,
//           which matters because these are the same surfaces that must stay legible in
//           greyscale and to colour-blind readers)
export default function Chip({
  label, active, onClick, isMobile = false, disabled = false,
  tone = null, variant = 'solid', title = null,
}) {
  const fg     = tone?.fg     ?? INK;
  const bg     = tone?.bg     ?? 'rgba(26,26,26,0.06)';
  const border = tone?.border ?? '#999999';

  return (
    <button
      type="button"
      onClick={disabled ? undefined : onClick}
      disabled={disabled}
      title={title ?? undefined}
      aria-pressed={!!active}
      style={{
        padding: isMobile ? '12px 16px' : '8px 14px',
        borderRadius: 12,
        border: `1.5px ${variant === 'dashed' ? 'dashed' : 'solid'} ${active ? border : '#999999'}`,
        fontSize: isMobile ? 14 : 11,
        fontWeight: 700,
        cursor: disabled ? 'not-allowed' : 'pointer',
        background: active ? bg : 'transparent',
        color: active ? fg : '#666',
        /* ⚠️ A locked chip that IS the current value stays at full strength. Dimming
           everything equally made a locked pair unreadable — the egg/eggless chips, once
           vegan forces eggless, showed the chosen and the rejected side at the same
           weight, so the customer could not tell which way it had been decided. That is
           the whole reason those chips are locked rather than hidden. Fading is for what
           you CANNOT pick, never for what has been picked for you. */
        opacity: disabled && !active ? 0.5 : 1,
        fontFamily: "'Quicksand', sans-serif",
        /* ⚠️ A PILL NEVER BREAKS ITS OWN LABEL, and never shrinks below it. In a row that scrolls
           sideways instead of wrapping (`ScrollFadeRow`, flex-nowrap) a chip is a shrinkable flex
           child like any other, so "On a stick" came out stacked as three lines in a squashed
           lozenge on the decoration card. Wrapping is the ROW's job — the chip is one word-shaped
           thing or it is not a chip. */
        whiteSpace: 'nowrap',
        flexShrink: 0,
        transition: 'all 0.15s',
      }}
    >
      {label}
    </button>
  );
}
