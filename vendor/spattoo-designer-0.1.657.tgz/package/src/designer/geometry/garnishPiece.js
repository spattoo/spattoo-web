import * as THREE from 'three';
import { buildPipingStroke, mergePenGeometries } from './creamPen.js';

// ── A drawn garnish, as a piece you can pick up ──────────────────────────────────────────────────
//
// The studio produces polylines: an outline, and optionally a fill. This turns them into ONE mesh
// with a size and an origin — the missing noun. Until a drawing is an object it cannot be placed,
// cannot be rotated upright, cannot be dragged, and cannot be saved and used on another cake.
//
// ⚠️ IT IS THE SAME SWEEP THE PEN USES. `buildPipingStroke` builds the rope; this only lays the
// paths flat, merges them and moves the result to a sensible origin. Writing a second, "flat"
// rope-builder would be a copy that drifts — and the whole appeal is that a garnish looks like the
// piped chocolate it is, which means it must be made the way the piped chocolate is made.
//
// ⚠️ FLAT IN X/Y, WITH THE ROPE'S OWN DEPTH IN Z. Piped on parchment, a garnish IS flat: a couple of
// rope-widths thick and no more. The thickness is not a parameter to be tuned upward — a garnish
// thick enough to look like a slab is one that would never have set in that shape. It comes from the
// nozzle, which is where it comes from in life.
//
// ⚠️ THE ORIGIN IS THE BOTTOM-CENTRE OF THE PIECE, NOT ITS MIDDLE, and this is what makes standing
// work. A piece stood upright turns about the point where it meets the cake; with a centred origin
// it would sink half its height into the buttercream, and every standing garnish would need a
// compensating offset applied by whoever placed it — which is how two callers end up disagreeing.

/**
 * paths      [[ [x, y], … ], …] in the studio's own 2D space (its plate)
 * rope       the nozzle's rope radius, in the same units
 * plateSize  the width of the plate the paths were drawn on, so the piece can be scaled to the cake
 *
 * Returns `{ geometry, size, ropeWorld }` — geometry centred on x, resting on y = 0, or `null` when
 * there is nothing to build.
 */
/* ⚠️ `frame` IS WHAT KEEPS A TWO-TONE PIECE FROM COLLAPSING INTO A PILE. A piece with more than one
 * chocolate is built as one geometry per colour, and each of those would otherwise centre itself on
 * its OWN bounds — so a white circle drawn in the corner of a dark triangle would come out sitting
 * dead centre on top of it, every part stacked at the same origin with their relative positions
 * thrown away. Pass the whole piece's bounds and every part is placed in the same frame.
 * (The SCALE is safe either way: `k` comes from the plate, not from the drawing's extent.) */
export function buildGarnishGeometry(paths, { rope = 6, plateSize = 420, worldSize = 0.9, frame = null } = {}) {
  if (!paths?.length) return null;

  // Studio pixels → cake units. Everything scales together, so a garnish drawn large and one drawn
  // small come out the same size on the cake — what the baker drew is the SHAPE, not the size.
  const k = worldSize / plateSize;
  const ropeWorld = Math.max(0.004, rope * k);

  const parts = [];
  for (const path of paths) {
    if (!path || path.length < 2) continue;
    // Studio y runs DOWN the screen; the cake's runs up. Flipping here rather than at draw time
    // keeps the studio's own maths in screen space, where anyone debugging it expects to find it.
    const pts = path.map(([x, y]) => [x * k, -y * k, 0]);
    const geo = buildPipingStroke(pts, 'round', ropeWorld);
    if (geo) parts.push(geo);
  }
  if (!parts.length) return null;

  const merged = mergePenGeometries(parts);
  merged.computeBoundingBox();
  /* ⚠️ CLONED BEFORE THE TRANSLATE BELOW. `BufferGeometry.translate` moves the bounding box with the
     vertices, so a caller collecting several parts' boxes to build a shared frame would be unioning
     boxes that had each already been re-centred — every one of them sitting at the origin, and the
     frame therefore meaningless. This is the piece's extent WHERE IT WAS DRAWN. */
  const bounds = frame ?? merged.boundingBox.clone();
  const size = {
    w: bounds.max.x - bounds.min.x,
    h: bounds.max.y - bounds.min.y,
    d: bounds.max.z - bounds.min.z,
  };
  // Bottom-centre origin: x centred, y resting on zero. See the note above — this is what lets a
  // standing piece turn about the point where it touches the cake.
  merged.translate(-(bounds.min.x + bounds.max.x) / 2, -bounds.min.y, -(bounds.min.z + bounds.max.z) / 2);
  return { geometry: merged, size, bounds, ropeWorld };
}

/**
 * How a piece sits where it was put.
 *
 * ⚠️ A STANDING PIECE IS PUSHED INTO THE BUTTERCREAM. Without that it rests exactly on the surface,
 * which reads as floating — the one tell that separates a render from a photograph, and the same
 * fault the background-replacement prototype hit with a cake board on a pale backdrop. A real garnish
 * is pressed in until it holds, so the insertion is a fraction of the piece's height, floored so a
 * small piece still gets a bite.
 */
export const INSERT_FRACTION = 0.06;
export const insertionDepth = (height, rope) => Math.max(rope * 1.5, height * INSERT_FRACTION);

/** Where the piece's own origin goes for a given mode. `lie` puts it flat on the surface; `stand`
 *  turns it upright and buries the foot. Rotation is about x, so the piece rises toward the viewer
 *  rather than falling away from them. */
export function garnishTransform(mode, { height = 0.5, rope = 0.02, surfaceY = 0 } = {}) {
  if (mode === 'stand') {
    return { rotation: [0, 0, 0], y: surfaceY - insertionDepth(height, rope) };
  }
  // Lying down: rotate flat so the piece's own "up" becomes the surface's outward normal, and lift
  // it by the rope's radius so it rests ON the surface rather than half-sunk in it.
  return { rotation: [-Math.PI / 2, 0, 0], y: surfaceY + rope };
}
