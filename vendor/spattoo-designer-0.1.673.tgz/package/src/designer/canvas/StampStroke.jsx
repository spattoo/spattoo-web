import { useMemo } from 'react';
import { useGLTF } from '@react-three/drei';
import * as THREE from 'three';
import { stampTransforms } from '../geometry/creamPen.js';
import { creamMaterialProps } from './CakeTier.jsx';
import { extractGeo } from './shellGeo.js';
import { SafeGlb } from './TextureErrorBoundary.jsx';

// ── GLB stamp stroke ─────────────────────────────────────────────────────────
// Renders one committed stamp stroke (a tap → single stamp, or a drag → row of stamps) by
// cloning the chosen library GLB's mesh at each placement transform. We deliberately strip
// the GLB's own materials and apply the shared cream material (piping renders geometry-only),
// so every stamp matches the pen's colour/softness.
//
// The export is a thin SafeGlb wrapper: it carries the Suspense useGLTF needs (so no call site has
// to remember one) AND the shared boundary, so a stamp whose GLB has gone missing costs that stroke
// rather than throwing out of the canvas and killing the screen.
export default function StampStroke(props) {
  return <SafeGlb screen="StampStroke"><StampStrokeImpl {...props} /></SafeGlb>;
}

/* `userData` and the pointer handlers are PASSED THROUGH, not decoration: a stamp has to be
   able to act as a hit target. The cream pattern studio pipes onto what is already piped, which
   means a ray that strikes a placed piece must report that piece — its id, its stroke, and the
   direction it grew — rather than falling through to the cake behind it. Adding it here keeps ONE
   stamp renderer: the alternative was a second copy inside the studio, which is how a studio and
   the cake start shading the same cream two different ways (INVARIANTS #15). Absent on every
   existing call site, where these are undefined and the mesh is exactly what it was.

   ⚠️ `onClick` IS SEPARATE FROM `onPointerDown` AND BOTH ARE NEEDED. The pen stacks on pointer DOWN
   — a press is where a new piece seats. Selecting a placed piece has to be a CLICK, because the
   tier underneath is selected by its own R3F `onClick`, and stopping propagation on a pointerdown
   does not stop a click. */
function StampStrokeImpl({ stroke, url, color, softness, userData, onPointerDown, onPointerMove, onClick }) {
  const glbUrl = url || stroke.glbUrl;
  const { scene } = useGLTF(glbUrl);

  // ── The RING's preparation, not a second one ─────────────────────────────────────────────────
  // This used to merge every mesh, centre on X/Z and seat on the raw base. Reasonable, and not what
  // a ring does — extractGeo bakes a +90° X rotation into the geometry before any config value is
  // read, takes the FIRST mesh rather than merging, and seats on the base AFTER that turn. So a
  // hand-piped shell started a quarter turn out from a ringed one, and every attempt to fix the
  // orientation by adjusting the ROTATION was correcting the wrong side of the difference. The
  // rotation was never what differed.
  //
  // `sizeY` comes back from the same call, so the height a piped stamp scales by is measured the way
  // the ring measures it too.
  const { geo, footprint, height, bbox } = useMemo(() => {
    const prepared = extractGeo(scene);
    if (!prepared?.geo) return { geo: null, footprint: 1, height: 1, bbox: null };
    const g = prepared.geo;
    g.computeBoundingBox();
    const b = g.boundingBox, size = new THREE.Vector3();
    b.getSize(size);
    return {
      geo: g,
      footprint: Math.max(size.x, size.z),
      height: prepared.sizeY || size.y || 1,
      // Already in the frame the transform rotates — extractGeo has centred and seated it.
      bbox: { min: b.min.toArray(), max: b.max.toArray() },
    };
  }, [scene]);

  const transforms = useMemo(
    () => (geo ? stampTransforms(stroke, { footprint, height, bbox }) : []),
    [geo, footprint, height, bbox, stroke],
  );
  if (!geo) return null;
  const mat = creamMaterialProps(softness ?? stroke.softness, color ?? stroke.color);

  return transforms.map((t, i) => (
    <mesh key={i} geometry={geo} position={t.pos} quaternion={t.quat} scale={t.scale} castShadow
      userData={userData} onPointerDown={onPointerDown} onPointerMove={onPointerMove} onClick={onClick}>
      <meshPhysicalMaterial {...mat} />
    </mesh>
  ));
}
